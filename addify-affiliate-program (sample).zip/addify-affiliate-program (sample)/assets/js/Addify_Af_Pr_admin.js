jQuery(document).ready(function ($) {
  jQuery(".sel_affiliate").select2({
    ajax: {
      url: wsp_php_vars.admin_url,
      dataType: "json",
      type: "POST",
      delay: 250,
      data: function (params) {
        return {
          q: params.term || "",
          action: "Addify_Af_Pr_save_meta_box",
          nonce: wsp_php_vars.nonce,
          context: "restrict_affiliates",
        };
      },
      processResults: function (data) {
        if (data && Array.isArray(data)) {
          return {
            results: data.map(function (item) {
              return { id: item.id, text: item.text };
            }),
          };
        }
        return { results: [] };
      },
      error: function (xhr, status, error) {
        console.error("Error fetching data:", error);
      },
      cache: true,
    },
    multiple: true,
    placeholder: wsp_php_vars.choose_affiliate,
    allowClear: true,
    minimumInputLength: 0,
  });
  jQuery(".sel_affiliate2").select2({
    ajax: {
      url: wsp_php_vars.admin_url,
      dataType: "json",
      type: "POST",
      delay: 250,
      data: function (params) {
        return {
          q: params.term || "",
          action: "Addify_Af_Pr_save_meta_box",
          nonce: wsp_php_vars.nonce,
          context: "restrict_affiliates2",
        };
      },
      processResults: function (data) {
        if (data && Array.isArray(data)) {
          return {
            results: data.map(function (item) {
              return { id: item.id, text: item.text };
            }),
          };
        }
        return { results: [] };
      },
      error: function (xhr, status, error) {
        console.error("Error fetching data:", error);
      },
      cache: true,
    },
    multiple: true,
    placeholder: wsp_php_vars.choose_affiliate,
    allowClear: true,
    minimumInputLength: 0,
  });
  jQuery(".sel_payment").select2({
    ajax: {
      url: wsp_php_vars.admin_url,
      dataType: "json",
      type: "POST",
      delay: 60,
      data: function (params) {
        return {
          q: params.term,
          action: "Addify_Af_Pr_save_meta_box",
          context: "payments",
          nonce: wsp_php_vars.nonce,
        };
      },
      processResults: function (data) {
        return { results: data };
      },
      cache: true,
    },
    placeholder: wsp_php_vars.choose_payment,
    allowClear: true,
    minimumInputLength: 3,
  });

  jQuery(".sel-role").select2({
    ajax: {
      url: wsp_php_vars.admin_url,
      dataType: "json",
      type: "POST",
      delay: 250,
      data: function (params) {
        return {
          q: params.term || "",
          action: "Addify_Af_Pr_save_meta_box",
          nonce: wsp_php_vars.nonce,
          context: "roles",
        };
      },
      processResults: function (data) {
        if (data && Array.isArray(data)) {
          return {
            results: data.map(function (item) {
              return { id: item.id, text: item.text };
            }),
          };
        }
        return { results: [] };
      },
      error: function (xhr, status, error) {
        console.error("Error fetching data:", error);
      },
      cache: true,
    },
    multiple: true,
    placeholder: wsp_php_vars.choose_role,
    allowClear: true,
    minimumInputLength: 3,
  });
  jQuery(".sel_pros").select2({
    ajax: {
      url: wsp_php_vars.admin_url,
      dataType: "json",
      type: "POST",
      delay: 60,
      data: function (params) {
        return {
          q: params.term,
          action: "Addify_Af_Pr_save_meta_box",
          context: "products", // Specify the context as 'products'
          nonce: wsp_php_vars.nonce,
        };
      },
      processResults: function (data) {
        return { results: data };
      },
      cache: true,
    },
    placeholder: wsp_php_vars.choose_products,
    allowClear: true,
    minimumInputLength: 3,
  });
  jQuery(".sel_brands").select2({
    ajax: {
      url: wsp_php_vars.admin_url,
      dataType: "json",
      type: "POST",
      delay: 60,
      data: function (params) {
        return {
          q: params.term,
          action: "Addify_Af_Pr_save_meta_box",
          context: "brands",
          nonce: wsp_php_vars.nonce,
        };
      },
      processResults: function (data) {
        return { results: data };
      },
      cache: true,
    },
    placeholder: wsp_php_vars.choose_brands,
    allowClear: true,
    minimumInputLength: 3,
  });

  jQuery(".sel_categories").select2({
    ajax: {
      url: wsp_php_vars.admin_url,
      dataType: "json",
      type: "POST",
      delay: 60,
      data: function (params) {
        return {
          q: params.term,
          action: "Addify_Af_Pr_save_meta_box",
          context: "categories", // Specify the context as 'categories'
          nonce: wsp_php_vars.nonce,
        };
      },
      processResults: function (data) {
        return { results: data };
      },
      cache: true,
    },
    placeholder: wsp_php_vars.choose_categories,
    allowClear: true,
    minimumInputLength: 3,
  });

  jQuery(function ($) {
    $(".woocommerce-help-tip").tipTip({
      attribute: "data-tip",
      fadeIn: 200,
      fadeOut: 200,
      delay: 200,
    });
  });

  function priceAdjustmentBlock() {
    $("head").append(`
      <style>
        #priceAdjustment_block_table th { text-align: center; }
        #priceAdjustment_block_body td input,
        #priceAdjustment_block_body td button,
        #priceAdjustment_block_body td select { width: 100%; }
        #add_priceAdjusmentRow {margin-top: 10px}
      </style>
    `);

    // Add row
    $(document)
      .off("click", "#add_priceAdjusmentRow")
      .on("click", "#add_priceAdjusmentRow", function () {
        let index = $("#priceAdjustment_block_body tr").length;
        let row = `
        <tr data-new="true">
          <td><input type="text" name="Addify_Af_Pr_affiliate_setting_price_adjustment_table[${index}][name]" required></td>
          <td><input type="number" min="0" name="Addify_Af_Pr_affiliate_setting_price_adjustment_table[${index}][earning_from]" required></td>
          <td><input type="number" min="0" name="Addify_Af_Pr_affiliate_setting_price_adjustment_table[${index}][earning_to]" required></td>
          <td><input type="number" min="0" name="Addify_Af_Pr_affiliate_setting_price_adjustment_table[${index}][commission_rate]" required></td>
          <td>
            <select name="Addify_Af_Pr_affiliate_setting_price_adjustment_table[${index}][commission_rate_type]" id="Addify_Af_Pr_affiliate_setting_price_adjustment_table[${index}][commission_rate_type]">
              <option value="fixed">${wsp_php_vars.fixed}</option>
              <option value="percentage">${wsp_php_vars.percentage}</option>
            </select>
          </td>
          <td>
            <select name="Addify_Af_Pr_affiliate_setting_price_adjustment_table[${index}][status]" id="Addify_Af_Pr_affiliate_setting_price_adjustment_table[${index}][status]">
              <option value="1">${wsp_php_vars.active}</option>
              <option value="0">${wsp_php_vars.inactive}</option>
            </select>
          </td>
          <td><button type="button" class="button remove_priceAdjustment_block">${wsp_php_vars.remove}</button></td>
        </tr>`;
        $("#priceAdjustment_block_body").append(row);
      });

    // Remove row and normalize indexes
    $(document)
      .off("click", ".remove_priceAdjustment_block")
      .on("click", ".remove_priceAdjustment_block", function () {
        $(this).closest("tr").remove();
        normalizeIndexes();
      });
    normalizeIndexes();

    // Normalize indexes after removing rows
    function normalizeIndexes() {
      $("#priceAdjustment_block_body tr").each(function (newIndex) {
        $(this)
          .find("input, select")
          .each(function () {
            const oldName = $(this).attr("name");
            const oldId = $(this).attr("id");

            if (oldName) {
              const newName = oldName.replace(/\[\d+\]/, `[${newIndex}]`);
              $(this).attr("name", newName);
            }

            if (oldId) {
              const newId = oldId.replace(/\[\d+\]/, `[${newIndex}]`);
              $(this).attr("id", newId);
            }
          });
      });
    }
  }
  function automaticRulesBlock() {
    $("head").append(`
      <style>
        #automaticRules_block_table th { text-align: center; }
        #automaticRules_block_body td input,
        #automaticRules_block_body td button,
        #automaticRules_block_body td select { width: 100%; }
        #add_automaticRulesRow {margin-top: 10px}
       
      </style>
    `);

    // Add row
    $(document)
      .off("click", "#add_automaticRulesRow")
      .on("click", "#add_automaticRulesRow", function () {
        let index = $("#automaticRules_block_body tr").length;
        let dayOptions = `
    <option value="">No Selection</option>
    <option value="Monday">Monday</option>
    <option value="Tuesday">Tuesday</option>
    <option value="Wednesday">Wednesday</option>
    <option value="Thursday">Thursday</option>
    <option value="Friday">Friday</option>
    <option value="Saturday">Saturday</option>
    <option value="Sunday">Sunday</option>
  `;

        let row = `
    <tr data-new="true">
      <td><input type="text" name="Addify_Af_Pr_affiliate_setting_automatic_rules_table[${index}][name]"></td>
      <td><input type="text" name="Addify_Af_Pr_affiliate_setting_automatic_rules_table[${index}][priority]"></td>
      <td><input type="number" min="0" name="Addify_Af_Pr_affiliate_setting_automatic_rules_table[${index}][payout_amount]"></td>
      <td>
        <select name="Addify_Af_Pr_affiliate_setting_automatic_rules_table[${index}][payout_type]" id="Addify_Af_Pr_affiliate_setting_automatic_rules_table[${index}][payout_type]">
          <option value="threshold">Threshold</option>
          <option value="date">Date</option>
          <option value="day">Day</option>
        </select>
      </td>
      <td>
        <input type="number" min="0" name="Addify_Af_Pr_affiliate_setting_automatic_rules_table[${index}][threshold]">
        <input type="date" hidden name="Addify_Af_Pr_affiliate_setting_automatic_rules_table[${index}][date]">
        <select hidden name="Addify_Af_Pr_affiliate_setting_automatic_rules_table[${index}][day]" id="Addify_Af_Pr_affiliate_setting_automatic_rules_table[${index}][day]">
          ${dayOptions}
        </select>
      </td>
      <td>
        <select name="Addify_Af_Pr_affiliate_setting_automatic_rules_table[${index}][status]" id="Addify_Af_Pr_affiliate_setting_automatic_rules_table[${index}][status]">
          <option value="1">Active</option>
          <option value="0">Inactive</option>
        </select>
      </td>
      <td><button type="button" class="button remove_automaticRules_block">${wsp_php_vars.remove}</button></td>
    </tr>
  `;

        $("#automaticRules_block_body").append(row);
      });

    // Remove row and normalize indexes
    $(document)
      .off("click", ".remove_automaticRules_block")
      .on("click", ".remove_automaticRules_block", function () {
        $(this).closest("tr").remove();
        automaticrulesnormalizeIndexes();
      });
    automaticrulesnormalizeIndexes();

    // Normalize indexes after removing rows
    function automaticrulesnormalizeIndexes() {
      $("#automaticRules_block_body tr").each(function (newIndex) {
        $(this)
          .find("input, select")
          .each(function () {
            const oldName = $(this).attr("name");
            const oldId = $(this).attr("id");

            if (oldName) {
              const newName = oldName.replace(/\[\d+\]/, `[${newIndex}]`);
              $(this).attr("name", newName);
            }

            if (oldId) {
              const newId = oldId.replace(/\[\d+\]/, `[${newIndex}]`);
              $(this).attr("id", newId);
            }
          });
      });
    }
  }
  // Function to toggle field visibility
  // Function to toggle field visibility
  function togglePayoutFields($row, selectedType) {
    if (!$row || !$row.length) {
      $('input[name$="[date]"]').hide().prop("disabled", true);
      $('select[name$="[day]"]').hide().prop("disabled", true);
    } else {
      // Hide and disable all fields
      $row.find('input[name$="[threshold]"]').hide().prop("disabled", true);
      $row.find('input[name$="[date]"]').hide().prop("disabled", true);
      $row.find('select[name$="[day]"]').hide().prop("disabled", true);

      // Fallback to "threshold" if selectedType is not recognized
      if (
        selectedType === "threshold" ||
        !["date", "day"].includes(selectedType)
      ) {
        $row.find('input[name$="[threshold]"]').show().prop("disabled", false);
      } else if (selectedType === "date") {
        $row.find('input[name$="[date]"]').show().prop("disabled", false);
      } else if (selectedType === "day") {
        $row.find('select[name$="[day]"]').show().prop("disabled", false);
      }
    }
  }

  // Delegate change event
  $(document).on("change", 'select[name*="[payout_type]"]', function () {
    let $row = $(this).closest("tr");
    let selectedType = $(this).val();
    togglePayoutFields($row, selectedType);
  });
  function toggleRegistrationFields(type) {
    const placeholder = $("#Addify_Af_Pr_field_placeholder");

    let placeholderText = "";

    switch (type) {
      case "text":
        placeholderText = "Type here…";
        break;
      case "email":
        placeholderText = "abc@xyz.com";
        break;
      case "number":
        placeholderText = "+1 212 555 1234";
        break;
      case "textarea":
        placeholderText = "Type here…";
        break;
      case "tel":
        placeholderText = "+1 212 555 1234";
        break;
      default:
        placeholderText = "Enter field placeholder";
    }

    // 🔥 delay to override WP admin auto-fill scripts
    setTimeout(() => {
      placeholder.attr("placeholder", placeholderText);
    }, 50);
  }

  // On document ready, initialize all rows
  $(document).ready(function () {
    $('select[name*="[payout_type]"]').each(function () {
      let $row = $(this).closest("tr");
      let selectedType = $(this).val();
      togglePayoutFields($row, selectedType);
    });
    $(document).on("change", "#Addify_Af_Pr_field_type", function () {
      const type = $(this).val();
      toggleRegistrationFields(type);
    });
  });

  jQuery(document).on("click", ".Addify_Af_Pr_check", function () {
    hideFields();
  });
  function hideFields() {
    var applyallcheck = $("#Addify_Af_Pr_apply_all").prop("checked");
    if (applyallcheck !== true) {
      $('label[for="Addify_Af_Pr_applied_products"]').closest("tr").show();
      $('label[for="Addify_Af_Pr_applied_brands"]').closest("tr").show();
      $('label[for="Addify_Af_Pr_applied_categories"]').closest("tr").show();
      $('label[for="Addify_Af_Pr_product_price"]').closest("tr").show();
    } else {
      $('label[for="Addify_Af_Pr_applied_products"]').closest("tr").hide();
      $('label[for="Addify_Af_Pr_applied_brands"]').closest("tr").hide();
      $('label[for="Addify_Af_Pr_applied_categories"]').closest("tr").hide();
      $('label[for="Addify_Af_Pr_product_price"]').closest("tr").hide();
    }
    var custompayoutcheck = $("#Addify_Af_Pr_custom_payout").prop("checked");
    if (custompayoutcheck == true) {
      $('label[for="Addify_Af_Pr_custom_payout_amount"]').closest("tr").show();
    } else {
      $('label[for="Addify_Af_Pr_custom_payout_amount"]').closest("tr").hide();
    }
    var applyallaffiliate = $(
      "#Addify_Af_Pr_affiliate_setting_apply_on_all_affiliates"
    ).prop("checked");
    if (applyallaffiliate !== true) {
      $("#Addify_Af_Pr_specific_affiliate_include_exclude")
        .closest("tr")
        .show();
      $("#Addify_Af_Pr_specific_affiliate_include_exclude_value")
        .closest("tr")
        .show();
    } else {
      $("#Addify_Af_Pr_specific_affiliate_include_exclude")
        .closest("tr")
        .hide();
      $("#Addify_Af_Pr_specific_affiliate_include_exclude_value")
        .closest("tr")
        .hide();
    }
  }
  jQuery(document).on("change", "#Addify_Af_Pr_field_type", function () {
    checkRegistrationFields();
  });
  jQuery(document).on(
    "change",
    "#Addify_Af_Pr_affiliate_setting_enable_auto_manual",
    function () {
      checkAutoManual();
    }
  );
  function checkAutoManual() {
    var automanualcheck = $(
      "#Addify_Af_Pr_affiliate_setting_enable_auto_manual"
    ).prop("checked");
    if (automanualcheck !== true) {
      $("#Addify_Af_Pr_affiliate_setting_default_status").closest("tr").show();
    } else {
      $("#Addify_Af_Pr_affiliate_setting_default_status").closest("tr").hide();
    }
  }
  function checkRegistrationFields() {
    var field_type = $("#Addify_Af_Pr_field_type").val();
    let placeholderInput = $("#Addify_Af_Pr_field_placeholder");

    if (field_type == "select") {
      $('label[for="Addify_Af_Pr_field_placeholder"]').closest("tr").hide();
      $('label[for="Addify_Af_Pr_field_options"]').closest("tr").show();
      $("#Addify_Af_Pr_field_options").attr(
        "placeholder",
        "Add options like (option->Small,option->Medium,option->Large)"
      );
    } else if (field_type == "radio") {
      $("#Addify_Af_Pr_field_options").attr(
        "placeholder",
        "Add options like (option->Small,option->Medium,option->Large)"
      );
      $('label[for="Addify_Af_Pr_field_placeholder"]').closest("tr").hide();
      $('label[for="Addify_Af_Pr_field_options"]').closest("tr").show();
      placeholderInput.attr("placeholder", "Choose an option");
    } else if (field_type == "checkbox") {
      $('label[for="Addify_Af_Pr_field_placeholder"]').closest("tr").hide();
      $('label[for="Addify_Af_Pr_field_options"]').closest("tr").hide();
    } else {
      $('label[for="Addify_Af_Pr_field_placeholder"]').closest("tr").show();
      $('label[for="Addify_Af_Pr_field_options"]').closest("tr").hide();
      placeholderInput.attr("placeholder", "Enter field placeholder");
    }
  }
 $('#addify_copy_button').on('click', function () {
        const value = $('#addify_copy_field').val();
        // Copy without selecting the input
        navigator.clipboard.writeText(value).then(() => {
            $(this).text('Copied!');
            setTimeout(() => {
                $(this).text('Copy');
            }, 1200);
        });
    });
  var postType = document.getElementById("post_type")?.value;

  if (postType === "payout_post") {
    // Only run this if it's a payout_post
    let payoutConfirmationHandler = null;

    function changeRequiredAttribute() {
      var selectedValue = $(".Addify_Af_Pr_withdrawal_payment_method")
        .find(":selected")
        .val();
      const form = document.querySelector("#post");
      const submitBtn = document.querySelector("#publish");

      if (selectedValue === "stripe" || selectedValue === "ppcp-gateway") {
        if (form && submitBtn && !payoutConfirmationHandler) {
          payoutConfirmationHandler = function (e) {
            const confirmed = confirm(
              "Are you sure you want to proceed with this payout?"
            );
            if (!confirmed) {
              e.preventDefault();
            } else {
              let hiddenInput = document.createElement("input");
              hiddenInput.type = "hidden";
              hiddenInput.name = "confirm_payout";
              hiddenInput.value = "1";
              form.appendChild(hiddenInput);
            }
          };
          form.addEventListener("submit", payoutConfirmationHandler);
        }

        $("#Addify_Af_Pr_transaction_id").removeAttr("required");
        $("#Addify_Af_Pr_transaction_id").closest("tr").hide();
      } else {
        if (form && payoutConfirmationHandler) {
          form.removeEventListener("submit", payoutConfirmationHandler);
          payoutConfirmationHandler = null;
        }

        $("#Addify_Af_Pr_transaction_id").closest("tr").show();
        $("#Addify_Af_Pr_transaction_id").attr("required", "required");
      }
    }
    $(".Addify_Af_Pr_withdrawal_payment_method").on(
      "change",
      changeRequiredAttribute
    );
    changeRequiredAttribute();
  }
  $('input[type="checkbox"][name^="notify_"]').change(function () {
    var statusText = $(this).siblings(".status-text");
    if ($(this).is(":checked")) {
      statusText.text(wsp_php_vars.enabled_text);
    } else {
      statusText.text(wsp_php_vars.disabled_text);
    }
  });

  hideFields();
  priceAdjustmentBlock();
  automaticRulesBlock();
  toggleRegistrationFields("text");
  checkAutoManual();
  checkRegistrationFields();

});
