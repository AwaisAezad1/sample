jQuery(document).ready(function ($) {
  jQuery(".wc-product-user-role").select2({
    ajax: {
      url: wsp_php_vars.admin_url,
      dataType: "json",
      type: "POST",
      delay: 250,
      data: function (params) {
        return {
          q: params.term || "",
          action: "Addify_Af_Pr_custom_fields_save",
          nonce: wsp_php_vars.nonce,
          context: "roles_product",
        };
      },
      processResults: function (data) {
        if (data && Array.isArray(data)) {
          return {
            results: data.map(function (item) {
              return { id: item.id, text: item.text };
            }),
          };
        }
        return { results: [] };
      },
      error: function (xhr, status, error) {
        console.error("Error fetching data:", error);
      },
      cache: true,
    },
    multiple: true,
    placeholder: wsp_php_vars.choose_role,
    allowClear: true,
    minimumInputLength: 3,
  });
  
});
