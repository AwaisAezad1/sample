jQuery(document).ready(function ($) {
  // Show active tab content on load
$('#product-select').select2({
    placeholder: '-- Choose a product --',
    width: '100%',
    allowClear: true,
    minimumInputLength: 3,
  });

  var activeTab = $(".tab-menu li.active").data("tab");
  $("#" + activeTab + "-content").addClass("active");

  // Handle tab switching
  $(".tab-menu li").click(function () {
    var tab = $(this).data("tab");
    $(".tab-menu li").removeClass("active");
    $(".tab-content").removeClass("active");
    $(this).addClass("active");
    $("#" + tab + "-content").addClass("active");
  });
  const forms = document.querySelectorAll(
    "#generate-link-btn, #submit_affiliate"
  );

  $("#generate-link-btn, #submit_affiliate").on("click", function () {
    // Reset URL without tab or pagination
    window.history.replaceState(
      {},
      document.title,
      addify_affiliate_data.clean_url
    );
  });

  // Generate affiliate link and append to table
  $("#generate-link-btn").click(function () {
    const user_id = $("#affiliate_user_id").val();
    const referral_expiry_in_days = $("#referral_expiry_in_days").val();
    const select = $("#product-select")[0];
    const productId = select.value;

    const productLink = select.options[select.selectedIndex].value;
    const productName = select.options[select.selectedIndex].dataset.name;
    const commission = select.options[select.selectedIndex].dataset.commission;
    const commissionType =
      select.options[select.selectedIndex].dataset.commission_type;

    if (!productId) {
      alert("Please select a product.");
      return;
    }

    const link = productLink + "?" + "ref" + "=" + user_id;
    const expiryDays = parseInt(referral_expiry_in_days) || 30;
    const expiry = new Date();
    expiry.setDate(expiry.getDate() + expiryDays);
    const expiryDate = expiry.toISOString().split("T")[0];

    $("#generated-links-body tr").each(function () {
      const currentLink = $(this).find("a").attr("href");
      if (currentLink === link) {
        $(this).remove();
      }
    });

    const tableRows = $("#generated-links-body tr");
    const nextIndex = tableRows.length + 1;

    // Show loader on button
    const $btn = $("#generate-link-btn");
    $btn.prop("disabled", true).text("Generating...");

    $.ajax({
      url: addify_affiliate_data.ajaxurl,
      type: "POST",
      dataType: "json",
      data: {
        action: "addify_save_affiliate_link",
        nonce: addify_affiliate_data.nonce,
        id: nextIndex,
        productId: productId,
        productName: productName,
        link: link,
        expiryDate: expiryDate,
        commission: commission,
        commission_type: commissionType,
      },
      success: function (response) {
        if (response.success) {
          const id = response.data.id || nextIndex;
          const displayId = id + 1; // offset by +1 for display only

          const row = `
      <tr data-id="${id}">
        <td>${displayId}</td> <!-- show +1 -->
        <td>${productName}</td>
        <td><a href="${link}" target="_blank">${link}</a></td>
        <td>${expiryDate}</td>
        <td>${
          commissionType === "percentage" ? commission + "%" : addify_affiliate_data.currency_symbol+commission
        }</td>
        <td><button class="remove-link-btn" data-id="${id}">Remove</button></td>
      </tr>
    `;
          $("#generated-links-body").append(row);
          normalizeIndices(); // Recalculate table numbering if needed
        } else {
          alert(response.data.message || "Failed to generate link.");
        }
      },
      error: function () {
        alert("AJAX request failed.");
      },
      complete: function () {
        // Reset button after request finishes
        $btn.prop("disabled", false).text("Generate Link");
      },
    });
  });

  // Remove link from table + DB
  // Remove link from table + DB
  $(document).on("click", ".remove-link-btn", function () {
    const row = $(this).closest("tr");
    const id = $(this).data("id");
    const $btn = $(this);

    // Disable button + show loader text
    $btn.prop("disabled", true).text("Removing...");

    $.ajax({
      url: addify_affiliate_data.ajaxurl,
      method: "POST",
      data: {
        action: "addify_remove_affiliate_link",
        nonce: addify_affiliate_data.nonce,
        id: id,
      },
      success: function (response) {
        if (response.success) {
          row.remove(); // Remove the row from the table
          normalizeIndices(); // Normalize indices after removal
        } else {
          alert(response.data.message || "Failed to remove link.");
          $btn.prop("disabled", false).text("Remove"); // Re-enable if failed
        }
      },
      error: function () {
        alert("AJAX request failed.");
        $btn.prop("disabled", false).text("Remove");
      },
    });
  });

  // Normalize the index values after a link is removed
  // Normalize the index values after a link is removed
  function normalizeIndices() {
    $("#generated-links-body tr").each(function (index) {
      const newIndex = index; // real index in array
      const displayIndex = index + 1; // user-facing ID

      $(this).find("td:first").text(displayIndex);
      $(this).attr("data-id", newIndex);
      $(this).find(".remove-link-btn").attr("data-id", newIndex);
    });
  }
});
