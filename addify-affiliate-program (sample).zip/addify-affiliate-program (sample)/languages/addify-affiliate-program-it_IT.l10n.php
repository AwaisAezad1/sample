<?php
return array(
	'project-id-version'=>'Addify Affiliate Program',
	'report-msgid-bugs-to'=>'',
	'pot-creation-date'=>'2025-11-19 11:35+0000',
	'po-revision-date'=>'2025-11-19 11:35+0000',
	'last-translator'=>'',
	'language-team'=>'Italian',
	'language'=>'it_IT',
	'plural-forms'=>'nplurals=2; plural=n != 1;',
	'mime-version'=>'1.0',
	'content-type'=>'text/plain; charset=UTF-8',
	'content-transfer-encoding'=>'8bit',
	'x-generator'=>'Loco https://localise.biz/',
	'x-loco-version'=>'2.8.0; wp-6.8.3; php-8.2.12',
	'x-domain'=>'addify-affiliate-program',
	'messages'=>array(),
);
