<?php

/**
 * Plugin Name: Addify Affiliate Program
 * Plugin URI: https://www.your-site.com/
 * Description: An extension that lets you create, manage, and track affiliate programs directly within your WooCommerce store.
 * Version: 1.0.0
 * Author: Addify
 * Requires Plugins: woocommerce
 * Developed By:Addify
 * Author URI: https://woocommerce.com/vendor/Addify/
 * Support: https://woocommerce.com/vendor/Addify/
 * Domain Path: /languages
 * Text Domain: addify-affiliate-program
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 * WC requires at least: 4.0
 * WC tested up to: 9.*.*
 * Requires at least: 6.5
 * Tested up to: 6.*.*
 * Requires PHP: 8.0
 */

use function WPML\FP\Strings\remove;

if (!class_exists('Addify_Affiliate_Program')) {
	class Addify_Affiliate_Program {
	


		public function __construct() {
			$this->Addify_Affiliate_Program_Constents_Vars();
			add_action('before_woocommerce_init', array( $this, 'Addify_affiliate_program_before_woocommerce' ));
			register_activation_hook(__FILE__, array( $this, 'addify_create_affiliate_user_role' ));
			// Add this hook to update page title when user becomes affiliate
			add_action('wp', array( $this, 'update_affiliate_page_title' ));
			register_deactivation_hook(__FILE__, array( $this, 'addify_remove_affiliate_page' ));
			add_action('init', array( $this, 'affiliate_custom_cron_job' ));
			add_filter('cron_schedules', array( $this, 'bbloomer_check_interval' ));
			add_action('addify_affiliate_automatic_payout', array( $this, 'run_affiliate_auto_payout_cron' ));
			include_once AD_AFFILIATE_DIR . 'includes/addify_affiliate_program_main.php';
			add_action('template_redirect', array( $this, 'ka_redirect_register_affiliate_page' ));
		}
		public function ka_redirect_register_affiliate_page() {
			if (is_page('register-as-affiliate')) {
				$redirect_url = wc_get_account_endpoint_url('affiliate-account-settings');
				wp_safe_redirect($redirect_url);
				exit;
			}
		}
		// Remove the page on deactivation
		public function addify_remove_affiliate_page() {
			$page_slug = 'register-as-affiliate';
			$page = get_page_by_path($page_slug);

			if ($page) {
				wp_delete_post($page->ID, true); // true = force delete (skip trash)
			}
		}
		public function addify_create_affiliate_user_role() {
			add_role(
				'adf_affiliate',
				'Affiliate',
				array(
					'read' => true,
					'level_0' => true,
				)
			);
			$page_title = 'Register as Affiliate';
			$page_slug  = 'register-as-affiliate';
			$page_check = get_page_by_path($page_slug);

			if (! $page_check) {
				wp_insert_post(array(
					'post_title'   => $page_title,
					'post_name'    => $page_slug,
					'post_status'  => 'publish',
					'post_type'    => 'page',
					'post_content' => '',
				));
			}
			update_option('Addify_Af_Pr_affiliate_setting_enable', 'yes');
			update_option('Addify_Af_Pr_affiliate_setting_enable_registration_fields', 'yes');
			update_option('Addify_Af_Pr_affiliate_setting_enable_new_affiliation_email', 'yes');
			update_option('Addify_Af_Pr_affiliate_setting_restriction_message', 'Your affiliate account has been disabled by the admin');
			update_option('Addify_Af_Pr_affiliate_setting_endpoint_title', 'Affiliate');
		}
		public function update_affiliate_page_title() {
			$page_slug = 'register-as-affiliate';
			$page = get_page_by_path($page_slug);

			// Exit if page not found or admin area
			if (!$page || is_admin()) {
				return;
			}

			// Run only when the user is on my account page
			if (!function_exists('is_account_page') || !is_account_page()) {
				return;
			}

			// Check if we're on the specific affiliate page
			global $wp;
			$current_url = home_url($wp->request);
			$affiliate_page_url = get_permalink($page->ID);

			// Only show notice on the exact affiliate page
			if ($current_url !== $affiliate_page_url && !str_contains($current_url, 'affiliate-account-settings')) {
				return;
			}

			wc_clear_notices();

			$new_title = esc_html__('Register as Affiliate', 'addify-affiliate-program');

			if (is_user_logged_in()) {
				$user_id = get_current_user_id();

				// Check for affiliate posts for this user
				$affiliate_posts = get_posts(array(
					'post_type'      => 'affiliate_user_post',
					'posts_per_page' => 1,
					'post_status'    => 'publish',
					'author'         => $user_id,
					'fields'         => 'ids',
				));

				if (!empty($affiliate_posts)) {
					$new_title = esc_html__('Affiliate Dashboard', 'addify-affiliate-program');
				}
			} else {
				// Only show notice if user is not logged in
				wc_add_notice(
					esc_html__('You have to register as a user/customer before applying for the affiliate program.', 'addify-affiliate-program'),
					'notice'
				);
			}

			// Only update if title changed (avoid DB writes every page load)
			if ($page->post_title !== $new_title) {
				remove_action('save_post', array( $this, 'update_affiliate_page_title' )); // avoid recursion
				wp_update_post(array(
					'ID'         => $page->ID,
					'post_title' => $new_title,
				));
				add_action('save_post', array( $this, 'update_affiliate_page_title' ));
			}
		}


		public function Addify_affiliate_program_before_woocommerce() {
			if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
				\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
			}
		}

		public function Addify_Affiliate_Program_Constents_Vars() {
			if (!defined('AD_AFFILIATE_URL')) {
				define('AD_AFFILIATE_URL', plugin_dir_url(__FILE__));
			}
			if (!defined('AD_AFFILIATE_DIR')) {
				define('AD_AFFILIATE_DIR', plugin_dir_path(__FILE__));
			}
			if (!defined('AD_AFFILIATE_NAME')) {
				define('AD_AFFILIATE_NAME', plugin_basename(__DIR__));
			}
		}
		public function affiliate_custom_cron_job() {
			if (!wp_next_scheduled('addify_affiliate_automatic_payout')) {
				wp_schedule_event(time(), 'once_every_hour', 'addify_affiliate_automatic_payout');
			}
		}

		public function bbloomer_check_interval( $schedules ) {
			$schedules['once_every_hour'] = array(
				'interval' => 3600,
				'display' => esc_html__('Once Every Hour', 'addify-affiliate-program'),
			);

			return $schedules;
		}
		public function run_affiliate_auto_payout_cron() {

			global $wpdb;
			$today = current_time('Y-m-d');
			$weekday = gmdate('l', current_time('timestamp'));
			$rules = (array) get_option('Addify_Af_Pr_affiliate_setting_automatic_rules_table');
			$payment_method = (array) get_option('Addify_Af_Pr_auto_payment_method2');




			foreach ($rules as $rule) {
				$paid_amount = isset($rule['payout_amount']) ? floatval($rule['payout_amount']) : 0;
				$all_payout_posts = get_posts(array(
					'post_type'      => 'payout_post',
					'post_status'    => 'any',
					'posts_per_page' => -1,
				));

				if (!empty($all_payout_posts)) {
					foreach ($all_payout_posts as $post) {
						if ('publish' !== $post->post_status || empty($post)) {
							continue;
						}
						$post_id = $post->ID;
						$affiliate_id = $post->post_author;
						$affiliates = get_posts(array(
							'post_type'      => 'affiliate_user_post',
							'posts_per_page' => -1,
							'post_status'    => 'publish',
							'author'         => $affiliate_id,
						));
						foreach ($affiliates as $affiliate) {
							$affiliate_payment_method = get_post_meta($affiliate->ID, 'affiliate_auto_payment_method', true);
							if (!empty($affiliate_payment_method)) {
								// Handle both array and string formats
								if (is_array($affiliate_payment_method)) {
									$payment_method = isset($affiliate_payment_method[0]) ? $affiliate_payment_method[0] : $affiliate_payment_method;
								} else {
									$payment_method = $affiliate_payment_method;
								}
							}
						}


						if (!isset($rule['payout_type'])) {
							continue;
						}

						$should_payout = false;
						$earned = get_post_meta($post->ID, 'unpaid_amount', true);

						switch ($rule['payout_type']) {
							case 'date':
								if (isset($rule['date'])) {
									$rule_date = $rule['date'];
									// Check if the rule date is today or has already passed
									if ($rule_date == $today || strtotime($rule_date) <= strtotime($today)) {
										// Check if payout has already been processed for this date
										$last_payout_date = get_post_meta($post_id, 'last_automatic_payout_date', true);
										if ($last_payout_date !== $rule_date) {
											$should_payout = true;
										}
									}
								}
								break;

							case 'day':
								if (isset($rule['day']) && $rule['day'] === $weekday) {
									$should_payout = true;
								}
								break;

							case 'threshold':
								if (isset($rule['threshold']) && $earned >= floatval($rule['threshold'])) {
									$should_payout = true;
								}
								break;
						}

						if ($should_payout && $earned >= $paid_amount && $earned > 0) {
							$post = get_post($post_id);
							$user_id = $post->post_title;
							$user_data  = get_user_by('ID', $user_id);
							$username   = isset($user_data->user_login) ? $user_data->user_login : 'unknown';
							$user_email = isset($user_data->user_email) ? $user_data->user_email : 'unknown';
							$unpaid_amount = (float) 0;
							$total_amount  = (float) 0;
							$commission_amount =  get_post_meta($post->ID, 'unpaid_amount', true);
							$unpaid_amount = $commission_amount - $paid_amount;
							$total_amount  = $commission_amount;

							// Fix payment method handling - get the actual payment method
							$actual_payment_method = '';
							if (isset($payment_method) && is_array($payment_method)) {
								$actual_payment_method = isset($payment_method[0]) ? $payment_method[0] : '';
							} elseif (isset($payment_method) && is_string($payment_method)) {
								$actual_payment_method = $payment_method;
							}

							if (!empty($actual_payment_method)) {

								if ('stripe' === $actual_payment_method) {
									$stripe_data = get_option('woocommerce_stripe_settings');

									if (empty($stripe_data)) {
										return;
									}

									$test_mode = isset($stripe_data['testmode']) && 'yes' === $stripe_data['testmode'];
									$secret_key = $test_mode ? $stripe_data['test_secret_key'] : $stripe_data['secret_key'];

									if (empty($secret_key)) {
										return;
									}

									$receiver_account_id = get_user_meta($user_id, 'stripe_account_id', true);

									if (empty($receiver_account_id)) {
										return;
									}

									if (!isset($paid_amount) || !is_numeric($paid_amount)) {
										return;
									}

									$response = wp_remote_post('https://api.stripe.com/v1/transfers', array(
										'method'  => 'POST',
										'headers' => array(
											'Authorization' => 'Bearer ' . $secret_key,
											'Content-Type'  => 'application/x-www-form-urlencoded',
										),
										'body'    => array(
											'amount'      => (int) ( $paid_amount * 100 ), // Convert to cents and ensure it's an integer
											'currency'    => 'usd',
											'destination' => $receiver_account_id,
										),
										'timeout' => 60,
									));

									if (is_wp_error($response)) {
										return;
									}

									$response_body = wp_remote_retrieve_body($response);
									$data = json_decode($response_body, true);

									if (!empty($data['error'])) {
										return;
									}

									if (!empty($data['id'])) {
										$transaction_id = sanitize_text_field($data['id']);
										update_post_meta($post_id, 'transaction_id', $transaction_id);
									} else {
										return;
									}
								} else if ('ppcp-gateway' == $actual_payment_method) {
									$bearer_object = json_decode(get_option('_transient_ppcp-paypal-bearerppcp-bearer'));
									if (!$bearer_object || empty($bearer_object->access_token)) {
										return;
									}
									$paypal_common_data = get_option('woocommerce-ppcp-data-common');
									if (!is_array($paypal_common_data) || empty($paypal_common_data['merchant_email']) || empty($paypal_common_data['client_id'])) {
										return;
									}
									$bearer_access_token = $bearer_object->access_token;
									$merchant_email = $paypal_common_data['merchant_email'];
									$client_id = $paypal_common_data['client_id'];
									$use_sandbox = $paypal_common_data['use_sandbox'];
									$receiver_email = get_user_meta($user_id, 'paypal_email', true);
									if (!is_email($receiver_email)) {
										return;
									}
									if ($use_sandbox) {
										$response = wp_remote_post('https://api.sandbox.paypal.com/v1/payments/payouts', array(
											'headers' => array(
												'Content-Type'  => 'application/json',
												'Authorization' => 'Bearer ' . $bearer_access_token,
											),
											'body' => json_encode(array(
												'sender_batch_header' => array(
													'sender_batch_id' => uniqid(),
													'email_subject' => 'You have a payout!',
												),
												'items' => array(
													array(
														'recipient_type' => 'EMAIL',
														'amount' => array(
															'value' => number_format($paid_amount, 2, '.', ''),
															'currency' => 'USD',
														),
														'receiver' => $receiver_email,
														'note' => 'Thanks for your work!',
														'sender_item_id' => $post_id,
													),
												),
											)),
										));
									} else {
										$response = wp_remote_post('https://api.paypal.com/v1/payments/payouts', array(
											'headers' => array(
												'Content-Type'  => 'application/json',
												'Authorization' => 'Bearer ' . $bearer_access_token,
											),
											'body' => json_encode(array(
												'sender_batch_header' => array(
													'sender_batch_id' => uniqid(),
													'email_subject' => 'You have a payout!',
												),
												'items' => array(
													array(
														'recipient_type' => 'EMAIL',
														'amount' => array(
															'value' => number_format($paid_amount, 2, '.', ''),
															'currency' => 'USD',
														),
														'receiver' => $receiver_email,
														'note' => 'Thanks for your work!',
														'sender_item_id' => $post_id,
													),
												),
											)),
										));
									}
									if (is_wp_error($response)) {
										return;
									} else {
										$body = json_decode(wp_remote_retrieve_body($response), true);
										$transaction_id = $body['batch_header']['payout_batch_id'];
									}
								} else {
									continue;
								}
								$affiliates = get_posts(array(
									'post_type'      => 'affiliate_user_post',
									'posts_per_page' => -1,
									'post_status'    => 'publish',
									'author'         => $user_id,
								));
								$paid_commission_check = false;
								foreach ($affiliates as $affiliate) {
									$paid_commission_check = get_post_meta($affiliate->ID, 'notify_paid_commission', true);
									$log = array(
										'transaction_id'       => $transaction_id,
										'method'               => $actual_payment_method,
										'custom_payout_check'  => 'automatic',
										'payout_amount'        => $paid_amount,
									);


									$existing_logs = get_post_meta($affiliate->ID, 'payout_save_log', true);
									if (!is_array($existing_logs)) {
										$existing_logs = array();
									}

									$existing_logs[] = $log;

									$previous_paid = (float) get_post_meta($affiliate->ID, 'payout_save_paid_amount', true);
									$updated_paid = $previous_paid + $paid_amount;
									update_post_meta($affiliate->ID, 'payout_save_log', $existing_logs);
									update_post_meta($affiliate->ID, 'payout_save_paid_amount', $updated_paid);
									update_post_meta($affiliate->ID, 'payout_save_unpaid_amount', $unpaid_amount);
									update_post_meta($affiliate->ID, 'payout_save_total_amount', $total_amount);

									// Add hourly stats logging (same as meta box payout)
									$offset = (float) get_option('gmt_offset');
									$sign   = ( $offset <= 0 ) ? '+' : '-';
									$hours  = abs($offset);
									$wp_timezone = 'Etc/GMT' . $sign . $hours;

									$tz = new DateTimeZone($wp_timezone);
									$now = new DateTime('now', $tz);
									$hour_key = $now->format('Y-m-d H:00'); // Local hour bucket

									$hourly_log = get_post_meta($affiliate->ID, 'hourly_stats', true);
									if (!is_array($hourly_log)) {
										$hourly_log = array();
									}

									if (!isset($hourly_log[ $hour_key ])) {
										$hourly_log[ $hour_key ] = array(
											'clicks'   => 0,
											'paid'     => 0,
											'unpaid'   => 0,
											'earnings' => 0,
											'refunds'  => 0,
										);
									}

									// Add to the paid field
									$hourly_log[ $hour_key ]['paid'] += $paid_amount;

									update_post_meta($affiliate->ID, 'hourly_stats', $hourly_log);
								}

								// Update remaining unpaid amount
								$remaining_unpaid = $commission_amount - $paid_amount;
								update_post_meta($post_id, 'unpaid_amount', $remaining_unpaid);
								update_user_meta($user_id, 'unpaid_amount', $remaining_unpaid);

								// Find and update the corresponding payout_post
								$existing_payouts = get_posts(array(
									'post_type'   => 'payout_post',
									'post_status' => 'any',
									'numberposts' => -1,
								));

								$matching_payout_id = null;
								foreach ($existing_payouts as $payout_post) {
									$payout_affiliate_id = get_post_meta($payout_post->ID, 'affiliate_id', true);
									if ((string) $payout_affiliate_id === (string) $user_id) {
										$matching_payout_id = $payout_post->ID;
										break;
									}
								}

								// Update payout_data in payout_post (critical for dashboard)
								if ($matching_payout_id) {
									$payout_data = get_post_meta($matching_payout_id, 'payout_data', true);
									if (!is_array($payout_data)) {
										$payout_data = array();
									}

									// Append the paid payout entry
									$payout_data[] = array(
										'amount'  => (float) $paid_amount,
										'status'  => 'paid',
										'created' => current_time('mysql'),
									);

									update_post_meta($matching_payout_id, 'payout_data', $payout_data);

									// Update payout status based on remaining unpaid
									if ($remaining_unpaid <= 0) {
										update_post_meta($matching_payout_id, 'payout_status', 'paid');
									} else {
										update_post_meta($matching_payout_id, 'payout_status', 'unpaid');
									}
								}

								// Track the payout date for date-based rules to prevent duplicate payouts
								if ('date' === $rule['payout_type']  && isset($rule['date'])) {
									update_post_meta($post_id, 'last_automatic_payout_date', $rule['date']);
								}

								if ('yes' == $paid_commission_check) {
									$new_form_data = array();
									$get_woo_currency = get_option('woocommerce_currency');
									$new_form_data = array(
										'affiliate_id'      => $user_id,
										'paid_amount'     => $get_woo_currency . ' ' . $paid_amount,
										'User_name'         => $username,
										'User_email'        => $user_email,
									);
									// Call your custom WooCommerce email notification
									$mailer = WC()->mailer();
									$email  = $mailer->emails['Addify_Ad_Pr_Affiliate_Paid_Commission_Email'];
									if ($email) {
										$email->trigger($new_form_data);
									}
								}
							}
						}
					}
				}
			}
		}
	}

	new Addify_Affiliate_Program();
}
