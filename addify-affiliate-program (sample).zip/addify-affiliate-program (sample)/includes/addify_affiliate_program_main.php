<?php

if (!defined('ABSPATH')) {
	exit();
}

if (!class_exists('Addify_Affiliate_Program_Main')) {
	class Addify_Affiliate_Program_Main {
	






		public function addify_affiliate_user_post_custom_columns( $columns ) {
			$new_columns = array();

			foreach ($columns as $key => $value) {
				if ('date' === $key) {
					continue;
				}
				if ('title' === $key) {
					$new_columns[ $key ] = esc_html__('Name', 'addify-affiliate-program');
					$new_columns['total_earning'] = esc_html__('Total Earnings', 'addify-affiliate-program');
					$new_columns['paid_earning'] = esc_html__('Paid Earnings', 'addify-affiliate-program');
					$new_columns['unpaid_earning'] = esc_html__('Unpaid Earnings', 'addify-affiliate-program');
					$new_columns['commission'] = esc_html__('Commission', 'addify-affiliate-program');
					$new_columns['status'] = esc_html__('Status', 'addify-affiliate-program');
					$new_columns['registration_date'] = esc_html__('Date', 'addify-affiliate-program'); //  Custom Date column
				} else {
					$new_columns[ $key ] = $value;
				}
			}
			return $new_columns;
		}
		// Populate custom columns
		public function addify_affiliate_user_post_column_content( $column, $post_id ) {
			$post_obj = get_post($post_id);
			$user_id = get_post_meta($post_id, 'user_ID', true);

			if (empty($user_id)) {
				$user_id = $post_obj->post_author;
			}

			$user_meta = $user_id ? get_user_meta($user_id) : array();

			$total_amount = 0;
			$paid_amount = 0;
			$unpaid_amount = 0;
			$number_of_commission_earned = 0;

			// ✅ Unpaid amount
			$payout_posts = get_posts(array(
				'post_type'      => 'payout_post',
				'posts_per_page' => -1,
				'post_status'    => 'publish',
				'fields'         => 'ids',
			));

			foreach ($payout_posts as $payout_post_id) {
				$payout_post_title = get_the_title($payout_post_id);
				if ($payout_post_title == $user_id && '' !== get_post_meta($payout_post_id, 'unpaid_amount', true)) {
					$unpaid_amount = floatval(get_post_meta($payout_post_id, 'unpaid_amount', true));
				}
			}

			// ✅ Paid amount
			if ('' !== get_post_meta($post_id, 'payout_save_paid_amount', true)) {
				$paid_amount = floatval(get_post_meta($post_id, 'payout_save_paid_amount', true));
			}

			// ✅ Commission count
			$commission_posts = get_posts(array(
				'post_type'      => 'commission_post',
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
			));

			foreach ($commission_posts as $commission_post_id) {
				$affiliate_id = get_post_meta($commission_post_id, 'affiliate_id', true);
				if ($affiliate_id == $user_id) {
					$number_of_commission_earned++;
				}
			}

			// ✅ Column output
			switch ($column) {
				case 'total_earning':
					$total_amount = get_post_meta($post_id, 'total_earning_amount', true);
					echo wp_kses_post(wc_price($total_amount));
					break;

				case 'paid_earning':
					echo wp_kses_post(wc_price($paid_amount));
					break;

				case 'unpaid_earning':
					echo wp_kses_post(wc_price($unpaid_amount));
					break;

				case 'commission':
					echo esc_html($number_of_commission_earned);
					break;

				case 'status':
					$status = isset($user_meta['affiliate_user_status'][0])
						? $user_meta['affiliate_user_status'][0]
						: 'pending';
					echo esc_html($status);
					break;

				case 'registration_date':
					$post_time = get_post_time('U', false, $post_id);
					echo esc_html__('Register Date', 'addify-affiliate-program'), '<br>';
					echo esc_html(date_i18n('Y/m/d \a\t g:i a', $post_time));
					break;
			}
		}

		// Add custom columns to 'rule_setting_tab'
		public function addify_rule_setting_tab_custom_columns( $columns ) {
			$new_columns = array();

			foreach ($columns as $key => $value) {
				if ('title' === $key) {
					$new_columns[ $key ] = esc_html__('Title', 'addify-affiliate-program');
					$new_columns['commission_rate'] = esc_html__('Commission Rate', 'addify-affiliate-program');
					$new_columns['expiry_date'] = esc_html__('Expiry Date', 'addify-affiliate-program');
				} else {
					$new_columns[ $key ] = $value;
				}
			}
			return $new_columns;
		}
		// Populate custom columns
		public function addify_rule_setting_tab_column_content( $column, $post_id ) {
			switch ($column) {
				case 'commission_rate':
					$commission_type = get_post_meta($post_id, 'Addify_Af_Pr_rule_commission_rate_type', true);
					if ('fixed' === $commission_type) {
						$commission_rate = get_post_meta($post_id, 'Addify_Af_Pr_rule_commission_rate_value', true);
						echo wp_kses_post(wc_price($commission_rate));
					} else {
						$commission_rate = get_post_meta($post_id, 'Addify_Af_Pr_rule_commission_rate_value', true);
						echo esc_html($commission_rate) . ' %';
					}
					break;
				case 'expiry_date':
					$date = get_post_meta($post_id, 'Addify_Af_Pr_rule_expiry_date', true);
					if (empty($date)) {
						echo esc_html__('No date set', 'addify-affiliate-program');
					} else {
						echo esc_html($date);
					}
					break;
			}
		}
		// Add custom columns to 'payout_post'
		public function addify_payout_post_custom_columns( $columns ) {
			$new_columns = array();

			foreach ($columns as $key => $value) {
				if ('date' === $key) {
					continue;
				}
				// Change 'title' to 'User ID'
				if ('title' === $key) {
					$new_columns[ $key ] = esc_html__('User ID', 'addify-affiliate-program');
					$new_columns['username'] = esc_html__('Username', 'addify-affiliate-program');
					$new_columns['payout_amount'] = esc_html__('To Be Paid', 'addify-affiliate-program');
					$new_columns['paid_amount'] = esc_html__('Paid Amount', 'addify-affiliate-program');
					$new_columns['registration_date'] = esc_html__('Date', 'addify-affiliate-program'); //  Custom Date column

				} else {
					$new_columns[ $key ] = $value;
				}
			}
			return $new_columns;
		}
		// Populate custom columns
		public function addify_payout_post_column_content( $column, $post_id ) {
			$affiliate_id = get_post_meta($post_id, 'affiliate_id', true);
			$affiliates = get_posts(array(
				'post_type'      => 'affiliate_user_post',
				'posts_per_page' => -1,
				'post_status'    => 'publish',
				'author' => $affiliate_id,
			));
			switch ($column) {
				case 'registration_date':
					$post_time = get_post_time('U', false, $post_id);
					echo esc_html(date_i18n('Y/m/d \a\t g:i a', $post_time));
					break;
				case 'paid_amount':
					$paid_amount = get_post_meta($affiliates[0]->ID, 'payout_save_paid_amount', true);
					echo wp_kses_post(wc_price($paid_amount));
					break;

				case 'payout_amount':
					$amount = get_post_meta($post_id, 'unpaid_amount', true);
					echo wp_kses_post(wc_price($amount));
					break;


				case 'username':
					$username = get_post_meta($post_id, 'user_name', true);

					if (!empty($affiliates) && isset($affiliates[0]->ID)) {
						$edit_link = get_edit_post_link($affiliates[0]->ID);
						echo '<a href="' . esc_url($edit_link) . '">' . esc_html($username) . '</a>';
					} else {
						echo esc_html($username);
					}
					break;

				case 'title':
					$title = get_post_meta($post_id, 'affiliate_id', true);
					echo esc_html($title);
					break;
			}
		}
		// Add custom columns to 'commission_post'
		public function addify_commission_post_custom_columns( $columns ) {
			$new_columns = array();

			foreach ($columns as $key => $value) {
				// Change 'title' to 'User ID'
				if ('title' === $key) {
					$new_columns[ $key ] = esc_html__('User ID', 'addify-affiliate-program');
					$new_columns['username'] = esc_html__('Username', 'addify-affiliate-program');
					$new_columns['order_id'] = esc_html__('Order ID', 'addify-affiliate-program');
					$new_columns['affiliation_type'] = esc_html__('Type', 'addify-affiliate-program');
					$new_columns['product_name'] = esc_html__('Products', 'addify-affiliate-program');
					$new_columns['total_product_amount'] = esc_html__('Total', 'addify-affiliate-program');
					$new_columns['rate'] = esc_html__('Commission Rate', 'addify-affiliate-program');
					$new_columns['amount'] = esc_html__('Commission Earned', 'addify-affiliate-program');
					$new_columns['status'] = esc_html__('Refunded Status', 'addify-affiliate-program');
					$new_columns['date'] = esc_html__('Date', 'addify-affiliate-program');
				} else {
					$new_columns[ $key ] = $value;
				}
			}
			return $new_columns;
		}
		// Populate custom columns
		public function addify_commission_post_column_content( $column, $post_id ) {

			switch ($column) {
				case 'username':
					$username = get_post_meta($post_id, 'user_name', true);
					echo esc_html($username);
					break;
				case 'order_id':
					$order_id = get_post_meta($post_id, 'order_id', true);
					echo esc_html($order_id);
					break;
				case 'affiliation_type':
					$affiliation_type = get_post_meta($post_id, 'affiliation_type', true);
					if ('Product' == $affiliation_type) {
						echo esc_html__('Product', 'addify-affiliate-program');
					} else {
						echo esc_html__('Coupon', 'addify-affiliate-program');
					}
					break;
				case 'product_name':
					$product_name = get_post_meta($post_id, 'product_name', true);
					if ('' !== $product_name) {
						echo esc_html($product_name);
					} else {
						echo esc_html__('No Product', 'addify-affiliate-program');
					}
					break;
				case 'total_product_amount':
					$total_product_amount = get_post_meta($post_id, 'total_product_amount', true);
					echo wp_kses_post(wc_price($total_product_amount));
					break;
				case 'amount':
					$amount = get_post_meta($post_id, 'unpaid_amount', true);
					echo wp_kses_post(wc_price($amount));
					break;
				case 'rate':
					$commission_type = get_post_meta($post_id, 'commission_type', true);
					if ('fixed' === $commission_type) {
						$commission_rate = get_post_meta($post_id, 'commission_rate', true);
						echo wp_kses_post(wc_price($commission_rate));
					} else {
						$commission_rate = get_post_meta($post_id, 'commission_rate', true);
						echo esc_html($commission_rate) . ' %';
					}
					break;
				case 'status':
					$status = get_post_meta($post_id, 'commission_status', true);
					if ('refunded' == $status) {
						$status = esc_html__('Refunded', 'addify-affiliate-program');
					} else {
						$status = esc_html__('Non Refunded', 'addify-affiliate-program');
					}
					echo wp_kses_post($status);
					break;
				case 'date':
					$date = get_post_meta($post_id, 'date', true);
					echo esc_html($date);
					break;
			}
		}
		public function register_post_types() {
			// Post Type 1: Rule Settings
			$rule_labels = array(
				'name' => esc_html__('Campaigns', 'addify-affiliate-program'),
				'singular_name' => esc_html__('Campaigns', 'addify-affiliate-program'),
				'add_new' => esc_html__('Add New Campaigns', 'addify-affiliate-program'),
				'add_new_item' => esc_html__('Add Campaigns', 'addify-affiliate-program'),
				'edit_item' => esc_html__('Edit Campaigns', 'addify-affiliate-program'),
				'new_item' => esc_html__('New Campaigns', 'addify-affiliate-program'),
				'view_item' => esc_html__('View Campaigns', 'addify-affiliate-program'),
				'search_items' => esc_html__('Search Campaigns', 'addify-affiliate-program'),
				'not_found' => esc_html__('No campaigns found', 'addify-affiliate-program'),
				'not_found_in_trash' => esc_html__('No campaigns found in trash', 'addify-affiliate-program'),
				'menu_name' => esc_html__('Affiliate', 'addify-affiliate-program'),
			);
			$rule_args = array(
				'labels' => $rule_labels,
				'public' => false,
				'publicly_queryable' => false,
				'show_ui' => true,
				'show_in_menu' => 'woocommerce',
				'query_var' => true,
				'capability_type' => 'post',
				'has_archive' => false,
				'hierarchical' => false,
				'supports' => array( 'title', 'page-attributes' ),
				'rewrite' => false,
			);

			register_post_type('rule_setting_tab', $rule_args);
			$user_labels = array(
				'name' => esc_html__('Affiliate Users', 'addify-affiliate-program'),
				'singular_name' => esc_html__('Affiliate User', 'addify-affiliate-program'),
				'add_new' => esc_html__('Add New User', 'addify-affiliate-program'),
				'add_new_item' => esc_html__('Add User', 'addify-affiliate-program'),
				'edit_item' => esc_html__('Edit User', 'addify-affiliate-program'),
				'new_item' => esc_html__('New User', 'addify-affiliate-program'),
				'view_item' => esc_html__('View User', 'addify-affiliate-program'),
				'search_items' => esc_html__('Search Users', 'addify-affiliate-program'),
				'not_found' => esc_html__('No users found', 'addify-affiliate-program'),
				'not_found_in_trash' => esc_html__('No users found in trash', 'addify-affiliate-program'),
				'menu_name' => esc_html__('Affiliate', 'addify-affiliate-program'),
			);

			$user_args = array(
				'labels' => $user_labels,
				'public' => false,
				'publicly_queryable' => false,
				'show_ui' => true,
				'show_in_menu' => 'woocommerce',
				'query_var' => true,
				'capability_type' => 'post',
				'has_archive' => false,
				'hierarchical' => false,
				'supports' => array( 'title' ),
				'rewrite' => false,
			);

			register_post_type('affiliate_user_post', $user_args);
			// Post Type 3: Payout Post
			$payout_labels = array(
				'name' => esc_html__('Payouts', 'addify-affiliate-program'),
				'singular_name' => esc_html__('Payout Plan', 'addify-affiliate-program'),
				'add_new' => esc_html__('Add New Payout', 'addify-affiliate-program'),
				'add_new_item' => esc_html__('Add Payout', 'addify-affiliate-program'),
				'edit_item' => esc_html__('Edit Payout', 'addify-affiliate-program'),
				'new_item' => esc_html__('New Payout', 'addify-affiliate-program'),
				'view_item' => esc_html__('View Payout', 'addify-affiliate-program'),
				'search_items' => esc_html__('Search Payout', 'addify-affiliate-program'),
				'not_found' => esc_html__('No payout found', 'addify-affiliate-program'),
				'not_found_in_trash' => esc_html__('No payout found in trash', 'addify-affiliate-program'),
				'menu_name' => esc_html__('Affiliate', 'addify-affiliate-program'),
			);
			$payout_args = array(
				'labels' => $payout_labels,
				'public' => false,
				'publicly_queryable' => false,
				'show_ui' => true,
				'show_in_menu' => 'woocommerce',
				'query_var' => true,
				'capability_type' => 'post',
				'capabilities' => array(
					'create_posts' => 'do_not_allow', // Remove "Add New"
					'delete_posts' => 'delete_commissions', // Custom capability
					'delete_others_posts' => 'delete_others_commissions',
					'delete_private_posts' => 'delete_private_commissions',
					'delete_published_posts' => 'delete_published_commissions',
				),
				'map_meta_cap' => true,
				'has_archive' => false,
				'hierarchical' => false,
				'supports' => array( 'title' ),
				'rewrite' => false,
			);

			register_post_type('payout_post', $payout_args);
			// Post Type 4: Commission Post
			$commission_labels = array(
				'name' => esc_html__('Commissions', 'addify-affiliate-program'),
				'singular_name' => esc_html__('Commission Plan', 'addify-affiliate-program'),
				'add_new' => esc_html__('Add New Commission', 'addify-affiliate-program'),
				'add_new_item' => esc_html__('Add Commission', 'addify-affiliate-program'),
				'edit_item' => esc_html__('Edit Commission', 'addify-affiliate-program'),
				'new_item' => esc_html__('New Commission', 'addify-affiliate-program'),
				'view_item' => esc_html__('View Commission', 'addify-affiliate-program'),
				'search_items' => esc_html__('Search Commission', 'addify-affiliate-program'),
				'not_found' => esc_html__('No commission found', 'addify-affiliate-program'),
				'not_found_in_trash' => esc_html__('No commission found in trash', 'addify-affiliate-program'),
				'menu_name' => esc_html__('Affiliate', 'addify-affiliate-program'),
			);

			$commission_args = array(
				'labels' => $commission_labels,
				'public' => false,
				'publicly_queryable' => false,
				'show_ui' => true,
				'show_in_menu' => 'woocommerce',
				'query_var' => true,
				'capability_type' => 'post',
				'capabilities' => array(
					'create_posts' => 'do_not_allow', // Remove "Add New"
					'delete_posts' => 'delete_commissions', // Custom capability
					'delete_others_posts' => 'delete_others_commissions',
					'delete_private_posts' => 'delete_private_commissions',
					'delete_published_posts' => 'delete_published_commissions',
				),
				'map_meta_cap' => true,
				'has_archive' => false,
				'hierarchical' => false,
				'supports' => array( 'title' ),
				'rewrite' => false,
			);

			register_post_type('commission_post', $commission_args);

			//post type 5: registration field post
			$registration_labels = array(
				'name' => esc_html__('Registration Fields', 'addify-affiliate-program'),
				'singular_name' => esc_html__('Registration Field', 'addify-affiliate-program'),
				'add_new' => esc_html__('Add New Field', 'addify-affiliate-program'),
				'add_new_item' => esc_html__('Add Field', 'addify-affiliate-program'),
				'edit_item' => esc_html__('Edit Field', 'addify-affiliate-program'),
				'new_item' => esc_html__('New Field', 'addify-affiliate-program'),
				'view_item' => esc_html__('View Field', 'addify-affiliate-program'),
				'search_items' => esc_html__('Search Registration Fields', 'addify-affiliate-program'),
				'not_found' => esc_html__('No registration fields found', 'addify-affiliate-program'),
				'not_found_in_trash' => esc_html__('No registration fields found in trash', 'addify-affiliate-program'),
				'menu_name' => esc_html__('Affiliate', 'addify-affiliate-program'),
			);
			$registration_args = array(
				'labels' => $registration_labels,
				'public' => false,
				'publicly_queryable' => false,
				'show_ui' => true,
				'show_in_menu' => 'woocommerce',
				'query_var' => true,
				'capability_type' => 'post',
				'map_meta_cap' => true,
				'has_archive' => false,
				'hierarchical' => false,
				'supports' => array( 'title' ),
				'rewrite' => false,
			);
			register_post_type('registration_post', $registration_args);
		}

		public function addify_create_default_registration_fields() {

			$default_fields = array(
				'first_name' => array(
					'label'       => 'First Name',
					'type'        => 'text',
					'placeholder' => 'Type here…',
				),
				'last_name' => array(
					'label'       => 'Last Name',
					'type'        => 'text',
					'placeholder' => 'Type here…',
				),
				'email' => array(
					'label'       => 'Email',
					'type'        => 'email',
					'placeholder' => 'abc@xyz.com',
				),
			);

			// Get all existing registration posts
			$existing_posts = get_posts(array(
				'post_type'      => 'registration_post',
				'posts_per_page' => -1,
				'fields'         => 'ids',
			));

			$existing_keys = array();

			foreach ($existing_posts as $post_id) {
				$key = get_post_meta($post_id, 'field_key', true);
				if (false === empty($key)) {
					$existing_keys[] = $key;
				}
			}

			foreach ($default_fields as $field_key => $data) {

				if (false === in_array($field_key, $existing_keys, true)) {

					$post_id = wp_insert_post(array(
						'post_type'   => 'registration_post',
						'post_title'  => $data['label'],
						'post_status' => 'publish',
					));

					if (0 !== $post_id && false === is_wp_error($post_id)) {
						add_post_meta($post_id, 'field_key', $field_key);
						add_post_meta($post_id, 'unchangeable', '1');
						add_post_meta($post_id, 'not_selectable', '1');
						add_post_meta($post_id, 'Addify_Af_Pr_field_label', $data['label']);
						add_post_meta($post_id, 'Addify_Af_Pr_field_type', $data['type']);
						add_post_meta($post_id, 'Addify_Af_Pr_field_placeholder', $data['placeholder']);
						add_post_meta($post_id, 'Addify_Af_Pr_field_status', 'active');
						add_post_meta($post_id, 'Addify_Af_Pr_field_required', 'no');
					}
				}
			}
		}
	}
	new Addify_Affiliate_Program_Main();
}
