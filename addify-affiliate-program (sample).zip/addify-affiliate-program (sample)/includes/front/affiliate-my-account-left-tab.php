<?php

if (!defined('ABSPATH')) {
	exit();
}

if (!class_exists('Addify_Affiliate_My_Account_Left_Tab')) :
	class Addify_Affiliate_My_Account_Left_Tab {
	



	

		public function handle_affiliate_form_submission() {
			if (
				isset($_SERVER['REQUEST_METHOD']) &&
				'POST' === sanitize_text_field(wp_unslash($_SERVER['REQUEST_METHOD']))
				&& isset($_POST['addify_request_nonce'])
				&& wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['addify_request_nonce'])), 'addify_form_request_withdrawal_action')
			) {
				$new_form_data = array();
				$new_form_data = array(
					'affiliate_id'      => isset($_POST['affiliate_id']) ? sanitize_text_field(wp_unslash($_POST['affiliate_id'])) : '',
					'unpaid_amount'     => isset($_POST['unpaid_amount']) ? sanitize_text_field(wp_unslash($_POST['unpaid_amount'])) : '',
					'User_name'         => isset($_POST['user_name']) ? sanitize_text_field(wp_unslash($_POST['user_name'])) : '',
					'User_email'        => isset($_POST['user_email']) ? sanitize_text_field(wp_unslash($_POST['user_email'])) : '',
				);
				// Call your custom WooCommerce email notification
				$mailer = WC()->mailer();
				$email  = $mailer->emails['Addify_Ad_Pr_Affiliate_Withdrawal_Email'];
				if ($email) {
					$email->trigger($new_form_data);
				}
				wc_clear_notices();
				wc_add_notice(esc_html__('Request for withdrawal sent.', 'addify-affiliate-program'), 'success');
				wp_safe_redirect(wc_get_account_endpoint_url('affiliate-account-settings'));
				exit;
			}
			if (
				'POST' === $_SERVER['REQUEST_METHOD']
				&& isset($_POST['affiliate_account_nonce'])
				&& wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['affiliate_account_nonce'])), 'save_affiliate_account_info')
			) {

				$user_id = get_current_user_id();

				// Save withdrawal info if set
				if (isset($_POST['stripe_account_id'])) {
					update_user_meta($user_id, 'stripe_account_id', sanitize_text_field(wp_unslash($_POST['stripe_account_id'])));
				}
				if (isset($_POST['paypal_email'])) {
					update_user_meta($user_id, 'paypal_email', sanitize_email(wp_unslash($_POST['paypal_email'])));
				}
				if (empty($_POST['stripe_account_id']) && empty($_POST['paypal_email'])) {
					wc_clear_notices();
					wc_add_notice(esc_html__('Payment info empty.', 'addify-affiliate-program'), 'notice');
					wp_safe_redirect(wc_get_account_endpoint_url('affiliate-account-settings'));
					exit;
				}
				wc_clear_notices();
				wc_add_notice(esc_html__('Payment info updated successfully.', 'addify-affiliate-program'), 'success');
				wp_safe_redirect(wc_get_account_endpoint_url('affiliate-account-settings'));
				exit;
			}
			if (
				isset($_POST['addify_af_pr_register']) &&
				isset($_POST['addify_af_pr_nonce']) &&
				wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['addify_af_pr_nonce'])), 'addify_af_pr_register_action')
			) {
				$user_id = get_current_user_id();
				$data = get_user_meta($user_id);
				$user = get_user_by('id', $user_id);
				$affiliate_user_status = isset($data['affiliate_user_status']) ? $data['affiliate_user_status'][0] : '';

				// If already applied but not approved, stop
				if (!empty($affiliate_user_status) && 'approved' !== $affiliate_user_status) {
					$submitted_before = get_user_meta($user_id, 'affiliate_request_submitted', true);
					if ($submitted_before) {
						wc_clear_notices();
						wc_add_notice(
							esc_html__('Your affiliation request is already being processed.', 'addify-affiliate-program'),
							'notice'
						);
						wp_safe_redirect(wc_get_account_endpoint_url('affiliate-account-settings'));
						exit;
					}
				}

				// Check if affiliate post already exists for this user
				$existing_affiliate = get_posts(array(
					'post_type'   => 'affiliate_user_post',
					'author'      => $user_id,
					'post_status' => 'publish',
					'fields'      => 'ids',
					'numberposts' => 1,
				));

				if ($existing_affiliate) {
					wc_clear_notices();
					wc_add_notice(
						esc_html__('You are already registered as an affiliate.', 'addify-affiliate-program'),
						'notice'
					);
					wp_safe_redirect(wc_get_account_endpoint_url('affiliate-account-settings'));
					exit;
				}

				// Mark request submitted
				update_user_meta($user_id, 'affiliate_request_submitted', true);

				// Create new affiliate post
				$affiliate_post = array(
					'post_title'   => $user->user_login,
					'post_status'  => 'publish',
					'post_type'    => 'affiliate_user_post',
					'post_author'  => $user_id,
				);

				$post_id = wp_insert_post($affiliate_post);

				$user_default_status = get_option('Addify_Af_Pr_affiliate_setting_default_status');
				$auto_manual_enable  = get_option('Addify_Af_Pr_affiliate_setting_enable_auto_manual');

				if ($post_id) {
					// Update status
					if ('yes' === $auto_manual_enable) {
						update_user_meta($user_id, 'affiliate_user_status', 'approved');
						$user_status = 'approved';
					} else {
						$user_status = !empty($user_default_status[0]) ? $user_default_status[0] : 'pending';
						update_user_meta($user_id, 'affiliate_user_status', $user_status);
					}

					// Assign role
					$user_obj = new WP_User($user_id);
					$userRoles = $user_obj->roles;
					if ('approved' === $user_status) {
						if (!in_array('adf_affiliate', (array) $userRoles, true)) {
							$user_obj->add_role('adf_affiliate');
						}
					} else {
						$user_obj->remove_role('adf_affiliate');
					}

					// Send email
					$new_affiliation_check = get_option('Addify_Af_Pr_affiliate_setting_enable_new_affiliation_email');
					if ('yes' === $new_affiliation_check) {
						$new_form_data = array(
							'affiliate_id' => $user_id,
							'User_name'    => $user->data->user_login,
							'User_email'   => $user->data->user_email,
						);

						$mailer = WC()->mailer();
						$email  = isset($mailer->emails['Addify_Ad_Pr_Affiliate_New_Email']) ? $mailer->emails['Addify_Ad_Pr_Affiliate_New_Email'] : false;
						if ($email) {
							$email->trigger($new_form_data);
						}
					}
				}

				// Process extra registration fields
				$args_posts = array(
					'post_type'      => 'registration_post',
					'orderby'        => 'menu_order',
					'order'          => 'DESC',
					'posts_per_page' => -1,
				);

				$query = new WP_Query($args_posts);
				$count = 0;

				if ($query->have_posts()) {
					while ($query->have_posts()) {
						$query->the_post();
						$post_id = get_the_ID();

						$label  = get_post_meta($post_id, 'Addify_Af_Pr_field_label', true);
						$type   = get_post_meta($post_id, 'Addify_Af_Pr_field_type', true);
						$status = get_post_meta($post_id, 'Addify_Af_Pr_field_status', true);

						if ('active' !== $status || empty($label)) {
							continue;
						}

						$field_id       = 'reg_' . sanitize_title($type) . '_' . $count;
						$field_id_label = $field_id . '_label';

						if ('checkbox' === $type) {
							$value = isset($_POST[ $field_id ]) ? 1 : 0;
						} else {
							$value = isset($_POST[ $field_id ]) ? sanitize_text_field(wp_unslash($_POST[ $field_id ])) : '';
						}

						update_user_meta($user_id, $field_id_label, sanitize_text_field($label));
						update_user_meta($user_id, $field_id, $value);

						++$count;
					}
					wp_reset_postdata();
				}

				wp_safe_redirect(wc_get_account_endpoint_url('affiliate-account-settings'));
				exit;
			}
		}


		public function addify_af_pr_add_link_my_content() {
			// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
			$account_menu_items = apply_filters('woocommerce_account_menu_items', array());
			if (!array_key_exists('affiliate-account-settings', $account_menu_items)) {
				return;
			}
			$user_id = get_current_user_id();

			$user_meta = get_user_meta($user_id);
			$user_remote_address = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';
			update_user_meta($user_id, 'user_remote_address', $user_remote_address);
			// $unpaid_amount_user_meta = get_user_meta($user_id, 'unpaid_amount', true);
			$user = get_user_by('id', $user_id);
			$user_name = $user->user_login;
			$user_email = $user->user_email;
			$user_role = $user->roles;
			$user_role = isset($user_role) ? $user_role : '';
			$submitted_before = false;
			$selected = 0;
			$args_check = array(
				'post_type'      => 'registration_post',
				'posts_per_page' => -1,
			);
			$check_query = new WP_Query($args_check);
			$count = 0;
			if ($check_query->have_posts()) {
				while ($check_query->have_posts()) {
					$check_query->the_post();
					$post_id = get_the_ID();
					$type = get_post_meta(get_the_ID(), 'Addify_Af_Pr_field_type', true);

					if (!empty($type)) {

						$field_id = 'reg_' . sanitize_title($type) . '_' . $count;

						$saved_value = get_user_meta($user_id, $field_id, true);
						if (!empty($saved_value)) {
							$submitted_before = true;
							break;
						}
					}
					++$count;
				}
				wp_reset_postdata();
			} else {
				echo '<div class="woocommerce-MyAccount-content" style="float: left;">';
				// translators: %s: Minimum earning amount, formatted as price.
				wc_print_notice(sprintf(esc_html__('There are no registration form yet.', 'addify-affiliate-program')), 'notice');
				echo '</div>';
				return;
			}


			$affiliate_user_status = isset($user_meta['affiliate_user_status']) ? $user_meta['affiliate_user_status'][0] : '';

			$Addify_Af_Pr_specific_affiliate_restrict = get_option('Addify_Af_Pr_specific_affiliate_restrict');
			$Addify_Af_Pr_affiliate_setting_restriction_message = get_option('Addify_Af_Pr_affiliate_setting_restriction_message');
			if (empty($Addify_Af_Pr_affiliate_setting_restriction_message)) {
				$Addify_Af_Pr_affiliate_setting_restriction_message = esc_html__('You have been restricted by admin.', 'addify-affiliate-program');
			}
			$affiliates = get_posts(array(
				'post_type'      => 'affiliate_user_post',
				'posts_per_page' => -1,
				'post_status'    => 'publish',
			));

			$selected_affiliate_data = array();
			foreach ($affiliates as $affiliate) {
				$meta_user_id = get_post_meta($affiliate->ID, 'user_ID', true);
				if ('' !== $meta_user_id) {
					if ($meta_user_id == $user_id) {
						$selected_affiliate_data[] = $affiliate;
					}
				} elseif ($affiliate->post_author == $user_id) {
					$selected_affiliate_data[] = $affiliate;
				}
			}

			if (!empty($affiliates)) {
				foreach ($affiliates as $affiliate) {
					$selected = in_array($user_id, (array) $Addify_Af_Pr_specific_affiliate_restrict);
				}
			}
			foreach ($selected_affiliate_data as $affiliate) {

				if (!empty($affiliate_user_status) && 'approved' == $affiliate_user_status && false == $selected) {

					$expiry_in_days = get_option('Addify_Af_Pr_affiliate_setting_referral_cookie_expiry_time');
					$affiliate_user_status = isset($user_meta['affiliate_user_status'][0]) ? $user_meta['affiliate_user_status'][0] : '';
					$paypal_email      = isset($user_meta['paypal_email'][0]) ? $user_meta['paypal_email'][0] : '';
					$stripe_account_id = isset($user_meta['stripe_account_id'][0]) ? $user_meta['stripe_account_id'][0] : '';
					$min_earning       = isset($user_meta['min_earning'][0]) ? $user_meta['min_earning'][0] : '';
					$max_earning       = isset($user_meta['max_earning'][0]) ? $user_meta['max_earning'][0] : '';
					$withdrawal_limit  = isset($user_meta['withdrawal_limit'][0]) ? $user_meta['withdrawal_limit'][0] : '';
					$affiliate_commission_rate = get_post_meta($affiliate->ID, 'Addify_Af_Pr_affiliate_commission_rate', true);
					$affiliate_commission_rate_type = get_post_meta($affiliate->ID, 'affiliate_commission_rate_type', true);
					if ('' == $affiliate_commission_rate) {
						$affiliate_commission_rate = 0;
					}
					if ('' == $affiliate_commission_rate_type) {
						$affiliate_commission_rate_type = 'fixed';
					}
					$total_amount = (float) 0;
					$paid_amount = (float) 0;
					$unpaid_amount = (float) 0;
					$total_refunded = (float) 0;
					$orders = wc_get_orders(array(
						'limit'  => -1,  // Fetch all orders (adjust if necessary)
						'status' => array( 'refunded' ),
					));
					foreach ($orders as $order) {
						$order              = wc_get_order($order->get_id());
						foreach ($order->get_items() as $item_id => $item) {
							$item_product_id = (int) $item->get_product_id();
							$affiliate_data = $order->get_meta('affiliate_order_data', true);
							if (!empty($affiliate_data) && is_array($affiliate_data)) {
								foreach ($affiliate_data as $data) {
									if (
										isset($data['affiliate_id'], $data['product_id']) &&
										$item_product_id == $data['product_id'] &&
										$user_id == $data['affiliate_id']
									) {
										++$total_refunded;
									}
								}
							}
						}
					}
					$payout_post = get_posts(array(
						'post_type'      => 'payout_post',
						'posts_per_page' => -1,
						'post_status'    => 'publish',
					));

					foreach ($payout_post as $key => $value) {
						$payout_post_id = $value->ID;
						$payout_post_title = $value->post_title;
						if ($payout_post_title == $user_id && '' !== get_post_meta($payout_post_id, 'unpaid_amount', true)) {
							$unpaid_amount = get_post_meta($payout_post_id, 'unpaid_amount', true);
						}
					}
					if ('' !== get_post_meta($affiliate->ID, 'payout_save_paid_amount', true)) {
						$paid_amount = get_post_meta($affiliate->ID, 'payout_save_paid_amount', true);
					}

					$Addify_Af_Pr_affiliate_setting_price_adjustment_table = get_option('Addify_Af_Pr_affiliate_setting_price_adjustment_table', array());

					$total_amount = $unpaid_amount + $paid_amount;


					if (!empty(get_post_meta($affiliate->ID, 'total_clicks', true))) {
						$total_clicks = get_post_meta($affiliate->ID, 'total_clicks', true);
					} else {
						$total_clicks = 0;
					}



					$all_commission_posts = get_posts(array(
						'post_type'   => 'commission_post',
						'post_status' => 'any',
						'posts_per_page' => -1,
					));

					$number_of_commission_earned = 0; // To store the number of commissions earned by the user

					foreach ($all_commission_posts as $post) {
						// Get the affiliate_id from the post meta
						$affiliate_id = get_post_meta($post->ID, 'affiliate_id', true);

						// Check if the affiliate_id matches the user_id
						if ($affiliate_id == $user_id) {
							// Increment the count or do something with the matching commission post
							$number_of_commission_earned++;
						}
					}

					?>
					<?php
					if (!empty($min_earning) && 0 !== $min_earning  && $total_amount < $min_earning) {
						echo '<div class="woocommerce-MyAccount-content" style="float: left;">';
						// translators: %s: Minimum earning amount, formatted as price.
						wc_print_notice(sprintf(esc_html__('You\'ll be able to request a payment as soon as you collect a minimum of %s and therefore cannot request for withdrawal.', 'addify-affiliate-program'), wc_price($min_earning)), 'notice');
						echo '</div>';
					} else if (!empty($max_earning) && 0 !== $max_earning  && $total_amount > $max_earning) {
						echo '<div class="woocommerce-MyAccount-content" style="float: left;">';
						// translators: %s: Maximum earning limit amount, formatted as price.
						wc_print_notice(sprintf(esc_html__('You have reached the maximum earning limit of %s and therefore cannot request for withdrawal.', 'addify-affiliate-program'), wc_price($max_earning)), 'notice');
						echo '</div>';
					} else if (!empty($withdrawal_limit) && 0 !== $withdrawal_limit  && $paid_amount >= $withdrawal_limit) {
						echo '<div class="woocommerce-MyAccount-content" style="float: left;">';
						// translators: %s: Maximum withdrawal limit amount, formatted as price.
						wc_print_notice(sprintf(esc_html__('You have reached the maximum withdrawal limit of %s and therefore cannot request for withdrawal.', 'addify-affiliate-program'), wc_price($withdrawal_limit)), 'notice');
						echo '</div>';
					}
					$tab_get_account = filter_input(INPUT_GET, 'tab', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
					$commissions_page_get_account = filter_input(INPUT_GET, 'commissions_page', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
					$campaigns_page_get_account = filter_input(INPUT_GET, 'campaigns_page', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
					$payouts_page_get_account = filter_input(INPUT_GET, 'payouts_page', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
					$active_tab = isset($tab_get_account) ? sanitize_text_field($tab_get_account) : 'dashboard';
					$commissions_paged = isset($commissions_page_get_account) ? max(1, intval($commissions_page_get_account)) : 1;
					$campaigns_paged   = isset($campaigns_page_get_account) ? max(1, intval($campaigns_page_get_account)) : 1;
					$payouts_paged     = isset($payouts_page_get_account) ? max(1, intval($payouts_page_get_account)) : 1;


					?>
					<div class="affiliate-dashboard">
						<div class="tabs">
							<ul class="tab-menu">
								<li class="<?php echo 'dashboard' == $active_tab ? 'active' : ''; ?>" data-tab="dashboard">
									<?php echo esc_html__('Dashboard', 'addify-affiliate-program'); ?>
								</li>
								<li class="<?php echo 'commissions' == $active_tab ? 'active' : ''; ?>" data-tab="commissions">
									<?php echo esc_html__('Commissions', 'addify-affiliate-program'); ?>
								</li>
								<li class="<?php echo 'payouts' == $active_tab ? 'active' : ''; ?>" data-tab="payouts">
									<?php echo esc_html__('Payouts', 'addify-affiliate-program'); ?>
								</li>
								<li class="<?php echo 'campaigns' == $active_tab ? 'active' : ''; ?>" data-tab="campaigns">
									<?php echo esc_html__('Campaigns', 'addify-affiliate-program'); ?>
								</li>
								<li class="<?php echo 'link-generator' == $active_tab ? 'active' : ''; ?>" data-tab="link-generator">
									<?php echo esc_html__('Link Generator', 'addify-affiliate-program'); ?>
								</li>
							</ul>

						</div>

						<div class="content">
							<div class="tab-content" id="dashboard-content">
								<div class="stats-boxes">

									<div class="box">
										<span class="icon-box"><a class="fas fa-dollar-sign"></a></span>
										<div>
											<strong>
												<?php echo esc_html__('Unpaid Earnings', 'addify-affiliate-program'); ?>
											</strong>
											<br>
											<?php echo wp_kses_post(wc_price($unpaid_amount)); ?>
										</div>
										<?php
										if (
											( '' === $min_earning || $total_amount > $min_earning ) &&
											( '' === $max_earning || $total_amount < $max_earning ) &&
											( '' === $withdrawal_limit || $paid_amount <= $withdrawal_limit ) && ( $total_amount > 0 )
										) {
											?>
											<!-- withdrawal section -->
											<form method="post" action="">

												<?php wp_nonce_field('addify_form_request_withdrawal_action', 'addify_request_nonce'); ?>

												<div class="withdrawal-section">
													<br>
													<input type="hidden" name="affiliate_id" value="<?php echo esc_attr($user_id); ?>" />
													<input type="hidden" name="unpaid_amount" value="<?php echo esc_attr($unpaid_amount); ?>" />
													<input type="hidden" name="user_name" value="<?php echo esc_attr($user_name); ?>" />
													<input type="hidden" name="user_email" value="<?php echo esc_attr($user_email); ?>" />
													<input type="submit" class="woocommerce-Button button" name="addify-form-request-withdrawal-action" value="<?php esc_attr_e('Request Withdrawal', 'addify-affiliate-program'); ?>" />
												</div>
											</form>
										<?php
										}
										?>
									</div>
									<?php
									if (
										( '' === $min_earning || $total_amount > $min_earning ) &&
										( '' === $max_earning || $total_amount < $max_earning ) &&
										( '' === $withdrawal_limit || $paid_amount <= $withdrawal_limit ) && ( $total_amount > 0 )
									) {
										?>
										<div class="grid_status_box">
										<?php
									}
									?>
										<div class="box">
											<span class="icon-box"><a class="fas fa-credit-card"></a></span>
											<div>
												<strong>
													<?php echo esc_html__('Paid Earnings', 'addify-affiliate-program'); ?>
													<br>
												</strong>
												<?php echo wp_kses_post(wc_price($paid_amount)); ?>
											</div>
										</div>
										<div class="box">
											<span class="icon-box"><a class="fas fa-piggy-bank"></a></span>
											<div>
												<strong>
													<?php echo esc_html__('Total Earnings', 'addify-affiliate-program'); ?>
												</strong>
												<br>
												<?php echo wp_kses_post(wc_price($total_amount)); ?>
											</div>
										</div>
										<div class="box">
											<span class="icon-box"><a class="fas fa-undo-alt"></a></span>
											<div>
												<strong>
													<?php echo esc_html__('Refunds', 'addify-affiliate-program'); ?>
												</strong>
												<br>
												<?php echo esc_html($total_refunded); ?>
											</div>
										</div>
										<div class="box">
											<span class="icon-box"><a class="fas fa-coins"></a></span>
											<div>
												<strong>
													<?php echo esc_html__('Commission Earned', 'addify-affiliate-program'); ?>
												</strong>
												<br>
												<?php echo esc_html($number_of_commission_earned); ?>
											</div>
										</div>
										<div class="box">
											<span class="icon-box">
												<span class="icon-box"><a class="fas fa-mouse-pointer"></a></span>
											</span>
											<div>
												<strong>
													<?php echo esc_html__('Total Clicks', 'addify-affiliate-program'); ?>
												</strong>
												<br>
												<?php echo esc_html($total_clicks); ?>
											</div>
										</div>
										<?php
										if (
											( '' === $min_earning || $total_amount > $min_earning ) &&
											( '' === $max_earning || $total_amount < $max_earning ) &&
											( '' === $withdrawal_limit || $paid_amount <= $withdrawal_limit ) && ( $total_amount > 0 )
										) {
											?>
										</div>
									<?php
										}
										?>

								</div>

								<form method="post" action="">
									<div class="content">
										<div class="left-content">
											<div class="section">
												<h3 style="font-weight: 600;"><?php echo esc_html__('Account Info', 'addify-affiliate-program'); ?></h3>
												<?php

												foreach ($user_meta as $meta_key => $meta_value) {

													// Skip label keys (they’re just for display)
													if (strpos($meta_key, 'reg_') !== 0 || strpos($meta_key, '_label') !== false) {
														continue;
													}

													$value = is_array($meta_value) ? $meta_value[0] : $meta_value;

													// Get custom label if saved
													$label_key = $meta_key . '_label';
													if (isset($user_meta[ $label_key ][0])) {
														$label = $user_meta[ $label_key ][0];
													} else {
														$trimmed_key = preg_replace('/^reg_/', '', $meta_key);
														$trimmed_key = preg_replace('/_\d+$/', '', $trimmed_key); // remove trailing _0, _1, etc.
														$label = ucwords(str_replace('_', ' ', $trimmed_key));
													}

													// Determine field type from meta_key
													$input_type = 'text';
													if (strpos($meta_key, 'email') !== false) {
														$input_type = 'email';
													} elseif (strpos($meta_key, 'tel') !== false) {
														$input_type = 'tel';
													} elseif (strpos($meta_key, 'checkbox') !== false) {
														$input_type = 'checkbox';
													} elseif (strpos($meta_key, 'textarea') !== false) {
														$input_type = 'textarea';
													} elseif (strpos($meta_key, 'radio') !== false) {
														$input_type = 'radio';
													} elseif (strpos($meta_key, 'select') !== false) {
														$input_type = 'select';
													}

													if ('checkbox' === $input_type) {
														$checked = '1' == $value ? 'checked' : '';
														echo '<div style="display: flex; gap: 6px;align-items: baseline;">';
														echo '<span style="width:50%;font-weight: 700;">' . esc_html($label) . '</span>';
														echo '<input disabled style="width:50%;" type="checkbox" name="' . esc_attr($meta_key) . '" value="1" ' . esc_attr($checked) . ' />';
														echo '</div>';
													} else {
														echo '<label>' . esc_html($label) . '<br>';

														if ('textarea' === $input_type) {
															echo '<textarea name="' . esc_attr($meta_key) . '" rows="4">' . esc_textarea($value) . '</textarea>';
														} elseif ('radio' === $input_type || 'select' === $input_type) {
															// Get the post that defined this field
															$field_post = array();
															$all_registration_posts = get_posts(array(
																'post_type'      => 'registration_post',
																'posts_per_page' => -1,  // Get all posts to filter manually
																'post_status'    => 'publish',
															));

															foreach ($all_registration_posts as $post) {
																$field_label = get_post_meta($post->ID, 'Addify_Af_Pr_field_label', true);
																if ($field_label === $label) {
																	$field_post[] = $post;
																	break;
																}
															}


															$options = array();
															if (!empty($field_post)) {
																$options_raw = get_post_meta($field_post[0]->ID, 'Addify_Af_Pr_field_options', true);
																$options = preg_split('/[\n,]+/', $options_raw); // Support commas & newlines
																$options = array_filter(array_map('trim', $options));
															}

															if ('radio' === $input_type) {
																echo '<div class="addify-radio-group">';
																foreach ($options as $index => $option_line) {
																	$option_label = str_replace('option->', '', $option_line);
																	$radio_id     = $meta_key . '_' . $index;
																	$checked      = ( $value === $option_label ) ? 'checked' : '';

																	echo '<label class="addify-radio-option" for="' . esc_attr($radio_id) . '">';
																	echo '<span class="option_label_text">' . esc_html($option_label) . '</span>';
																	echo '<input disabled class="woocommerce-Input woocommerce-Input--radio input-radio" type="radio" name="' . esc_attr($meta_key) . '" id="' . esc_attr($radio_id) . '" value="' . esc_attr($option_label) . '" ' . esc_attr($checked) . ' >';
																	echo '</label>';
																}
																echo '</div>';
															} elseif ('select' === $input_type) {
																echo '<select class="affiliate_select_field" name="' . esc_attr($meta_key) . '" id="' . esc_attr($meta_key) . '">';
																foreach ($options as $option_line) {
																	$option_label = str_replace('option->', '', $option_line);
																	$selected = ( $value === $option_label ) ? 'selected' : '';
																	echo '<option value="' . esc_attr($option_label) . '" ' . esc_attr($selected) . '>' . esc_html($option_label) . '</option>';
																}
																echo '</select><br>';
															}
														} else {
															echo '<input disabled class="woocommerce-Input woocommerce-Input--text input-text" type="' . esc_attr($input_type) . '" name="' . esc_attr($meta_key) . '" value="' . esc_attr($value) . '" />';
														}

														echo '</label>';
													}
												}


												?>
											</div>
										</div>

										<div class="section right-content">
											<h3 style="font-weight: 600;"><?php echo esc_html__('Payment Info', 'addify-affiliate-program'); ?></h3>
											<?php
											$payment_restriction = get_option('Addify_Af_Pr_payment_method_restriction');

											if (!empty($payment_restriction) && in_array('stripe', $payment_restriction)) {
												?>
												<label for="paypal_email"><?php echo esc_html__('PayPal Email', 'addify-affiliate-program'); ?></label>
												<input type="email" id="paypal_email" name="paypal_email" value="<?php echo esc_attr($paypal_email); ?>" />

											<?php } elseif (!empty($payment_restriction) && in_array('ppcp-gateway', $payment_restriction)) { ?>
												<label for="stripe_account_id"><?php echo esc_html__('Stripe Account ID', 'addify-affiliate-program'); ?></label>
												<input type="text" id="stripe_account_id" name="stripe_account_id" value="<?php echo esc_attr($stripe_account_id); ?>" />

											<?php
											} elseif (!empty($payment_restriction) && in_array('stripe', $payment_restriction) && in_array('ppcp-gateway', $payment_restriction)) {
												echo esc_html__('Your Payment will be processed through Direct Bank Transfer.', 'addify-affiliate-program');
											} else {
												?>
												<label for="stripe_account_id"><?php echo esc_html__('Stripe Account ID', 'addify-affiliate-program'); ?></label>
												<input type="text" id="stripe_account_id" name="stripe_account_id" value="<?php echo esc_attr($stripe_account_id); ?>" />

												<label for="paypal_email"><?php echo esc_html__('PayPal Email', 'addify-affiliate-program'); ?></label>
												<input type="email" id="paypal_email" name="paypal_email" value="<?php echo esc_attr($paypal_email); ?>" />
											<?php } ?>

										</div>
									</div>
									<?php wp_nonce_field('save_affiliate_account_info', 'affiliate_account_nonce'); ?>
									<p>
										<input type="submit" id="submit_affiliate" class="woocommerce-Button button" name="submit-affiliate-form" value="<?php esc_attr_e('Submit', 'addify-affiliate-program'); ?>" />
									</p>
								</form>
							</div>
							<?php
							// Get all commission posts authored by a specific affiliate

							$all_commission_posts = get_posts(array(
								'post_type'      => 'commission_post',
								'post_status'    => 'any',
								'posts_per_page' => -1,
							));

							$matched_commission_posts = array();

							foreach ($all_commission_posts as $commission_post) {
								$affiliate_user_id = get_post_meta($commission_post->ID, 'affiliate_id', true);

								if ((int) $affiliate_user_id === (int) $user_id) {
									$matched_commission_posts[] = $commission_post;
								}
							}


							// Output the result for debugging

							$commissions_paged = isset($commissions_page_get_account) ? max(1, intval($commissions_page_get_account)) : 1;
							$campaigns_paged   = isset($campaigns_page_get_account) ? max(1, intval($campaigns_page_get_account)) : 1;
							$payouts_paged     = isset($payouts_page_get_account) ? max(1, intval($payouts_page_get_account)) : 1;

							$per_page = 5; // rows per page

							?>
							<div class="tab-content" id="commissions-content">
								<h3><?php echo esc_html__('Commissions Table', 'addify-affiliate-program'); ?></h3>
								<?php
								$commission_query = new WP_Query(array(
									'post_type'      => 'commission_post',
									'post_status'    => 'any',
									'posts_per_page' => $per_page,
									'paged'          => $commissions_paged,
									// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
									'meta_query'     => array(
										array(
											'key'   => 'affiliate_id',
											'value' => (int) $user_id,
											'compare' => '=',
										),
									),
								));


								?>
								<table class="woocommerce-orders-table woocommerce-MyAccount-orders shop_table  my_account_orders account-orders-table">
									<thead>
										<tr>
											<th><?php echo esc_html__('Order ID', 'addify-affiliate-program'); ?></th>
											<th><?php echo esc_html__('Type', 'addify-affiliate-program'); ?></th>
											<th><?php echo esc_html__('Order Total', 'addify-affiliate-program'); ?></th>
											<th><?php echo esc_html__('Commission Rate', 'addify-affiliate-program'); ?></th>
											<th><?php echo esc_html__('Commission Earned', 'addify-affiliate-program'); ?></th>
											<th><?php echo esc_html__('Date', 'addify-affiliate-program'); ?></th>
										</tr>
									</thead>
									<tbody>
										<?php foreach ($commission_query->posts as $post) : ?>
											<?php
											$affiliate_id = get_post_meta($post->ID, 'affiliate_id', true);
											$username = get_post_meta($post->ID, 'user_name', true);
											$order_id = get_post_meta($post->ID, 'order_id', true);
											$order = wc_get_order($order_id);
											$product = get_post_meta($post->ID, 'product_name', true);
											$commission = get_post_meta($post->ID, 'unpaid_amount', true);
											$date = get_post_meta($post->ID, 'date', true);
											$commission_type = get_post_meta($post->ID, 'commission_type', true);
											?>
											<tr>

												<td><?php echo esc_html($order_id); ?></td>
												<td>
													<?php
													if ('' !== $product) {
														echo esc_html('Product Based: ' . $product);
													} else {
														$product = get_post_meta($post->ID, 'referral_token', true);
														echo esc_html('Coupon Based: ' . $product);
													}
													?>
												</td>
												<td>
													<?php
													if (! $order) {
														echo esc_html__('Order not found', 'addify-affiliate-program');
													} else {
														echo wp_kses_post($order->get_total());
													}

													?>
												</td>
												<td>
													<?php

													if ('fixed' === $commission_type) {
														$commission_rate = get_post_meta($post->ID, 'commission_rate', true);
														echo wp_kses_post(wc_price($commission_rate));
													} else {
														$commission_rate = get_post_meta($post->ID, 'commission_rate', true);
														$html = '<span class="woocommerce-Price-amount amount">&nbsp;' . $commission_rate . '<span class="woocommerce-Price-currencySymbol">%</span></span>';
														echo wp_kses_post($html);
													}
													?>
												</td>
												<td><?php echo wp_kses_post(wc_price($commission)); ?></td>
												<td><?php echo esc_html($date); ?></td>
											</tr>
										<?php endforeach; ?>
									</tbody>
								</table>
								<?php
								if ($commission_query->max_num_pages > 1) {
									echo '<div class="pagination">';
									echo wp_kses_post(paginate_links(array(
										'base'      => esc_url_raw(
											add_query_arg(
												array(
													'tab'             => 'commissions',
													'commissions_page' => '%#%',
												),
												remove_query_arg(
													array( 'campaigns_page', 'payouts_page' ),
													wc_get_endpoint_url('affiliate-account-settings', '', wc_get_page_permalink('myaccount'))
												)
											)
										),
										'format'    => '',
										'current'   => max(1, $commissions_paged),
										'total'     => $commission_query->max_num_pages,
										'prev_text' => __('« Prev', 'addify-affiliate-program'),
										'next_text' => __('Next »', 'addify-affiliate-program'),
									)));
									echo '</div>';
								}
								?>
							</div>
							<?php
							$today = gmdate('Y-m-d');

							$all_rule_posts = get_posts(array(
								'post_type'      => 'rule_setting_tab',
								'post_status'    => 'publish',
								'posts_per_page' => -1,
								'orderby'        => 'menu_order',
								'order'          => 'ASC',
							));
							?>
							<div class="tab-content" id="campaigns-content">
								<h3><?php echo esc_html__('Active Campaigns', 'addify-affiliate-program'); ?></h3>
								<?php
								$campaign_query = new WP_Query(array(
									'post_type'      => 'rule_setting_tab',
									'post_status'    => 'publish',
									'posts_per_page' => $per_page,
									'paged'          => $campaigns_paged,
									'orderby'        => 'menu_order',
									'order'          => 'ASC',
								));
								$all_rule_posts = $campaign_query->posts;

								?>
								<table class="woocommerce-orders-table woocommerce-MyAccount-orders shop_table ">
									<thead>
										<tr>
											<th><?php esc_html_e('ID', 'addify-affiliate-program'); ?></th>
											<th><?php esc_html_e('Campaign Name', 'addify-affiliate-program'); ?></th>
											<th><?php esc_html_e('Commission Rate', 'addify-affiliate-program'); ?></th>
											<th><?php esc_html_e('Applies To', 'addify-affiliate-program'); ?></th>
											<th><?php esc_html_e('Expiry', 'addify-affiliate-program'); ?></th>
										</tr>
									</thead>
									<tbody>
										<?php

										foreach ($all_rule_posts as $rule_post) :

											// Get meta fields
											$rate_type  = get_post_meta($rule_post->ID, 'Addify_Af_Pr_rule_commission_rate_type', true);

											$rate_value = get_post_meta($rule_post->ID, 'Addify_Af_Pr_rule_commission_rate_value', true);
											$expiry     = get_post_meta($rule_post->ID, 'Addify_Af_Pr_rule_expiry_date', true);
											$products   = (array) get_post_meta($rule_post->ID, 'Addify_Af_Pr_applied_products', true);
											$categories = (array) get_post_meta($rule_post->ID, 'Addify_Af_Pr_applied_categories', true);
											$brands     = (array) get_post_meta($rule_post->ID, 'Addify_Af_Pr_applied_brands', true);
											$apply_all  = get_post_meta($rule_post->ID, 'Addify_Af_Pr_apply_all', true) === 'yes';

											if (
												! empty($expiry) &&
												strtotime(gmdate('Y-m-d', strtotime($expiry))) < strtotime($today)
											) {
												continue;
											}
											// Build "Applies To" string
											if ($apply_all) {
												$applies_to = esc_html__('All Products', 'addify-affiliate-program');
											} else {
												$items = array();
												foreach ($products as $pid) {
													$items[] = get_the_title($pid);
												}
												foreach ($categories as $cid) {
													$term = get_term($cid);
													if (! is_wp_error($term) && $term) {
														$items[] = $term->name;
													}
												}
												foreach ($brands as $bid) {
													$term = get_term($bid);
													if (! is_wp_error($term) && $term) {
														$items[] = $term->name;
													}
												}
												$applies_to = ! empty($items) ? implode(', ', $items) : '-';
											}
											?>
											<tr>
												<td><?php echo esc_html($rule_post->ID); ?></td>
												<td><?php echo esc_html(get_the_title($rule_post->ID)); ?></td>
												<td>
													<?php
													if ('percentage' === $rate_type) {
														$html = '<span class="woocommerce-Price-amount amount">&nbsp;' . $rate_value . '<span class="woocommerce-Price-currencySymbol">%</span></span>';
														echo wp_kses_post($html);
													} else {
														echo wp_kses_post(wc_price($rate_value));
													}
													?>
												</td>
												<td><?php echo esc_html($applies_to); ?></td>
												<td><?php echo esc_html(!empty($expiry) ? $expiry : esc_html__('No Expiry', 'addify-affiliate-program')); ?></td>
											</tr>
										<?php endforeach; ?>
									</tbody>
								</table>
								<?php
								if ($campaign_query->max_num_pages > 1) {
									echo '<div class="pagination">';
									echo wp_kses_post(paginate_links(array(
										'base'      => esc_url_raw(
											add_query_arg(
												array(
													'tab'            => 'campaigns',
													'campaigns_page' => '%#%',
												),
												remove_query_arg(
													array( 'commissions_page', 'payouts_page' ),
													wc_get_endpoint_url('affiliate-account-settings', '', wc_get_page_permalink('myaccount'))
												)
											)
										),
										'current'   => $campaigns_paged,
										'total'     => $campaign_query->max_num_pages,
										'prev_text' => __('« Prev', 'addify-affiliate-program'),
										'next_text' => __('Next »', 'addify-affiliate-program'),
									)));
									echo '</div>';
								}

								?>
							</div>

							<?php
							$payout_query = new WP_Query(array(
								'post_type'      => 'payout_post',
								'post_status'    => 'any',
								'posts_per_page' => $per_page,
								'paged'          => $payouts_paged,
								// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
								'meta_query'     => array(
									array(
										'key'     => 'affiliate_id',
										'value'   => (int) $user_id,
										'compare' => '=',
									),
								),
							));

							$matched_payout_posts = $payout_query->posts; // already filtered
							?>
							<div class="tab-content" id="payouts-content">
								<h3><?php echo esc_html__('Payouts Table', 'addify-affiliate-program'); ?></h3>

								<?php if ($matched_payout_posts) : ?>

									<?php foreach ($matched_payout_posts as $post) : ?>
										<?php
										$post_id = $post->ID;
										$user_id = $post->post_author;

										$affiliate_posts = get_posts(array(
											'post_type'      => 'affiliate_user_post',
											'posts_per_page' => -1,
											'post_status'    => 'publish',
											'author'         => $user_id,
										));

										if (empty($affiliate_posts)) {
											echo '<p>' . esc_html__('No Affiliate Payout Logs Found For This User.', 'addify-affiliate-program') . '</p>';
											continue;
										}

										// Collect all payout logs together
										$all_logs = array();

										foreach ($affiliate_posts as $affiliate_post) {
											$logs = get_post_meta($affiliate_post->ID, 'payout_save_log', true);
											if (!empty($logs) && is_array($logs)) {
												$all_logs = array_merge($all_logs, $logs);
											}
										}

										if (empty($all_logs)) {
											echo '<p>' . esc_html__('No payout logs found.', 'addify-affiliate-program') . '</p>';
											continue;
										}

										// Pagination
										$paged_get = filter_input(INPUT_GET, 'payout_page', FILTER_SANITIZE_NUMBER_INT);
										$paged     = !empty($paged_get) ? max(1, intval($paged_get)) : 1;

										$per_page  = 5;
										$total     = count($all_logs);
										$pages     = ceil($total / $per_page);
										$offset    = ( $paged - 1 ) * $per_page;

										$display_items = array_slice($all_logs, $offset, $per_page);

										?>

										<table class="widefat striped">
											<thead>
												<tr>
													<th><?php echo esc_html__('Affiliate Name', 'addify-affiliate-program'); ?></th>
													<th><?php echo esc_html__('Transaction ID', 'addify-affiliate-program'); ?></th>
													<th><?php echo esc_html__('Payment Method', 'addify-affiliate-program'); ?></th>
													<th><?php echo esc_html__('Custom Payout', 'addify-affiliate-program'); ?></th>
													<th><?php echo esc_html__('Payout Amount', 'addify-affiliate-program'); ?></th>
												</tr>
											</thead>
											<tbody>

												<?php foreach ($display_items as $log) : ?>

													<?php
													$transaction_id = isset($log['transaction_id']) ? $log['transaction_id'] : '';
													$payment_method = isset($log['method']) ? $log['method'] : '';
													$custom_payout  = isset($log['custom_payout_check']) ? $log['custom_payout_check'] : 'no';
													$payout_amount  = isset($log['payout_amount']) ? $log['payout_amount'] : '';

													// Icons allowed safely
													if ('stripe' == $payment_method) {
														$payment_method .= ' <i class="fa fa-cc-stripe"></i>';
													} elseif ('paypal' == $payment_method) {
														$payment_method .= ' <i class="fa fa-cc-paypal"></i>';
													} elseif ('bacs' == $payment_method) {
														$payment_method .= ' <i class="fa fa-bank"></i>';
													}

													$affiliate_user = get_user_by('ID', $user_id);
													$affiliate_name = $affiliate_user ? $affiliate_user->display_name : 'Unknown';
													?>

													<tr>
														<td><?php echo esc_html($affiliate_name); ?></td>
														<td><?php echo esc_html($transaction_id); ?></td>
														<td><?php echo wp_kses_post($payment_method); ?></td>
														<td>
														<?php
														echo 'yes' == $custom_payout
																? '<i class="fa fa-check"></i>'
																: '<i class="fa fa-close"></i>';
														?>
														</td>
														<td><?php echo esc_html($payout_amount); ?></td>
													</tr>

												<?php endforeach; ?>

											</tbody>
										</table>

										<?php if ($pages > 1) : ?>
											<?php
											$range = 2;
											$pages_to_show = array( 1, $pages );

											for ($i = $paged - $range; $i <= $paged + $range; $i++) {
												if ($i > 1 && $i < $pages) {
													$pages_to_show[] = $i;
												}
											}

											$pages_to_show = array_unique($pages_to_show);
											sort($pages_to_show);
											$last_page = 0;
											?>
											<div class="pagination">

												<!-- Prev Button -->
												<?php if ($paged > 1) : ?>
													<a class="page-numbers prev"
														href="
														<?php
														echo esc_url(add_query_arg(array(
															'tab' => 'payouts',
															'payout_page' => $paged - 1,
														)));
														?>
																">
														&laquo; <?php esc_html_e('Prev', 'addify-affiliate-program'); ?>
													</a>
												<?php endif; ?>

												<!-- Page Numbers -->
												<?php foreach ($pages_to_show as $page) : ?>
													<?php if ($last_page && $page > $last_page + 1) : ?>
														<span class="dots">…</span>
													<?php endif; ?>

													<a class="page-numbers <?php echo $page == $paged ? 'current' : ''; ?>"
														href="
														<?php
														echo esc_url(add_query_arg(array(
															'tab' => 'payouts',
															'payout_page' => $page,
														)));
														?>
																">
														<?php echo esc_html($page); ?>
													</a>

													<?php $last_page = $page; ?>
												<?php endforeach; ?>

												<!-- Next Button -->
												<?php if ($paged < $pages) : ?>
													<a class="page-numbers next"
														href="
														<?php
														echo esc_url(add_query_arg(array(
															'tab' => 'payouts',
															'payout_page' => $paged + 1,
														)));
														?>
																">
														<?php esc_html_e('Next', 'addify-affiliate-program'); ?> &raquo;
													</a>
												<?php endif; ?>

											</div>
										<?php endif; ?>

									<?php endforeach; ?>

								<?php else : ?>

									<p><?php echo esc_html__('No payouts found.', 'addify-affiliate-program'); ?></p>

								<?php endif; ?>
							</div>



							<div class="tab-content" id="link-generator-content">
								<input type="hidden" id="affiliate_user_id" value="<?php echo esc_attr($user_id); ?>" />
								<input type="hidden" id="referral_expiry_in_days" value="<?php echo esc_attr($expiry_in_days); ?>" />

								<?php
								$product_commissions = array();
								$product_commissions_type = array();

								// Get all products
								$all_products = get_posts(array(
									'post_type' => 'product',
									'posts_per_page' => -1,
									'post_status' => 'publish',
									'fields' => 'ids',
								));

								// Fetch rules
								$rules = get_posts(array(
									'post_type' => 'rule_setting_tab',
									'posts_per_page' => -1,
									'post_status' => 'publish',
									'orderby' => 'menu_order',
									'order' => 'ASC',
								));

								$matched_products = array();

								// First, collect all products that match any rule
								$rule_matched_products = array();

								foreach ($rules as $rule) {
									$Apply_all = (array) get_post_meta($rule->ID, 'Addify_Af_Pr_apply_all', true);
									$allowed_products = (array) get_post_meta($rule->ID, 'Addify_Af_Pr_applied_products', true);
									$allowed_categories = (array) get_post_meta($rule->ID, 'Addify_Af_Pr_applied_categories', true);
									$allowed_brands = (array) get_post_meta($rule->ID, 'Addify_Af_Pr_applied_brands', true);
									$value_min = get_post_meta($rule->ID, 'Addify_Af_Pr_value_min', true);
									$value_max = get_post_meta($rule->ID, 'Addify_Af_Pr_value_max', true);
									$rule_expiry_date = get_post_meta($rule->ID, 'Addify_Af_Pr_rule_expiry_date', true);

									if (
										!empty($rule_expiry_date) &&
										strtotime(gmdate('Y-m-d', strtotime($rule_expiry_date))) < strtotime(gmdate('Y-m-d'))
									) {
										continue;
									}


									$is_apply_all = ( in_array('yes', $Apply_all) || in_array(1, $Apply_all) );

									if ($is_apply_all) {
										// If apply all is enabled, add all products
										foreach ($all_products as $pid) {
											$rule_matched_products[ $pid ] = $pid;
										}
									} else {
										// Add specific products
										foreach ($allowed_products as $pid) {
											if (in_array($pid, $all_products)) {
												$rule_matched_products[ $pid ] = $pid;
											}
										}

										// Get all published products once
										$all_products = get_posts(array(
											'post_type'      => 'product',
											'posts_per_page' => -1,
											'post_status'    => 'publish',
											'fields'         => 'ids',
										));

										// Loop products and match
										foreach ($all_products as $pid) {

											// Match categories
											if (!empty($allowed_categories) && has_term($allowed_categories, 'product_cat', $pid)) {
												$rule_matched_products[ $pid ] = $pid;
											}

											// Match brands
											if (!empty($allowed_brands) && has_term($allowed_brands, 'product_brand', $pid)) {
												$rule_matched_products[ $pid ] = $pid;
											}
										}


										// Add all products in price range
										if (!empty($value_min) || !empty($value_max)) {
											foreach ($all_products as $pid) {
												$price = get_post_meta($pid, '_price', true);
												if (( empty($value_min) || $price >= $value_min ) && ( empty($value_max) || $price <= $value_max )) {
													$rule_matched_products[ $pid ] = $pid;
												}
											}
										}
									}
								}

								// If no rules exist, include all products
								if (empty($rules)) {
									$rule_matched_products = array_combine($all_products, $all_products);
								}

								// Now process only the matched products for commissions
								foreach ($rule_matched_products as $pid) {
									$rate = 0;
									$type = 'fixed';
									$commission_matched = false;
									$matched = true; // These products are already matched by rules

									// Priority 1: Product-level commission
									$prod_commission = get_post_meta($pid, 'addify_Af_Pr_discount_amount', true);
									$prod_type = get_post_meta($pid, 'addify_Af_Pr_discount_amount_type', true);
									if (is_numeric($prod_commission) && $prod_commission > 0) {
										$rate = $prod_commission;
										$type = in_array($prod_type, array( 'percentage', 'fixed' )) ? $prod_type : 'fixed';
										$commission_matched = true;
									}

									// Priority 2: Rule-based commission (only if not already matched at product-level)
									if (!$commission_matched && !empty($rules)) {
										foreach ($rules as $rule) {
											$rule_rate_val = get_post_meta($rule->ID, 'Addify_Af_Pr_rule_commission_rate_value', true);
											$rule_rate_type = get_post_meta($rule->ID, 'Addify_Af_Pr_rule_commission_rate_type', true);
											$rule_expiry_date = get_post_meta($rule->ID, 'Addify_Af_Pr_rule_expiry_date', true);

											if (
												( !empty($rule_expiry_date) && strtotime(gmdate('Y-m-d', strtotime($rule_expiry_date))) < strtotime(gmdate('Y-m-d')) )
												|| empty($rule_rate_val)
											) {
												continue;
											}

											// Check if this product matches this specific rule
											$Apply_all = (array) get_post_meta($rule->ID, 'Addify_Af_Pr_apply_all', true);
											$allowed_products = (array) get_post_meta($rule->ID, 'Addify_Af_Pr_applied_products', true);
											$allowed_categories = (array) get_post_meta($rule->ID, 'Addify_Af_Pr_applied_categories', true);
											$allowed_brands = (array) get_post_meta($rule->ID, 'Addify_Af_Pr_applied_brands', true);
											$value_min = get_post_meta($rule->ID, 'Addify_Af_Pr_value_min', true);
											$value_max = get_post_meta($rule->ID, 'Addify_Af_Pr_value_max', true);

											$is_apply_all = ( in_array('yes', $Apply_all) || in_array(1, $Apply_all) );
											$rule_match = false;

											if ($is_apply_all) {
												$rule_match = true;
											} else {
												// Check specific products first
												if (in_array($pid, $allowed_products)) {
													$rule_match = true;
												}

												// Check categories if not already matched
												if (!$rule_match && !empty($allowed_categories)) {
													$cats = wp_get_post_terms($pid, 'product_cat', array( 'fields' => 'ids' ));
													if (array_intersect($cats, $allowed_categories)) {
														$rule_match = true;
													}
												}

												// Check brands if not already matched
												if (!$rule_match && !empty($allowed_brands)) {
													$brands = wp_get_post_terms($pid, 'product_brand', array( 'fields' => 'ids' ));
													if (array_intersect($brands, $allowed_brands)) {
														$rule_match = true;
													}
												}

												// Check price range if not already matched
												if (!$rule_match && ( !empty($value_min) || !empty($value_max) )) {
													$price = get_post_meta($pid, '_price', true);
													if (( empty($value_min) || $price >= $value_min ) && ( empty($value_max) || $price <= $value_max )) {
														$rule_match = true;
													}
												}
											}

											// If product matched this rule → apply commission
											if ($rule_match) {
												$rate = $rule_rate_val;
												$type = !empty($rule_rate_type) ? $rule_rate_type : 'fixed';
												if (0 < $rate) {
													$commission_matched = true;
													break;
												}
											}
										}
									}

									// Priority 3: General settings
									if (!$commission_matched && !empty($Addify_Af_Pr_affiliate_setting_price_adjustment_table)) {
										foreach ($Addify_Af_Pr_affiliate_setting_price_adjustment_table as $tier) {
											if (!empty($tier['status']) && 1 == $tier['status']) {
												$from = !empty($tier['earning_from']) ? $tier['earning_from'] : 0;
												$to   = !empty($tier['earning_to']) ? $tier['earning_to'] : 0;
												if ($total_amount >= $from && $total_amount <= $to) {
													$rate    = !empty($tier['commission_rate']) ? $tier['commission_rate'] : 0;
													$type    = !empty($tier['commission_rate_type']) ? $tier['commission_rate_type'] : 'fixed';
													if (0 < $rate) {
														$commission_matched = true;
														break;
													}
												}
											}
										}
									}

									// Priority 4: Affiliate-specific
									if (!$commission_matched && !empty($affiliate_commission_rate)) {
										$rate    = $affiliate_commission_rate;
										$type    = !empty($affiliate_commission_rate_type) ? $affiliate_commission_rate_type : 'fixed';
										$commission_matched = true;
									}

									// -----------------
									// Step 3: Save matched products
									// -----------------
									if ($matched) {
										$product_commissions[ $pid ]      = $rate;
										$product_commissions_type[ $pid ] = $type;
										$matched_products[] = $pid;
									}
								}

								?>

								<!-- Output Dropdown -->
								<div style="margin-bottom: 15px;">
									<label for="product-select"><?php echo esc_html__('Select Product', 'addify-affiliate-program'); ?>:</label>
									<select id="product-select">
										<option value=""><?php echo esc_html__('-- Choose a product --', 'addify-affiliate-program'); ?></option>
										<?php
										foreach ($matched_products as $pid) :
											$product = wc_get_product($pid);
											if (!$product) {
												continue;
											}
											$rate = !empty($product_commissions[ $pid ]) ? $product_commissions[ $pid ] : 0;
											$type = !empty($product_commissions_type[ $pid ]) ? $product_commissions_type[ $pid ] : 'fixed';
											?>
											<option value="<?php echo esc_attr(get_permalink($pid)); ?>"
												data-name="<?php echo esc_attr($product->get_name()); ?>"
												data-commission="<?php echo esc_attr($rate); ?>"
												data-commission_type="<?php echo esc_attr($type); ?>">
												<?php echo esc_html($product->get_name()); ?>
											</option>
										<?php endforeach; ?>
									</select>
									<button id="generate-link-btn"><?php echo esc_html__('Generate Link', 'addify-affiliate-program'); ?></button>
								</div>

								<!-- Existing Links Table -->
								<table class="woocommerce-orders-table woocommerce-MyAccount-orders shop_table">
									<thead>
										<tr>
											<th>ID</th>
											<th><?php echo esc_html__('Product', 'addify-affiliate-program'); ?></th>
											<th><?php echo esc_html__('Link', 'addify-affiliate-program'); ?></th>
											<th><?php echo esc_html__('Expiry Date', 'addify-affiliate-program'); ?></th>
											<th><?php echo esc_html__('Commission Rate', 'addify-affiliate-program'); ?></th>
											<th><?php echo esc_html__('Action', 'addify-affiliate-program'); ?></th>
										</tr>
									</thead>
									<tbody id="generated-links-body">
										<?php

										$links = get_option('addify_affiliate_links' . $user_id, array());
										foreach ($links as $index => $link) {
											echo '<tr data-id="' . esc_html($index) . '">';
											echo '<td>' . esc_html(( $index + 1 )) . '</td>';
											echo '<td>' . esc_html($link['product_name']) . '</td>';
											echo '<td><a href="' . esc_url($link['link']) . '" target="_blank">' . esc_url($link['link']) . '</a></td>';
											echo '<td>' . esc_html($link['expiry']) . '</td>';
											echo '<td>' . ( 'percentage' == $link['commission_type'] ? '' . esc_html($link['commission']) . '%' : '' . wp_kses_post(get_woocommerce_currency_symbol() . ( $link['commission'] )) . '' ) . '</td>';
											echo '<td><button data-id="' . esc_html($index) . '" class="remove-link-btn">' . esc_html__('Remove', 'addify-affiliate-program') . '</button></td>';
											echo '</tr>';
										}
										?>
									</tbody>
								</table>
							</div>
						</div>
					</div>

			<?php
				}
			}
			$submitted_before = get_user_meta($user_id, 'affiliate_request_submitted', true);

			if (!empty($affiliate_user_status) && 'pending' == $affiliate_user_status) {
				if (true == $submitted_before) {
					echo '<div class="woocommerce-MyAccount-content">';
					wc_print_notice(esc_html__('Your affiliation request is being processed by admin.', 'addify-affiliate-program'), 'notice');
					echo '</div>';

					// ✅ Trigger pending email
					$new_form_data = array(
						'affiliate_id' => $user_id,
						'User_name'    => $user_name,
						'User_email'   => $user_email,
					);

					$mailer = WC()->mailer();
					$email  = $mailer->emails['Addify_Ad_Pr_Affiliate_Registration_Pending_Email'];
					if ($email) {
						$email->trigger($new_form_data);
					}

					return;
				}
			} elseif (!empty($affiliate_user_status) && 'suspended' == $affiliate_user_status) {
				if (true == $submitted_before) {
					echo '<div class="woocommerce-MyAccount-content">';
					wc_print_notice(esc_html__('Your affiliation account is suspended. Please contact admin for more details.', 'addify-affiliate-program'), 'notice');
					echo '</div>';
					return;
				}
			} elseif (!empty($affiliate_user_status) && 'rejected' == $affiliate_user_status) {
				if (true == $submitted_before) {
					echo '<div class="woocommerce-MyAccount-content">';
					wc_print_notice(esc_html__('Your affiliation request is rejected by admin.', 'addify-affiliate-program'), 'error');
					echo '</div>';

					// ✅ Trigger rejected email
					$new_form_data = array(
						'affiliate_id' => $user_id,
						'User_name'    => $user_name,
						'User_email'   => $user_email,
					);

					$mailer = WC()->mailer();
					$email  = $mailer->emails['Addify_Ad_Pr_Affiliate_Registration_Rejected_Email'];
					if ($email) {
						$email->trigger($new_form_data);
					}

					return;
				}
			} else if (!empty($affiliate_user_status) && 'approved' == $affiliate_user_status) {
				return;
			} else if (true == $selected && !empty($affiliate_user_status) && 'approved' == $affiliate_user_status) {
				echo '<div class="woocommerce-MyAccount-content">';
				wc_print_notice($Addify_Af_Pr_affiliate_setting_restriction_message, 'error');
				echo '</div>';
				return;
			}
			$args_posts = array(
				'post_type'      => 'registration_post',
				'orderby'        => 'menu_order',
				'order'          => 'DESC',
				'posts_per_page' => -1,
			);

			$query = new WP_Query($args_posts);

			?>
			<div class="addify_woocommerce-MyAccount-content">
				<form method="post" class="woocommerce-EditAccountForm edit-account">

					<?php
					$count = 0;
					if ($query->have_posts()) {
						while ($query->have_posts()) {
							$query->the_post();
							$post_id = get_the_ID();
							$post = get_post($post_id);
							$value = '';
							if ('first-name' == $post->post_name) {
								$value = get_user_meta(get_current_user_id(), 'first_name', true);
								$value = isset($value) ? $value : '';
							} elseif ('last-name' == $post->post_name) {
								$value = get_user_meta(get_current_user_id(), 'last_name', true);
								$value = isset($value) ? $value : '';
							} elseif ('email' == $post->post_name) {
								$value = isset($user_email) ? $user_email : '';
							}
							$value = trim($value, ' ');
							$label       = get_post_meta($post_id, 'Addify_Af_Pr_field_label', true);
							$type        = get_post_meta($post_id, 'Addify_Af_Pr_field_type', true);
							$placeholder = get_post_meta($post_id, 'Addify_Af_Pr_field_placeholder', true);
							$status      = get_post_meta($post_id, 'Addify_Af_Pr_field_status', true);
							$required    = get_post_meta($post_id, 'Addify_Af_Pr_field_required', true);

							if ('active' !== $status  || empty($label)) {
								continue;
							}

							$field_id = 'reg_' . sanitize_title($type) . '_' . $count;


							$required_attr = 'yes' === $required ? 'required' : '';
							$saved_value = get_user_meta(get_current_user_id(), $field_id, true);
							?>

							<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
								<?php
								// Get saved options (for select/radio)
								$options_raw = get_post_meta($post_id, 'Addify_Af_Pr_field_options', true);
								$options = array_filter(array_map('trim', explode("\n", $options_raw)));

								if ('checkbox' === $type) :
									?>

									<label for="<?php echo esc_attr($field_id); ?>">
										<input
											type="checkbox"
											class="woocommerce-Input woocommerce-Input--checkbox input-checkbox"
											name="<?php echo esc_attr($field_id); ?>"
											id="<?php echo esc_attr($field_id); ?>"
											value="1"
											<?php echo checked($saved_value, 1, false); ?>
											<?php echo esc_html($required_attr); ?> />
										<?php echo esc_html($label); ?>
										<?php
										if ('yes' === $required) {
											echo ' <span class="required">*</span>';
										}
										?>
									</label>

								<?php elseif ('select' === $type) : ?>

									<label for="<?php echo esc_attr($field_id); ?>">
										<?php echo esc_html($label); ?>
										<?php
										if ('yes' === $required) {
											echo ' <span class="required">*</span>';
										}
										?>
									</label>
									<select
										style="min-width:200px ;max-width:fit-content;"
										name="<?php echo esc_attr($field_id); ?>"
										id="<?php echo esc_attr($field_id); ?>"
										class="woocommerce-Input woocommerce-Input--select"
										<?php echo esc_html($required_attr); ?>>
										<?php if (!empty($placeholder)) : ?>
											<option value=""><?php echo esc_html($placeholder); ?></option>
										<?php endif; ?>

										<?php
										// Get options (split by new lines AND commas)
										$options_raw = get_post_meta($post_id, 'Addify_Af_Pr_field_options', true);
										$options = preg_split('/[\n,]+/', $options_raw); // Split by comma or newline
										$options = array_filter(array_map('trim', $options)); // Clean up

										foreach ($options as $option_line) :
											$option_label = str_replace('option->', '', $option_line);
											?>
											<option value="<?php echo esc_attr($option_label); ?>"
												<?php selected($saved_value, $option_label); ?>>
												<?php echo esc_html($option_label); ?>
											</option>
										<?php endforeach; ?>
									</select>
									<br>

								<?php elseif ('radio' === $type) : ?>

									<label>
										<?php echo esc_html($label); ?>
										<?php
										if ('yes' === $required) {
											echo ' <span class="required">*</span>';
										}
										?>
									</label>

									<?php
									// Get raw options (comma or newline separated)
									$options_raw = get_post_meta($post_id, 'Addify_Af_Pr_field_options', true);
									$options = preg_split('/[\n,]+/', $options_raw); // Split by commas or newlines
									$options = array_filter(array_map('trim', $options)); // Clean up

									foreach ($options as $index => $option_line) :
										$option_label = str_replace('option->', '', $option_line);
										$radio_id = $field_id . '_' . $index;
										?>

										<label for="<?php echo esc_attr($radio_id); ?>" style="display:block;">
											<input
												type="radio"
												name="<?php echo esc_attr($field_id); ?>"
												id="<?php echo esc_attr($radio_id); ?>"
												value="<?php echo esc_attr($option_label); ?>"
												<?php checked($saved_value, $option_label); ?>
												<?php echo esc_html($required_attr); ?> />
											<?php echo esc_html($option_label); ?>
										</label>
									<?php endforeach; ?>
								<?php elseif ('textarea' === $type) : ?>
									<label for="<?php echo esc_attr($field_id); ?>">
										<?php echo esc_html($label); ?>
										<?php
										if ('yes' === $required) {
											echo ' <span class="required">*</span>';
										}
										?>
									</label>
									<textarea
										class="woocommerce-Input woocommerce-Input--textarea input-text"
										name="<?php echo esc_attr($field_id); ?>"
										id="<?php echo esc_attr($field_id); ?>"
										placeholder="<?php echo esc_attr($placeholder); ?>"
										<?php echo esc_html($required_attr); ?>><?php echo esc_textarea($saved_value); ?></textarea>
								<?php else : ?>

									<label for="<?php echo esc_attr($field_id); ?>">
										<?php echo esc_html($label); ?>
										<?php
										if ('yes' === $required) {
											echo ' <span class="required">*</span>';
										}
										?>
									</label>
									<input
										type="<?php echo esc_attr($type); ?>"
										class="woocommerce-Input woocommerce-Input--text input-text"
										name="<?php echo esc_attr($field_id); ?>"
										id="<?php echo esc_attr($field_id); ?>"
										placeholder="<?php echo esc_attr($placeholder); ?>"
										value="
										<?php
										if ('' !== $saved_value) {
											echo esc_attr($saved_value);
										} else {
											echo esc_attr($value);
										}
										?>
										"
										<?php echo esc_html($required_attr); ?> />

								<?php endif; ?>
							</p>


					<?php
							++$count;
						}

						wp_reset_postdata();
					}
					?>

					<?php wp_nonce_field('addify_af_pr_register_action', 'addify_af_pr_nonce'); ?>
					<p>
						<input type="submit" class="woocommerce-Button button" name="addify_af_pr_register" value="<?php esc_attr_e('Register', 'addify-affiliate-program'); ?>" />
					</p>

				</form>
			</div>
<?php
		}
	}
	new Addify_Affiliate_My_Account_Left_Tab();
endif;
