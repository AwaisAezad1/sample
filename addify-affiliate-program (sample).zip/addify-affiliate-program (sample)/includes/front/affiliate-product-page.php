<?php

if (!defined('ABSPATH')) {
	exit();
}

if (!class_exists('Addify_Affiliate_Product_Page')) :
	class Addify_Affiliate_Product_Page {
	






	
		public function affiliate_process_affiliate_refunded_commission( $order_id ) {
			$order = wc_get_order($order_id);
			if (!$order) {
				return;
			}

			$affiliate_data_coupon = $order->get_meta('affiliate_coupon_order_data');

			if (!empty($affiliate_data_coupon)) {
				if (!is_array($affiliate_data_coupon) || !isset($affiliate_data_coupon['affiliate_id'])) {
					return;
				}

				$affiliate_id = $affiliate_data_coupon['affiliate_id'];
				$amount_to_be_refunded = floatval(0);

				$commissions = get_posts(array(
					'post_type' => 'commission_post',
					'posts_per_page' => -1,
					'post_status' => 'publish',
				));

				foreach ($commissions as $commission) {
					$commission_order_id = get_post_meta($commission->ID, 'order_id', true);
					$commission_affiliate_id = get_post_meta($commission->ID, 'affiliate_id', true);

					if ((int) $commission_order_id === (int) $order_id && (int) $commission_affiliate_id === (int) $affiliate_id) {
						update_post_meta($commission->ID, 'commission_status', 'refunded');
						$amount_to_be_refunded += floatval(get_post_meta($commission->ID, 'unpaid_amount', true));
					}
				}

				if ($amount_to_be_refunded > 0) {
					$payout_posts = get_posts(array(
						'post_type' => 'payout_post',
						'post_status' => 'any',
						'posts_per_page' => -1,
						'author' => $affiliate_id,
					));

					foreach ($payout_posts as $payout_post) {
						$payout_status = get_post_meta($payout_post->ID, 'payout_status', true);

						// 🚫 Skip if payout already marked as paid
						if ('paid' === strtolower($payout_status)) {
							continue;
						}

						$unpaid_amount = floatval(get_post_meta($payout_post->ID, 'unpaid_amount', true));
						$new_unpaid    = max(0, $unpaid_amount - $amount_to_be_refunded);

						update_post_meta($payout_post->ID, 'unpaid_amount', $new_unpaid);

						// (optional) Log refund adjustment
						update_post_meta($payout_post->ID, 'last_refund_update', current_time('mysql'));
						update_user_meta($affiliate_id, 'unpaid_amount', $new_unpaid);
					}
				}
			} else {
				// No coupon data, check affiliate_order_data
				$affiliate_data = $order->get_meta('affiliate_order_data');
				if (empty($affiliate_data) || !is_array($affiliate_data)) {
					return;
				}

				foreach ($affiliate_data as $data) {
					if (empty($data['product_id']) || empty($data['affiliate_id'])) {
						continue;
					}

					$affiliate_product_id = $data['product_id'];
					$affiliate_id = $data['affiliate_id'];
					$amount_to_be_refunded = 0;

					$commissions = get_posts(array(
						'post_type' => 'commission_post',
						'posts_per_page' => -1,
						'post_status' => 'publish',
					));

					foreach ($commissions as $commission) {
						$commission_order_id = get_post_meta($commission->ID, 'order_id', true);
						$commission_affiliate_id = get_post_meta($commission->ID, 'affiliate_id', true);
						$commission_product_id = get_post_meta($commission->ID, 'product_id', true);

						if (
							(int) $commission_order_id === (int) $order_id
							&& (int) $commission_affiliate_id === (int) $affiliate_id
							&& (int) $commission_product_id === (int) $affiliate_product_id
						) {

							update_post_meta($commission->ID, 'commission_status', 'refunded');
							$amount_to_be_refunded += floatval(get_post_meta($commission->ID, 'unpaid_amount', true));
						}
					}

					if ($amount_to_be_refunded > 0) {
						$payout_posts = get_posts(array(
							'post_type' => 'payout_post',
							'post_status' => 'any',
							'posts_per_page' => -1,
							'author' => $affiliate_id,
						));

						foreach ($payout_posts as $payout_post) {
							$payout_status = get_post_meta($payout_post->ID, 'payout_status', true);

							// 🚫 Skip if payout already marked as paid
							if ('paid' === strtolower($payout_status)) {
								continue;
							}

							$unpaid_amount = floatval(get_post_meta($payout_post->ID, 'unpaid_amount', true));
							$new_unpaid    = max(0, $unpaid_amount - $amount_to_be_refunded);

							update_post_meta($payout_post->ID, 'unpaid_amount', $new_unpaid);

							// (optional) Log refund adjustment
							update_post_meta($payout_post->ID, 'last_refund_update', current_time('mysql'));
							update_user_meta($affiliate_id, 'unpaid_amount', $new_unpaid);
						}
					}
				}
			}
		}


		public function affiliate_process_affiliate_commission( $order_id ) {

			$order = wc_get_order($order_id);

			if (!$order) {
				return;
			}


			$affiliate_data_coupon = $order->get_meta('affiliate_coupon_order_data');

			if (!empty($affiliate_data_coupon)) {

				if (!is_array($affiliate_data_coupon) || !isset($affiliate_data_coupon['affiliate_id'])) {
					return;
				}

				$affiliate_id      = $affiliate_data_coupon['affiliate_id'];
				$commission_value  = floatval($affiliate_data_coupon['commission']);
				$commission_type   = $affiliate_data_coupon['commission_type'];
				$referral_token    = $affiliate_data_coupon['coupon_code'];
				$user_meta         = get_user_meta($affiliate_id);
				$user_data         = get_user_by('ID', $affiliate_id);
				$username          = isset($user_data->user_login) ? $user_data->user_login : 'unknown';
				$user_email        = isset($user_data->user_email) ? $user_data->user_email : 'unknown';
				if ($commission_value <= 0) {
					return;
				}
				// Fetch existing commissions
				$existing_commissions = get_posts(array(
					'post_type'   => 'commission_post',
					'post_status' => 'any',
					'numberposts' => -1,
				));

				// Loop through products in the order
				$once_payout = false;
				$total_commision_earned_order = floatval(0);
				foreach ($order->get_items() as $item_id => $item) {
					$product        = $item->get_product();
					if (!$product) {
						continue;
					}

					$product_id     = $product->get_id();
					$product_name   = $product->get_name();
					$qty            = $item->get_quantity();
					$line_total     = $item->get_total();

					// Calculate commission
					if ('fixed' === $commission_type) {
						$commission_rate   = $commission_value;
						$commission_amount = $commission_rate * $qty;
					} else {
						$commission_rate   = $commission_value / 100;
						$commission_amount = $line_total * $commission_rate;
					}

					// === Manually check for existing commission for this product ===
					$commission_exists = false;
					foreach ($existing_commissions as $commission_post) {
						$existing_order_id     = get_post_meta($commission_post->ID, 'order_id', true);
						$existing_affiliate_id = get_post_meta($commission_post->ID, 'affiliate_id', true);
						$existing_product_id   = get_post_meta($commission_post->ID, 'product_id', true);

						if (
							(string) $existing_order_id === (string) $order_id &&
							(string) $existing_affiliate_id === (string) $affiliate_id &&
							(string) $existing_product_id === (string) $product_id
						) {
							$commission_exists = true;
							break;
						}
					}

					if ($commission_exists) {
						continue;
					}

					// === Create Commission Post ===
					$commission_id = wp_insert_post(array(
						'post_type'   => 'commission_post',
						'post_status' => 'publish',
						'post_title'  => $affiliate_id,
					));

					if ($commission_id && $commission_amount > 0) {
						update_post_meta($commission_id, 'order_id', $order_id);
						update_post_meta($commission_id, 'affiliate_id', $affiliate_id);
						update_post_meta($commission_id, 'user_name', $username);
						update_post_meta($commission_id, 'affiliation_type', 'Coupon');
						update_post_meta($commission_id, 'referral_token', $referral_token);
						update_post_meta($commission_id, 'commission_rate', $commission_value);
						update_post_meta($commission_id, 'commission_type', $commission_type);
						update_post_meta($commission_id, 'unpaid_amount', $commission_amount);
						update_post_meta($commission_id, 'total_product_amount', $line_total);
						update_post_meta($commission_id, 'product_id', $product_id);
						update_post_meta($commission_id, 'product_name', $product_name);
						update_post_meta($commission_id, 'date', gmdate('Y-m-d'));

						// Update affiliate's unpaid total
						$existing_user_unpaid        = floatval(get_user_meta($affiliate_id, 'unpaid_amount', true));
						$total_commision_earned_order = $existing_user_unpaid + $commission_amount;

						if (false == $once_payout) {
							if ('fixed' === $commission_type) {
								$once_payout = true;
							}

							// === Payout logic ===
							$payout_found   = false;
							$payout_id      = 0;
							$existing_payouts = get_posts(array(
								'post_type'   => 'payout_post',
								'post_status' => 'any',
								'numberposts' => -1,
							));

							foreach ($existing_payouts as $payout_post) {
								$payout_affiliate_id = get_post_meta($payout_post->ID, 'affiliate_id', true);
								if ((string) $payout_affiliate_id === (string) $affiliate_id) {
									$payout_found = true;
									$payout_id    = $payout_post->ID;

									$existing_unpaid = floatval(get_post_meta($payout_id, 'unpaid_amount', true));
									$new_unpaid      = $existing_unpaid + $commission_amount;

									update_post_meta($payout_id, 'unpaid_amount', $new_unpaid);
									update_post_meta($payout_id, 'order_id', $order_id);
									update_post_meta($payout_id, 'referral_token', $referral_token);
									update_post_meta($payout_id, 'user_name', $username);

									break;
								}
							}

							// If no payout found, create one
							if (!$payout_found) {
								$payout_id = wp_insert_post(array(
									'post_type'   => 'payout_post',
									'post_status' => 'publish',
									'post_title'  => $affiliate_id,
								));

								if ($payout_id) {
									update_post_meta($payout_id, 'order_id', $order_id);
									update_post_meta($payout_id, 'affiliate_id', $affiliate_id);
									update_post_meta($payout_id, 'referral_token', $referral_token);
									update_post_meta($payout_id, 'unpaid_amount', $commission_amount);
									update_post_meta($payout_id, 'user_name', $username);
								}
							}

							// ✅ Always append payout_data after payout_id is known
							if ($payout_id) {
								$payout_data = get_post_meta($payout_id, 'payout_data', true);
								if (!is_array($payout_data)) {
									$payout_data = array();
								}

								$payout_data[] = array(
									'amount'  => $commission_amount,
									'status'  => 'unpaid',
									'created' => current_time('mysql'),
								);

								update_post_meta($payout_id, 'payout_data', $payout_data);
							}

							/**
							 * Track transaction in hourly_stats for analytics.
							 */
							$wp_timezone = get_option('timezone_string');
							if (!$wp_timezone) {
								$offset = (float) get_option('gmt_offset');
								$sign   = ( $offset <= 0 ) ? '+' : '-';
								$hours  = abs($offset);
								$wp_timezone = 'Etc/GMT' . $sign . $hours;
							}

							$tz = new DateTimeZone($wp_timezone);
							$now = new DateTime('now', $tz);
							$hour_key = $now->format('Y-m-d H:00'); // e.g. "2025-07-21 13:00"

							// Fetch affiliate posts for this affiliate
							$affiliates = get_posts(array(
								'post_type'      => 'affiliate_user_post',
								'posts_per_page' => -1,
								'post_status'    => 'publish',
								'author'         => $affiliate_id,
							));

							foreach ($affiliates as $affiliate) {
								$hourly_log = get_post_meta($affiliate->ID, 'hourly_stats', true);
								if (!is_array($hourly_log)) {
									$hourly_log = array();
								}

								// Make sure bucket exists
								if (!isset($hourly_log[ $hour_key ])) {
									$hourly_log[ $hour_key ] = array(
										'clicks'   => 0,
										'paid'     => 0,
										'unpaid'   => 0,
										'earnings' => 0,
										'refunds'  => 0,
									);
								}

								// Increment metrics correctly
								$hourly_log[ $hour_key ]['unpaid']   += (float) $commission_amount;
								$hourly_log[ $hour_key ]['earnings'] += (float) $commission_amount;

								update_post_meta($affiliate->ID, 'hourly_stats', $hourly_log);
							}
						}
					}
				}
				if ($total_commision_earned_order > 0) {
					update_user_meta($affiliate_id, 'unpaid_amount', $total_commision_earned_order);
				}
			} else {
				$affiliate_data = $order->get_meta('affiliate_order_data');

				$filtered_array = array();

				foreach ($order->get_items() as $item) {
					$product = $item->get_product();
					if (!$product) {
						continue;
					}

					$order_product_id = $product->is_type('variation') ? $product->get_parent_id() : $product->get_id();

					foreach ($affiliate_data as $data) {
						if (empty($data['product_id']) || empty($data['affiliate_id'])) {
							continue;
						}

						$affiliate_product_id = (int) $data['product_id'];

						if ((int) $affiliate_product_id !== (int) $order_product_id) {
							$affiliate_product = wc_get_product($affiliate_product_id);
							if ($affiliate_product && $affiliate_product->is_type('grouped')) {
								$grouped_children = $affiliate_product->get_children();
								if (!in_array($order_product_id, $grouped_children)) {
									continue;
								}
							} else {
								continue;
							}
						}


						$affiliate_product = wc_get_product($affiliate_product_id);
						if (!$affiliate_product) {
							continue;
						}

						$base_data = array(
							'product_id'   => $affiliate_product->is_type('variation') ? $affiliate_product->get_parent_id() : $affiliate_product->get_id(),
							'affiliate_id' => $data['affiliate_id'],
							'token'        => $data['token'],
							'commission'   => $data['commission'],
							'commission_type'   => $data['commission_type'],
						);

						if ($affiliate_product->is_type('grouped')) {
							$children = array();
							$child_ids = $affiliate_product->get_children();
							foreach ($child_ids as $child_id) {
								$children[] = array(
									'product_id'   => $child_id,
									'affiliate_id' => $data['affiliate_id'],
									'token'        => $data['token'],
									'commission'   => $data['commission'],
									'commission_type'   => $data['commission_type'],
								);
							}
							$base_data['children'] = $children;
						}

						$filtered_array[] = $base_data;
					}
				}

				// Remove duplicates by product_id + affiliate_id
				$unique_filtered = array();
				$seen = array();

				foreach ($filtered_array as $entry) {
					$key = $entry['product_id'] . '_' . $entry['affiliate_id'];
					if (!isset($seen[ $key ])) {
						$seen[ $key ] = true;
						$unique_filtered[] = $entry;
					}
				}

				$filtered_array = $unique_filtered;

				foreach ($filtered_array as $entry) {
					$product_id     = $entry['product_id'];
					$affiliate_id   = $entry['affiliate_id'];
					$referral_token = $entry['token'];
					$commission     = $entry['commission'];
					$commission_type     = $entry['commission_type'];
					$commission_rate = floatval(0);
					if ($commission <= 0) {
						return;
					}
					if (empty($product_id) || empty($affiliate_id)) {
						continue;
					}

					$user_meta    = get_user_meta($affiliate_id);
					$user_data    = get_user_by('ID', $affiliate_id);
					$username     = isset($user_data->user_login) ? $user_data->user_login : 'unknown';
					$user_email   = isset($user_data->user_email) ? $user_data->user_email : 'unknown';
					if ('fixed' == $commission_type) {
						$commission_rate = $commission;
					} else {
						$commission_rate = $commission / 100;
					}

					$payout_amount = floatval(0);
					$commission_amount = floatval(0);
					$product_name = '';
					$total_product_amount = floatval(0);

					if (isset($entry['children'])) {
						$total_price = floatval(0);

						foreach ($entry['children'] as $child) {
							foreach ($order->get_items() as $item) {
								$item_product = $item->get_product();
								if (!$item_product) {
									continue;
								}

								$item_product_id = $item_product->is_type('variation') ? $item_product->get_parent_id() : $item_product->get_id();

								if ($item_product_id == $child['product_id']) {
									$line_total = floatval($item->get_total()); // Excludes tax, use get_total()  if needed
									$total_price += $line_total;
								}
							}
						}
						if ('fixed' == $commission_type) {
							$payout_amount = $commission_rate;
							$commission_amount = $commission_rate;
						} else {
							$payout_amount = $total_price * $commission_rate;
							$commission_amount = $total_price * $commission_rate;
						}


						$product = wc_get_product($product_id);
						$product_name = $product ? $product->get_name() : 'Grouped Product';
					} else {
						foreach ($order->get_items() as $item) {
							$item_product = $item->get_product();
							if (!$item_product) {
								continue;
							}

							$item_product_id = $item_product->is_type('variation') ? $item_product->get_parent_id() : $item_product->get_id();

							if ($item_product_id == $product_id) {
								$line_total = $item->get_total(); // Excludes tax

								if ('fixed' == $commission_type) {
									$payout_amount =  $commission_rate;
									$commission_amount =  $commission_rate;
								} else {
									$payout_amount = $line_total * $commission_rate;
									$commission_amount = $line_total * $commission_rate;
								}

								$product = wc_get_product($product_id);
								$product_name = $product ? $product->get_name() : 'Simple Product';
								$total_product_amount = $product ? $line_total : 0;
								break;
							}
						}
					}


					if (!empty($user_meta['unpaid_amount'][0])) {
						$payout_amount += floatval($user_meta['unpaid_amount'][0]);
					}



					// Check if a commission already exists for this product and order ID
					$existing_commissions = get_posts(array(
						'post_type'   => 'commission_post',
						'post_status' => 'any',
						'numberposts' => -1,
					));

					$should_skip = false;

					foreach ($existing_commissions as $existing_commission) {
						$existing_order_id   = get_post_meta($existing_commission->ID, 'order_id', true);
						$existing_product_id = get_post_meta($existing_commission->ID, 'product_id', true);

						if ($existing_order_id == $order_id && $existing_product_id == $product_id) {
							$should_skip = true;
							break;
						}
					}

					if ($should_skip) {
						continue;
					}

					$commission_id = wp_insert_post(array(
						'post_type'   => 'commission_post',
						'post_status' => 'publish',
						'post_title'  =>  $affiliate_id,
					));

					if ($commission_id  && $commission_amount > 0) {
						if (isset($user_meta['notify_new_commission'][0]) && 'yes' === $user_meta['notify_new_commission'][0]) {
							$new_form_data = array(
								'affiliate_id'      => $affiliate_id,
								'commission_id'     => $commission_id,
								'commission_amount' => $commission_amount,
								'User_name'         => $username,
								'User_email'        => $user_email,
								'affiliate_email'   => $user_email,
							);

							$mailer = WC()->mailer();
							$email  = $mailer->emails['Addify_Ad_Pr_Affiliate_New_Commission_Email'];
							if ($email) {
								$email->trigger($new_form_data);
							}
							$mailer = WC()->mailer();
							$email  = $mailer->emails['Addify_Ad_Pr_Affiliate_New_Commission_Customer_Email'];
							if ($email) {
								$email->trigger($new_form_data);
							}
						}

						update_post_meta($commission_id, 'order_id', $order_id);
						update_post_meta($commission_id, 'affiliate_id', $affiliate_id);
						update_post_meta($commission_id, 'user_name', $username);
						update_post_meta($commission_id, 'product_id', $product_id);
						update_post_meta($commission_id, 'product_name', $product_name);
						update_post_meta($commission_id, 'referral_token', $referral_token);
						update_post_meta($commission_id, 'affiliation_type', 'Product');
						update_post_meta($commission_id, 'commission_rate', $commission);
						update_post_meta($commission_id, 'commission_type', $commission_type);
						update_post_meta($commission_id, 'unpaid_amount', $commission_amount);
						update_post_meta($commission_id, 'total_product_amount', $total_product_amount);
						update_post_meta($commission_id, 'date', gmdate('Y-m-d'));

						// ✅ Update affiliate unpaid balance
						update_user_meta($affiliate_id, 'unpaid_amount', $payout_amount);

						// Find existing payout post
						$existing_payout = get_posts(array(
							'post_type'   => 'payout_post',
							'post_status' => 'any',
							'fields'      => 'ids',
							'numberposts' => -1,
						));

						$matching_payout = null;
						foreach ($existing_payout as $post_id) {
							if (get_post_meta($post_id, 'affiliate_id', true) == $affiliate_id) {
								$matching_payout = $post_id;
								break;
							}
						}
						$payout_data = get_post_meta($matching_payout, 'payout_data', true);

						// make sure it's an array
						if (!is_array($payout_data)) {
							$payout_data = array();
						}
						if (!empty($matching_payout)) {
							update_post_meta($matching_payout, 'order_id', $order_id);
							update_post_meta($matching_payout, 'product_id', $product_id);
							update_post_meta($matching_payout, 'referral_token', $referral_token);
							update_post_meta($matching_payout, 'unpaid_amount', $payout_amount);
							update_post_meta($matching_payout, 'user_name', $username);
							$payout_data[] = array(
								'amount'  => $commission_amount,
								'status'  => 'unpaid',
								'created' => current_time('mysql'),
							);

							update_post_meta($matching_payout, 'payout_data', $payout_data);
						} else {
							$payout_id = wp_insert_post(array(
								'post_type'   => 'payout_post',
								'post_status' => 'publish',
								'post_title'  => $affiliate_id,
							));

							if ($payout_id) {
								update_post_meta($payout_id, 'order_id', $order_id);
								update_post_meta($payout_id, 'product_id', $product_id);
								update_post_meta($payout_id, 'affiliate_id', $affiliate_id);
								update_post_meta($payout_id, 'referral_token', $referral_token);
								update_post_meta($payout_id, 'unpaid_amount', $payout_amount);
								update_post_meta($payout_id, 'user_name', $username);
								$payout_data[] = array(
									'amount'  => $commission_amount,
									'status'  => 'unpaid',
									'created' => current_time('mysql'),
								);

								update_post_meta($payout_id, 'payout_data', $payout_data);
							}
						}


						/**
						 * Track transaction in hourly_stats for analytics.
						 */
						$wp_timezone = get_option('timezone_string');
						if (!$wp_timezone) {
							$offset = (float) get_option('gmt_offset');
							$sign   = ( $offset <= 0 ) ? '+' : '-';
							$hours  = abs($offset);
							$wp_timezone = 'Etc/GMT' . $sign . $hours;
						}

						$tz = new DateTimeZone($wp_timezone);
						$now = new DateTime('now', $tz);
						$hour_key = $now->format('Y-m-d H:00'); // e.g. "2025-07-21 13:00"

						// Fetch affiliate posts for this affiliate
						$affiliates = get_posts(array(
							'post_type'      => 'affiliate_user_post',
							'posts_per_page' => -1,
							'post_status'    => 'publish',
							'author'         => $affiliate_id,
						));

						foreach ($affiliates as $affiliate) {
							$hourly_log = get_post_meta($affiliate->ID, 'hourly_stats', true);
							if (!is_array($hourly_log)) {
								$hourly_log = array();
							}

							// Make sure bucket exists
							if (!isset($hourly_log[ $hour_key ])) {
								$hourly_log[ $hour_key ] = array(
									'clicks'   => 0,
									'paid'     => 0,
									'unpaid'   => 0,
									'earnings' => 0,
									'refunds'  => 0,
								);
							}

							// Increment metrics correctly
							$hourly_log[ $hour_key ]['unpaid']   += (float) $commission_amount;
							$hourly_log[ $hour_key ]['earnings'] += (float) $commission_amount;

							update_post_meta($affiliate->ID, 'hourly_stats', $hourly_log);
						}
					}
				}
			}
		}



		public function affiliate_check_order_affiliation( $order ) {

			if (WC()->cart->get_applied_coupons()) {

				$coupon_codes = WC()->cart->get_applied_coupons();

				foreach ($coupon_codes as $code) {
					$coupon = new WC_Coupon($code);

					// Get affiliate user ID from coupon
					$affiliate_id = get_post_meta($coupon->get_id(), 'addify_affiliate_user_id', true);

					if (empty($affiliate_id)) {
						continue; // No affiliate tied to this coupon
					}

					$commission_rate  = 0;
					$commission_type  = 'fixed'; // default type
					$affiliate_status = get_user_meta($affiliate_id, 'affiliate_user_status', true);

					// Skip if affiliate not approved
					if ('approved' !== $affiliate_status) {
						continue;
					}

					// Get unpaid/total amounts (used for tiered commission)

					$payout_post = get_posts(array(
						'post_type'      => 'payout_post',
						'posts_per_page' => -1,
						'post_status'    => 'publish',
					));

					foreach ($payout_post as $key => $value) {
						$payout_post_id = $value->ID;
						$payout_post_title = $value->post_title;
						if ($payout_post_title == $affiliate_id && '' !== get_post_meta($payout_post_id, 'unpaid_amount', true)) {
							$unpaid_amount = number_format(get_post_meta($payout_post_id, 'unpaid_amount', true), 2);
						}
					}
					// get affiliate post by affiliate id
					$affiliate_post = get_posts(array(
						'post_type'      => 'affiliate_user_post',
						'posts_per_page' => 1,
						'post_status'    => 'publish',
						'author'         => $affiliate_id,
					));
					foreach ($affiliate_post as $affiliate) {

						if ('' !== get_post_meta($affiliate->ID, 'payout_save_paid_amount', true)) {
							$paid_amount = (float) get_post_meta($affiliate->ID, 'payout_save_paid_amount', true);
						}
					}

					$total_amount = $unpaid_amount + $paid_amount;


					// Apply tiered commission rules first (if any)
					$price_rules = get_option('Addify_Af_Pr_affiliate_setting_price_adjustment_table', array());
					$mode = get_option('Addify_Af_Pr_specific_affiliate_include_exclude', 'include'); // 'include' or 'exclude'
					if (is_array($mode)) {
						$mode = reset($mode);
					}
					$mode = isset($mode) ? $mode : 'include'; // fallback if empty


					$affiliates_list = (array) get_option('Addify_Af_Pr_specific_affiliate_include_exclude_value', array());
					$eligible_for_tiered = true;

					$matched_rule = false;

					// Skip tiered pricing if excluded
					if ('exclude' === $mode && in_array($affiliate_id, $affiliates_list)) {
						$eligible_for_tiered = false;
					}

					// Skip tiered pricing if "include" mode but this affiliate is NOT in the include list
					if ('include' === $mode && !empty($affiliates_list) && !in_array($affiliate_id, $affiliates_list)) {
						$eligible_for_tiered = false;
					}

					// Apply tiered pricing if rules exist
					if (!empty($price_rules) && true == $eligible_for_tiered) {
						foreach ($price_rules as $rule) {
							if (1 == $rule['status']) {
								$from = isset($rule['earning_from']) ? (float) $rule['earning_from'] : 0;
								$to   = isset($rule['earning_to']) ? (float) $rule['earning_to'] : 0;
								$rate = isset($rule['commission_rate']) ? (float) $rule['commission_rate'] : 0;
								$type = isset($rule['commission_rate_type']) ? $rule['commission_rate_type'] : 'fixed';

								if ($total_amount >= $from && $total_amount <= $to) {
									$commission_rate = $rate;
									$commission_type = $type;
									$matched_rule    = true;
									break;
								}
							}
						}
					}



					// If no tiered rule matched, get affiliate-specific commission meta
					if (!$matched_rule) {
						$affiliate_post = get_posts(array(
							'post_type'      => 'affiliate_user_post',
							'posts_per_page' => 1,
							'post_status'    => 'publish',
							'author'         => $affiliate_id,
						));

						if (!empty($affiliate_post)) {
							$affiliate_post_id = $affiliate_post[0]->ID;
							$rate = get_post_meta($affiliate_post_id, 'Addify_Af_Pr_affiliate_commission_rate', true);
							$type = get_post_meta($affiliate_post_id, 'Addify_Af_Pr_affiliate_commission_rate_type', true);

							$commission_rate = ( '' !== $rate ) ? (float) $rate : 0;
							$commission_type = ( '' !== $type ) ? $type : 'fixed';
						}
					}

					// Save affiliate commission info to order
					$order->update_meta_data('affiliate_coupon_order_data', array(
						'coupon_code'      => $coupon->get_code(),
						'affiliate_id'     => $affiliate_id,
						'commission'       => $commission_rate,
						'commission_type'  => $commission_type,
					));
					$order->save();
				}
			} elseif (isset($_COOKIE['affiliate_product_ref'])) {
				$decoded_data = json_decode(sanitize_text_field(wp_unslash($_COOKIE['affiliate_product_ref'])), true);
				$order->update_meta_data('affiliate_order_data', $decoded_data);
				$order->save();
			}
		}


		public function capture_affiliate_reference() {

			if (!is_product()) {
				return;
			}

			$product_id = get_queried_object_id();

			$user_id = get_current_user_id();
			$user = get_userdata($user_id);
			$user_roles = $user ? $user->roles : array();
			$user_roles = isset($user_roles[0]) ? $user_roles[0] : 'guest';
			$user_remote_address = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';
			$get_user_remote_address = get_user_meta($user_id, 'user_remote_address', true);

			$Addify_Af_Pr_specific_affiliate_restrict = get_option('Addify_Af_Pr_specific_affiliate_restrict', array());
			$Addify_Af_Pr_roles_selected = get_option('Addify_Af_Pr_roles_selected', array());


			$selected = false;

			if (!empty($affiliates)) {
				foreach ($affiliates as $affiliate) {
					if (in_array($affiliate->ID, (array) $Addify_Af_Pr_specific_affiliate_restrict)) {
						$selected = true;
						break;
					}
				}
			}

			if (true === $selected  || in_array($user_roles, (array) $Addify_Af_Pr_roles_selected)) {
				wp_die(esc_html__('You are not allowed to use this link.', 'addify-affiliate-program'));
			}


			$get_referral_token = filter_input(INPUT_GET, 'ref', FILTER_SANITIZE_FULL_SPECIAL_CHARS);

			if (!empty($get_referral_token)) {
				$Addify_Af_Pr_affiliate_setting_prevent_own_referral = get_option('Addify_Af_Pr_affiliate_setting_prevent_own_referral');

				if ($user_remote_address == $get_user_remote_address && 'yes' == $Addify_Af_Pr_affiliate_setting_prevent_own_referral) {
					wp_die(esc_html__('You are not allowed to use this link.', 'addify-affiliate-program'));
				}

				$affiliate_id = sanitize_text_field(wp_unslash($get_referral_token));

				$affiliates = get_posts(array(
					'post_type'      => 'affiliate_user_post',
					'posts_per_page' => -1,
					'post_status'    => 'publish',
					'author'         => $affiliate_id,
				));
				$wp_timezone = get_option('timezone_string');

				if (!$wp_timezone) {
					$offset = (float) get_option('gmt_offset');
					$sign   = ( $offset <= 0 ) ? '+' : '-';
					$hours  = abs($offset);
					$wp_timezone = 'Etc/GMT' . $sign . $hours;
				}

				$tz = new DateTimeZone($wp_timezone);
				$now = new DateTime('now', $tz);
				$key = $now->format('Y-m-d H:00'); // Hourly bucket

				foreach ($affiliates as $affiliate) {
					$hourly_log = get_post_meta($affiliate->ID, 'hourly_stats', true);
					if (!is_array($hourly_log)) {
						$hourly_log = array();
					}

					// Ensure bucket exists without resetting existing data
					if (!isset($hourly_log[ $key ])) {
						$hourly_log[ $key ] = array(
							'clicks'   => 0,
							'paid'     => 0,
							'unpaid'   => 0,
							'earnings' => 0,
							'refunds'  => 0,
						);
					}

					$hourly_log[ $key ]['clicks']++;

					update_post_meta($affiliate->ID, 'hourly_stats', $hourly_log);

					$total_clicks = (int) get_post_meta($affiliate->ID, 'total_clicks', true);
					update_post_meta($affiliate->ID, 'total_clicks', $total_clicks + 1);
				}

				$links = get_option('addify_affiliate_links' . $affiliate_id, array());

				$request_uri = isset($_SERVER['REQUEST_URI']) ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'])) : '';

				$current_url_path  = wp_parse_url($request_uri, PHP_URL_PATH);
				$current_url_query = wp_parse_url($request_uri, PHP_URL_QUERY);

				$link_found = false;

				foreach ($links as $link_data) {
					$parsed_link_path = wp_parse_url($link_data['link'], PHP_URL_PATH);
					$parsed_link_query = wp_parse_url($link_data['link'], PHP_URL_QUERY);

					$expected_path = rawurldecode(trim($parsed_link_path));
					$expected_query = rawurldecode(trim($parsed_link_query));

					$current_path = rawurldecode(trim($current_url_path));
					$current_query = rawurldecode(trim($current_url_query));

					$expected_full = $expected_path . ( $expected_query ? '?' . $expected_query : '' );
					$current_full = $current_path . ( $current_query ? '?' . $current_query : '' );


					if ($current_full === $expected_full) {
						$link_found = true;

						$expiry_date = $link_data['expiry'];
						$today = gmdate('Y-m-d');

						if ($today >= $expiry_date) {
							setcookie('affiliate_product_ref', '', time() - 3600 * 24, COOKIEPATH, COOKIE_DOMAIN);
							unset($_COOKIE['affiliate_product_ref']);
							wp_die(esc_html__('This affiliate link has expired.', 'addify-affiliate-program'));
						}



						$cookie_data = array();

						// Check if the cookie exists and is a valid JSON array
						if (isset($_COOKIE['affiliate_product_ref'])) {
							$decoded_data = json_decode(sanitize_text_field(wp_unslash($_COOKIE['affiliate_product_ref'])), true);
							if (is_array($decoded_data) && isset($decoded_data[0])) {
								$cookie_data = $decoded_data;
							} elseif (is_array($decoded_data) && isset($decoded_data['product_id'])) {
								// Old single-entry structure — convert to array
								$cookie_data[] = $decoded_data;
							}
						}


						$already_exists = false;
						foreach ($cookie_data as $entry) {
							if (
								isset($entry['product_id'], $entry['affiliate_id']) &&
								$entry['product_id'] == $product_id &&
								$entry['affiliate_id'] == $affiliate_id
							) {
								// If duplicate found, clear the cookie entirely
								setcookie('affiliate_product_ref', '', time() - 3600, COOKIEPATH, COOKIE_DOMAIN);
								unset($_COOKIE['affiliate_product_ref']);
								$already_exists = true;
								break;
							}
						}

						if (!$already_exists) { // Add updated entry
							$cookie_data[] = array(
								'product_id'   => $product_id,
								'affiliate_id' => $affiliate_id,
								'token'        => 'ref',
								'commission'   => $link_data['commission'],
								'commission_type'   => $link_data['commission_type'],
							);
						}

						// Store the updated array back into the cookie
						setcookie(
							'affiliate_product_ref',
							json_encode($cookie_data),
							time() + 3600 * 24,
							COOKIEPATH,
							COOKIE_DOMAIN
						);

						$_COOKIE['affiliate_product_ref'] = json_encode($cookie_data);
					}
				}


				if (!$link_found) {
					wp_die(esc_html__('Invalid or unauthorized affiliate link.', 'addify-affiliate-program'));
				}
			}
		}
	}

	new Addify_Affiliate_Product_Page();
endif;
