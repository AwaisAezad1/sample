<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$addify_ad_pr_affiliate_name = isset( $data['{affiliate_name}'] ) ? sanitize_text_field( $data['{affiliate_name}'] ) : '';
$addify_ad_pr_site_name      = isset( $data['{site_name}'] ) ? sanitize_text_field( $data['{site_name}'] ) : '';
$addify_ad_pr_login_url      = wp_login_url();
$addify_ad_pr_addify_blog_name      = get_bloginfo( 'name' );

// Build plain text message
$addify_ad_pr_message  = '🎉 ' . esc_html__( 'Welcome to Our Affiliate Program!', 'addify-affiliate-program' ) . "\n\n";

$addify_ad_pr_message .= sprintf(
	/* translators: %s: affiliate name */
	esc_html__( 'Hello %s,', 'addify-affiliate-program' ),
	$addify_ad_pr_affiliate_name
) . "\n\n";

$addify_ad_pr_message .= '✅ ' . esc_html__( 'Congratulations — your affiliate registration has been approved!', 'addify-affiliate-program' ) . "\n\n";

$addify_ad_pr_message .= sprintf(
	/* translators: %s: site name */
	esc_html__( 'You are now an approved affiliate for %s. You can log in to your account to find your referral links, view commissions, and start promoting.', 'addify-affiliate-program' ),
	$addify_ad_pr_site_name
) . "\n\n";

$addify_ad_pr_message .= esc_html__( 'What you can do now:', 'addify-affiliate-program' ) . "\n";
$addify_ad_pr_message .= ' - ' . esc_html__( 'Access your unique referral links', 'addify-affiliate-program' ) . "\n";
$addify_ad_pr_message .= ' - ' . esc_html__( 'Track your commissions and earnings', 'addify-affiliate-program' ) . "\n";
$addify_ad_pr_message .= ' - ' . esc_html__( 'View performance reports and analytics', 'addify-affiliate-program' ) . "\n";
$addify_ad_pr_message .= ' - ' . esc_html__( 'Start promoting and earning commissions', 'addify-affiliate-program' ) . "\n\n";

$addify_ad_pr_message .= sprintf(
	/* translators: %s: login link */
	esc_html__( 'Login here: %s', 'addify-affiliate-program' ),
	$addify_ad_pr_login_url
) . "\n\n";

$addify_ad_pr_message .= '💡 ' . esc_html__( "Need Help? If you have any questions, reply to this email or contact our support team. We're here to help you succeed!", 'addify-affiliate-program' ) . "\n\n";

$addify_ad_pr_message .= esc_html__( 'Thank you for joining our program!', 'addify-affiliate-program' ) . "\n";
$addify_ad_pr_message .= $addify_ad_pr_addify_blog_name;

echo esc_html( $addify_ad_pr_message );
