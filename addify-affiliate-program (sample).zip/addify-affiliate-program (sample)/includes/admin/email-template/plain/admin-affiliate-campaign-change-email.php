<?php
if (!defined('ABSPATH')) {
	exit;
}

$addify_ad_pr_affiliate_name  = isset($new_form_data['{affiliate_name}']) ? $new_form_data['{affiliate_name}'] : '';
$addify_ad_pr_campaign_name   = isset($new_form_data['{campaign_name}']) ? $new_form_data['{campaign_name}'] : '';
$addify_ad_pr_changes_summary = isset($new_form_data['{changes_summary}']) ? wp_strip_all_tags($new_form_data['{changes_summary}']) : '';
$addify_ad_pr_effective_date  = isset($new_form_data['{effective_date}']) ? $new_form_data['{effective_date}'] : '';
printf(
	// translators: %s: customer name.
esc_html__(
'Hello %1$s,

We wanted to inform you about important updates to your affiliate campaign.

Campaign Name: %2$s
Effective Date: %3$s

Summary of Changes:
%4$s

Please review these changes and adjust your promotions accordingly.
If you have any questions, contact our support team.

Thank you for being a valued affiliate partner!
%5$s',
'addify-affiliate-program'
),
esc_html($addify_ad_pr_affiliate_name, 'addify-affiliate-program'),
esc_html($addify_ad_pr_campaign_name, 'addify-affiliate-program'),
esc_html($addify_ad_pr_effective_date, 'addify-affiliate-program'),
esc_html($addify_ad_pr_changes_summary, 'addify-affiliate-program'),
esc_html(get_bloginfo('name'))
);
