<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$addify_ad_pr_affiliate_name = isset( $data['{affiliate_name}'] ) ? sanitize_text_field( $data['{affiliate_name}'] ) : '';
$addify_ad_pr_site_name      = isset( $data['{site_name}'] ) ? sanitize_text_field( $data['{site_name}'] ) : '';
$addify_ad_pr_contact_url    = admin_url( 'admin.php?page=addify-affiliate-support' ); // adjust if needed
?>
<?php 
	printf( 
	// translators: %s: affiliate name
	esc_html__( 'Hello %s,', 'addify-affiliate-program' ), esc_html($addify_ad_pr_affiliate_name) );
	?>


<?php esc_html__( 'We appreciate your interest in joining our affiliate program. After review, we are sorry to inform you that your application has not been approved.', 'addify-affiliate-program' ); ?>


<?php
printf( 
	// translators: %1$s: site name; %2$s: support link label (plain text)
	esc_html__( 'If you would like more information about this decision or believe there has been a mistake, please contact support for %s.', 'addify-affiliate-program' ), esc_html($addify_ad_pr_site_name) );
?>

<?php
printf( 
	// translators: %1$s: site name; %2$s: support link label (plain text)
	esc_html__( 'Support: %s', 'addify-affiliate-program' ), esc_url($addify_ad_pr_contact_url) );
?>


<?php esc_html__( 'Thank you for your interest, and we wish you the best of luck.', 'addify-affiliate-program' ); ?>

<?php
echo esc_html( get_bloginfo( 'name' ) ); 
