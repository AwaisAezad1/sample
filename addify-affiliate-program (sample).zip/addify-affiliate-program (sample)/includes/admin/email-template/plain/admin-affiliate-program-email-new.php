<?php
if (!defined('ABSPATH')) {
	exit;
}

// Extract and sanitize data
$addify_ad_pr_affiliate_id       = isset($new_form_data['{affiliate_id}']) ? esc_html($new_form_data['{affiliate_id}']) : '';
$addify_ad_pr_user_name          = isset($new_form_data['{User_name}']) ? esc_html($new_form_data['{User_name}']) : '';
$addify_ad_pr_addify_user_email  = isset($new_form_data['{User_email}']) ? esc_html($new_form_data['{User_email}']) : '';
$addify_ad_pr_blog_name          = esc_html(get_bloginfo('name'));

// Plain text output
$addify_ad_pr_message  = '👥 ' . esc_html__('New Affiliate Registration', 'addify-affiliate-program') . "\n\n";
$addify_ad_pr_message .= esc_html__('Affiliate Details:', 'addify-affiliate-program') . "\n";
$addify_ad_pr_message .= "----------------------------------------\n";
$addify_ad_pr_message .= sprintf("%-15s | #%s\n", esc_html__('Affiliate ID', 'addify-affiliate-program'), $addify_ad_pr_affiliate_id);
$addify_ad_pr_message .= sprintf("%-15s | %s\n", esc_html__('Name', 'addify-affiliate-program'), $addify_ad_pr_user_name);
$addify_ad_pr_message .= sprintf("%-15s | %s\n", esc_html__('Email', 'addify-affiliate-program'), $addify_ad_pr_addify_user_email);
$addify_ad_pr_message .= "----------------------------------------\n\n";
$addify_ad_pr_message .= esc_html__('Next Steps:', 'addify-affiliate-program') . "\n";
$addify_ad_pr_message .= esc_html__('Please review the new affiliate registration in your admin dashboard and process accordingly.', 'addify-affiliate-program') . "\n\n";
$addify_ad_pr_message .= esc_html__('Thank you,', 'addify-affiliate-program') . "\n";
$addify_ad_pr_message .= $addify_ad_pr_blog_name . "\n\n";
$addify_ad_pr_message .= esc_html__('This is an automated notification. New affiliate registrations require admin approval.', 'addify-affiliate-program');

echo esc_html($addify_ad_pr_message);
