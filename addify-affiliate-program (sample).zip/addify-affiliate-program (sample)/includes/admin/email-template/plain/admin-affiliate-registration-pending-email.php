<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$addify_ad_pr_affiliate_name = isset( $data['{affiliate_name}'] ) ? sanitize_text_field( $data['{affiliate_name}'] ) : '';
$addify_ad_pr_site_name      = isset( $data['{site_name}'] ) ? sanitize_text_field( $data['{site_name}'] ) : '';
?>

<?php
printf(
	/* translators: %s: affiliate name */
	esc_html__( 'Hello %s,', 'addify-affiliate-program' ),
	esc_html( $addify_ad_pr_affiliate_name )
);
?>

<?php esc_html_e( 'Thanks for applying to join our affiliate program. Your application is currently under review.', 'addify-affiliate-program' ); ?>


<?php
printf(
	/* translators: %s: site name */
	esc_html__( 'We will review your application and notify you once a decision is made. Thank you for your interest in promoting %s.', 'addify-affiliate-program' ),
	esc_html( $addify_ad_pr_site_name )
);
?>


<?php esc_html_e( 'If you need to update your application or provide additional information, please reply to this email or contact our support team.', 'addify-affiliate-program' ); ?>


<?php esc_html_e( 'Thank you for your patience and understanding.', 'addify-affiliate-program' ); ?>


<?php
echo esc_html( get_bloginfo( 'name' ) );

