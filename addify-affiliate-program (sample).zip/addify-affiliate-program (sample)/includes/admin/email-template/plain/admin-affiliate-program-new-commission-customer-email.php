<?php
if (!defined('ABSPATH')) {
	exit;
}

// Extract and sanitize data
$addify_ad_pr_affiliate_id       = isset($new_form_data['{affiliate_id}']) ? esc_html($new_form_data['{affiliate_id}']) : '';
$addify_ad_pr_commission_id      = isset($new_form_data['{commission_id}']) ? esc_html($new_form_data['{commission_id}']) : '';
$addify_ad_pr_commission_amount  = isset($new_form_data['{commission_amount}']) ? esc_html($new_form_data['{commission_amount}']) : '';
$addify_ad_pr_user_name          = isset($new_form_data['{User_name}']) ? esc_html($new_form_data['{User_name}']) : '';
$addify_ad_pr_addify_user_email  = isset($new_form_data['{User_email}']) ? esc_html($new_form_data['{User_email}']) : '';
$addify_ad_pr_addify_blog_name          = esc_html(get_bloginfo('name'));
$addify_ad_pr_year_date               = gmdate('Y');

// Plain text output
$addify_ad_pr_message  = '🎉 ' . esc_html__('New Commission Earned!', 'addify-affiliate-program') . "\n\n";
$addify_ad_pr_message .= sprintf(
	// translators: %s: customer name.
	esc_html__('Hello %s,', 'addify-affiliate-program'),
	$addify_ad_pr_user_name
) . "\n\n";

$addify_ad_pr_message .= esc_html__('Great news! You have earned a new commission through our affiliate program.', 'addify-affiliate-program') . "\n\n";

$addify_ad_pr_message .= esc_html__('Commission Details:', 'addify-affiliate-program') . "\n";
$addify_ad_pr_message .= "----------------------------------------\n";
$addify_ad_pr_message .= sprintf("%-20s | #%s\n", esc_html__('Commission ID', 'addify-affiliate-program'), $addify_ad_pr_commission_id);
$addify_ad_pr_message .= sprintf("%-20s | #%s\n", esc_html__('Affiliate ID', 'addify-affiliate-program'), $addify_ad_pr_affiliate_id);
$addify_ad_pr_message .= sprintf("%-20s | %s\n", esc_html__('Commission Amount', 'addify-affiliate-program'), $addify_ad_pr_commission_amount);
$addify_ad_pr_message .= sprintf("%-20s | %s\n", esc_html__('Email', 'addify-affiliate-program'), $addify_ad_pr_addify_user_email);
$addify_ad_pr_message .= "----------------------------------------\n\n";

$addify_ad_pr_message .= esc_html__('You can view detailed reports and track your earnings in your affiliate dashboard.', 'addify-affiliate-program') . "\n\n";
$addify_ad_pr_message .= esc_html__('Thank you for being a valuable member of our affiliate community!', 'addify-affiliate-program') . "\n\n";
$addify_ad_pr_message .= esc_html__('Keep sharing and earning!', 'addify-affiliate-program') . "\n\n";

$addify_ad_pr_message .= esc_html__('If you have any questions about your commission, please contact our support team.', 'addify-affiliate-program') . "\n";
$addify_ad_pr_message .= "© {$addify_ad_pr_year_date} {$addify_ad_pr_addify_blog_name}. " . esc_html__('All rights reserved.', 'addify-affiliate-program');

echo esc_html($addify_ad_pr_message);
