<?php
if (!defined('ABSPATH')) {
	exit;
}

// Extract and sanitize data
$addify_ad_pr_affiliate_id  = isset($new_form_data['{affiliate_id}']) ? esc_html($new_form_data['{affiliate_id}']) : '';
$addify_ad_pr_paid_amount = isset($new_form_data['{paid_amount}']) ? esc_html($new_form_data['{paid_amount}']) : '';
$addify_ad_pr_user_name     = isset($new_form_data['{User_name}']) ? esc_html($new_form_data['{User_name}']) : '';
$addify_ad_pr_addify_user_email    = isset($new_form_data['{User_email}']) ? esc_html($new_form_data['{User_email}']) : '';
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<style>
		body {
			font-family: Arial, sans-serif;
			line-height: 1.6;
			color: #333;
			max-width: 600px;
			margin: 0 auto;
			padding: 20px;
			background-color: #f9f9f9;
		}
		.email-container {
			background: #ffffff;
			border-radius: 8px;
			padding: 30px;
			box-shadow: 0 2px 10px rgba(0,0,0,0.1);
		}
		.header {
			text-align: center;
			margin-bottom: 30px;
			border-bottom: 2px solid #f0f0f0;
			padding-bottom: 20px;
		}
		.header h1 {
			color: #27ae60;
			margin: 0;
			font-size: 24px;
		}
		.content {
			margin-bottom: 30px;
		}
		.greeting {
			font-size: 16px;
			margin-bottom: 20px;
		}
		.success-alert {
			background: #d4edda;
			border-left: 4px solid #28a745;
			padding: 25px;
			border-radius: 4px;
			margin: 25px 0;
			text-align: center;
		}
		.amount-display {
			font-size: 24px;
			font-weight: bold;
			color: #27ae60;
			margin: 15px 0;
		}
		.affiliate-details {
			background: #f8f9fa;
			border-left: 4px solid #3498db;
			padding: 20px;
			border-radius: 4px;
			margin: 25px 0;
		}
		.detail-row {
			display: flex;
			justify-content: space-between;
			margin-bottom: 12px;
			padding: 8px 0;
			border-bottom: 1px solid #eee;
		}
		.detail-label {
			font-weight: bold;
			color: #555;
			min-width: 120px;
		}
		.detail-value {
			color: #2c3e50;
			text-align: right;
		}
		.thank-you {
			text-align: center;
			margin: 25px 0;
			padding: 20px;
			background: #e7f4ff;
			border-radius: 4px;
			border-left: 4px solid #3498db;
		}
		.signature {
			text-align: center;
			margin-top: 30px;
			padding-top: 20px;
			border-top: 2px solid #f0f0f0;
		}
		.team-name {
			font-weight: bold;
			color: #2c3e50;
		}
		.footer {
			text-align: center;
			margin-top: 30px;
			color: #7f8c8d;
			font-size: 14px;
		}
	</style>
</head>
<body>
	<div class="email-container">
		<div class="header">
			<h1>✅ <?php esc_html_e('Payment Confirmed!', 'addify-affiliate-program'); ?></h1>
		</div>

		<div class="content">
			<div class="greeting">
				<p>
					<?php
					printf(
						/* translators: %s: Affiliate Name */
						esc_html__('Dear %s,', 'addify-affiliate-program'),
						'<strong>' . esc_html($addify_ad_pr_user_name) . '</strong>'
					);
					?>
				</p>
			</div>

			<div class="success-alert">
				<p>🎉 <?php esc_html_e('Great news! Your commission has been paid.', 'addify-affiliate-program'); ?></p>
				<div class="amount-display">
					<?php
					printf(
						esc_html('%1$s', 'addify-affiliate-program'),
						esc_html($addify_ad_pr_paid_amount)
					);
					?>
				</div>
				<p><?php esc_html_e('has been successfully processed and sent to your account.', 'addify-affiliate-program'); ?></p>
			</div>

			<div class="affiliate-details">
				<h3 style="margin-top: 0; color: #2c3e50;"><?php esc_html_e('Transaction Details:', 'addify-affiliate-program'); ?></h3>
				
				<div class="detail-row">
					<span class="detail-label"><?php esc_html_e('Affiliate ID:', 'addify-affiliate-program'); ?></span>
					<span class="detail-value">#<?php echo esc_html($addify_ad_pr_affiliate_id); ?></span>
				</div>
				
				<div class="detail-row">
					<span class="detail-label"><?php esc_html_e('Email:', 'addify-affiliate-program'); ?></span>
					<span class="detail-value"><?php echo esc_html($addify_ad_pr_addify_user_email); ?></span>
				</div>
				
				<div class="detail-row">
					<span class="detail-label"><?php esc_html_e('Status:', 'addify-affiliate-program'); ?></span>
					<span class="detail-value" style="color: #27ae60;">✅ <?php esc_html_e('Paid', 'addify-affiliate-program'); ?></span>
				</div>
			</div>

			<div class="thank-you">
				<p>🙏 <?php esc_html_e('Thank you for being a valued partner and for your continued support!', 'addify-affiliate-program'); ?></p>
			</div>
		</div>

		<div class="signature">
			<p><?php esc_html_e('Best regards,', 'addify-affiliate-program'); ?></p>
			<p class="team-name"><?php esc_html_e('The Team', 'addify-affiliate-program'); ?></p>
		</div>

		<div class="footer">
			<p><?php esc_html_e('This is an automated notification. Please do not reply to this email.', 'addify-affiliate-program'); ?></p>
		</div>
	</div>
</body>
</html>