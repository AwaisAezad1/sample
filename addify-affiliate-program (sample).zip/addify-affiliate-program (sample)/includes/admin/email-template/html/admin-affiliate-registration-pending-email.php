<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$addify_ad_pr_affiliate_name = isset( $data['{affiliate_name}'] ) ? esc_html( $data['{affiliate_name}'] ) : '';
$addify_ad_pr_site_name      = isset( $data['{site_name}'] ) ? esc_html( $data['{site_name}'] ) : '';
$addify_ad_pr_blog_name      = esc_html( get_bloginfo( 'name' ) );
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<style>
		body {
			font-family: Arial, sans-serif;
			line-height: 1.6;
			color: #333;
			max-width: 600px;
			margin: 0 auto;
			padding: 20px;
			background-color: #f9f9f9;
		}
		.email-container {
			background: #ffffff;
			border-radius: 8px;
			padding: 30px;
			box-shadow: 0 2px 10px rgba(0,0,0,0.1);
		}
		.header {
			text-align: center;
			margin-bottom: 30px;
			border-bottom: 2px solid #f0f0f0;
			padding-bottom: 20px;
		}
		.header h1 {
			color: #ff9800;
			margin: 0;
			font-size: 24px;
		}
		.content {
			margin-bottom: 30px;
		}
		.greeting {
			font-size: 16px;
			margin-bottom: 20px;
		}
		.review-banner {
			background: #fff3cd;
			border-left: 4px solid #ffc107;
			padding: 25px;
			border-radius: 4px;
			margin: 25px 0;
			text-align: center;
		}
		.process-info {
			background: #f8f9fa;
			border-left: 4px solid #6c757d;
			padding: 20px;
			border-radius: 4px;
			margin: 25px 0;
		}
		.process-list {
			list-style: none;
			padding: 0;
			margin: 0;
		}
		.process-list li {
			padding: 8px 0;
			padding-left: 25px;
			position: relative;
		}
		.process-list li:before {
			content: "⏳";
			position: absolute;
			left: 0;
		}
		.support-section {
			background: #e7f4ff;
			border-left: 4px solid #3498db;
			padding: 20px;
			border-radius: 4px;
			margin: 25px 0;
		}
		.signature {
			text-align: center;
			margin-top: 30px;
			padding-top: 20px;
			border-top: 2px solid #f0f0f0;
		}
		.team-name {
			font-weight: bold;
			color: #2c3e50;
		}
		.footer {
			text-align: center;
			margin-top: 30px;
			color: #7f8c8d;
			font-size: 14px;
		}
		.patience-note {
			text-align: center;
			font-style: italic;
			color: #6c757d;
			margin: 20px 0;
		}
	</style>
</head>
<body>
	<div class="email-container">
		<div class="header">
			<h1>📋 <?php esc_html_e( 'Application Received', 'addify-affiliate-program' ); ?></h1>
		</div>

		<div class="content">
			<div class="greeting">
				<p>
					<?php /* translators: %s: affiliate name */ ?>
					<?php printf( esc_html__( 'Hello %s,', 'addify-affiliate-program' ), '<strong>' . esc_html($addify_ad_pr_affiliate_name) . '</strong>' ); ?>
				</p>
			</div>

			<div class="review-banner">
				<h2 style="margin-top: 0; color: #856404;">⏳ <?php esc_html_e( 'Application Under Review', 'addify-affiliate-program' ); ?></h2>
				<p style="font-size: 16px; margin: 0;"><?php esc_html_e( 'Thanks for applying to join our affiliate program. Your application is currently under review.', 'addify-affiliate-program' ); ?></p>
			</div>

			<p>
				<?php
				printf(
					/* translators: %s: site name */
					esc_html__( 'We will review your application and notify you as soon as a decision is made. Thank you for your interest in promoting %s.', 'addify-affiliate-program' ),
					'<strong>' . esc_html($addify_ad_pr_site_name) . '</strong>'
				);
				?>
			</p>

			<div class="process-info">
				<h3 style="margin-top: 0; color: #2c3e50;"><?php esc_html_e( 'What happens next?', 'addify-affiliate-program' ); ?></h3>
				<ul class="process-list">
					<li><?php esc_html_e( 'Our team will review your application', 'addify-affiliate-program' ); ?></li>
					<li><?php esc_html_e( 'We may contact you for additional information', 'addify-affiliate-program' ); ?></li>
					<li><?php esc_html_e( 'You\'ll receive a decision via email', 'addify-affiliate-program' ); ?></li>
					<li><?php esc_html_e( 'Approval typically takes 1-3 business days', 'addify-affiliate-program' ); ?></li>
				</ul>
			</div>

			<div class="support-section">
				<p><strong>💡 <?php esc_html_e( 'Need to update your application?', 'addify-affiliate-program' ); ?></strong></p>
				<p><?php esc_html_e( 'If you need to update your application or provide additional information, please reply to this email or contact our support team.', 'addify-affiliate-program' ); ?></p>
			</div>

			<div class="patience-note">
				<p>🙏 <?php esc_html_e( 'Thank you for your patience and understanding.', 'addify-affiliate-program' ); ?></p>
			</div>
		</div>

		<div class="signature">
			<p><?php esc_html_e( 'Best regards,', 'addify-affiliate-program' ); ?></p>
			<p class="team-name"><?php echo esc_html($addify_ad_pr_blog_name); ?></p>
		</div>

		<div class="footer">
			<p><?php esc_html_e( 'We appreciate your interest in our affiliate program!', 'addify-affiliate-program' ); ?></p>
		</div>
	</div>
</body>
</html>