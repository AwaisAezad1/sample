<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$addify_ad_pr_affiliate_name = isset( $data['{affiliate_name}'] ) ? esc_html( $data['{affiliate_name}'] ) : '';
$addify_ad_pr_site_name      = isset( $data['{site_name}'] ) ? esc_html( $data['{site_name}'] ) : '';
$addify_ad_pr_login_url      = esc_url( wp_login_url() );
$addify_ad_pr_blog_name      = esc_html( get_bloginfo( 'name' ) );
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<style>
		body {
			font-family: Arial, sans-serif;
			line-height: 1.6;
			color: #333;
			max-width: 600px;
			margin: 0 auto;
			padding: 20px;
			background-color: #f9f9f9;
		}
		.email-container {
			background: #ffffff;
			border-radius: 8px;
			padding: 30px;
			box-shadow: 0 2px 10px rgba(0,0,0,0.1);
		}
		.header {
			text-align: center;
			margin-bottom: 30px;
			border-bottom: 2px solid #f0f0f0;
			padding-bottom: 20px;
		}
		.header h1 {
			color: #27ae60;
			margin: 0;
			font-size: 24px;
		}
		.content {
			margin-bottom: 30px;
		}
		.greeting {
			font-size: 16px;
			margin-bottom: 20px;
		}
		.welcome-banner {
			background: #d4edda;
			border-left: 4px solid #28a745;
			padding: 25px;
			border-radius: 4px;
			margin: 25px 0;
			text-align: center;
		}
		.cta-button {
			display: inline-block;
			background: #27ae60;
			color: white;
			padding: 12px 30px;
			text-decoration: none;
			border-radius: 5px;
			font-weight: bold;
			margin: 20px 0;
			transition: background 0.3s ease;
		}
		.cta-button:hover {
			background: #219653;
		}
		.features {
			background: #f8f9fa;
			border-left: 4px solid #3498db;
			padding: 20px;
			border-radius: 4px;
			margin: 25px 0;
		}
		.feature-list {
			list-style: none;
			padding: 0;
			margin: 0;
		}
		.feature-list li {
			padding: 8px 0;
			padding-left: 25px;
			position: relative;
		}
		.feature-list li:before {
			content: "✓";
			color: #27ae60;
			font-weight: bold;
			position: absolute;
			left: 0;
		}
		.support-section {
			background: #e7f4ff;
			border-left: 4px solid #3498db;
			padding: 20px;
			border-radius: 4px;
			margin: 25px 0;
		}
		.signature {
			text-align: center;
			margin-top: 30px;
			padding-top: 20px;
			border-top: 2px solid #f0f0f0;
		}
		.team-name {
			font-weight: bold;
			color: #2c3e50;
		}
		.footer {
			text-align: center;
			margin-top: 30px;
			color: #7f8c8d;
			font-size: 14px;
		}
	</style>
</head>
<body>
	<div class="email-container">
		<div class="header">
			<h1>🎉 <?php esc_html_e( 'Welcome to Our Affiliate Program!', 'addify-affiliate-program' ); ?></h1>
		</div>

		<div class="content">
			<div class="greeting">
				<p>
					<?php /* translators: %s: affiliate name */ ?>
					<?php printf( esc_html__( 'Hello %s,', 'addify-affiliate-program' ), '<strong>' . esc_html($addify_ad_pr_affiliate_name) . '</strong>' ); ?>
				</p>
			</div>

			<div class="welcome-banner">
				<h2 style="margin-top: 0; color: #155724;">✅ <?php esc_html_e( 'Congratulations!', 'addify-affiliate-program' ); ?></h2>
				<p style="font-size: 16px; margin: 0;"><?php esc_html_e( 'Your affiliate registration has been approved!', 'addify-affiliate-program' ); ?></p>
			</div>

			<p>
				<?php
				printf(
					/* translators: %s: site name */
					esc_html__( 'You are now an approved affiliate for %s. You can log in to your account to find your referral links, view commissions, and start promoting.', 'addify-affiliate-program' ),
					'<strong>' . esc_html($addify_ad_pr_site_name) . '</strong>'
				);
				?>
			</p>

			<div class="features">
				<h3 style="margin-top: 0; color: #2c3e50;"><?php esc_html_e( 'What you can do now:', 'addify-affiliate-program' ); ?></h3>
				<ul class="feature-list">
					<li><?php esc_html_e( 'Access your unique referral links', 'addify-affiliate-program' ); ?></li>
					<li><?php esc_html_e( 'Track your commissions and earnings', 'addify-affiliate-program' ); ?></li>
					<li><?php esc_html_e( 'View performance reports and analytics', 'addify-affiliate-program' ); ?></li>
					<li><?php esc_html_e( 'Start promoting and earning commissions', 'addify-affiliate-program' ); ?></li>
				</ul>
			</div>

			<div style="text-align: center; margin: 30px 0;">
				<a href="<?php echo esc_url($addify_ad_pr_login_url); ?>" class="cta-button">
					<?php esc_html_e( 'Log in to Your Account', 'addify-affiliate-program' ); ?>
				</a>
			</div>

			<div class="support-section">
				<p><strong>💡 <?php esc_html_e( 'Need Help?', 'addify-affiliate-program' ); ?></strong></p>
				<p><?php esc_html_e( 'If you have any questions, reply to this email or contact our support team. We\'re here to help you succeed!', 'addify-affiliate-program' ); ?></p>
			</div>
		</div>

		<div class="signature">
			<p><?php esc_html_e( 'Thank you for joining our program!', 'addify-affiliate-program' ); ?></p>
			<p class="team-name"><?php echo esc_html($addify_ad_pr_blog_name); ?></p>
		</div>

		<div class="footer">
			<p><?php esc_html_e( 'We\'re excited to have you on board and look forward to a successful partnership!', 'addify-affiliate-program' ); ?></p>
		</div>
	</div>
</body>
</html>