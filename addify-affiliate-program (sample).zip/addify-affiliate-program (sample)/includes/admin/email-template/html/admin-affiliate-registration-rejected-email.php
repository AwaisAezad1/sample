<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$addify_ad_pr_affiliate_name = isset( $data['{affiliate_name}'] ) ? esc_html( $data['{affiliate_name}'] ) : '';
$addify_ad_pr_site_name      = isset( $data['{site_name}'] ) ? esc_html( $data['{site_name}'] ) : '';
$addify_ad_pr_blog_name      = esc_html( get_bloginfo( 'name' ) );
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<style>
		body {
			font-family: Arial, sans-serif;
			line-height: 1.6;
			color: #333;
			max-width: 600px;
			margin: 0 auto;
			padding: 20px;
			background-color: #f9f9f9;
		}
		.email-container {
			background: #ffffff;
			border-radius: 8px;
			padding: 30px;
			box-shadow: 0 2px 10px rgba(0,0,0,0.1);
		}
		.header {
			text-align: center;
			margin-bottom: 30px;
			border-bottom: 2px solid #f0f0f0;
			padding-bottom: 20px;
		}
		.header h1 {
			color: #dc3545;
			margin: 0;
			font-size: 24px;
		}
		.content {
			margin-bottom: 30px;
		}
		.greeting {
			font-size: 16px;
			margin-bottom: 20px;
		}
		.decision-banner {
			background: #f8d7da;
			border-left: 4px solid #dc3545;
			padding: 25px;
			border-radius: 4px;
			margin: 25px 0;
			text-align: center;
		}
		.message-content {
			background: #f8f9fa;
			border-left: 4px solid #6c757d;
			padding: 20px;
			border-radius: 4px;
			margin: 25px 0;
		}
	
		.contact-button {
			display: inline-block;
			background: #3498db;
			color: white;
			padding: 12px 25px;
			text-decoration: none;
			border-radius: 5px;
			font-weight: bold;
			margin: 15px 0;
			transition: background 0.3s ease;
		}
	
		.closing {
			text-align: center;
			margin: 25px 0;
			padding: 20px;
			background: #f8f9fa;
			border-radius: 4px;
		}
		.signature {
			text-align: center;
			margin-top: 30px;
			padding-top: 20px;
			border-top: 2px solid #f0f0f0;
		}
		.team-name {
			font-weight: bold;
			color: #2c3e50;
		}
		.footer {
			text-align: center;
			margin-top: 30px;
			color: #7f8c8d;
			font-size: 14px;
		}
	</style>
</head>
<body>
	<div class="email-container">
		<div class="header">
			<h1>📋 <?php esc_html_e( 'Application Update', 'addify-affiliate-program' ); ?></h1>
		</div>

		<div class="content">
			<div class="greeting">
				<p>
					<?php /* translators: %s: affiliate name */ ?>
					<?php printf( esc_html__( 'Hello %s,', 'addify-affiliate-program' ), '<strong>' . esc_html($addify_ad_pr_affiliate_name) . '</strong>' ); ?>
				</p>
			</div>

			<div class="decision-banner">
				<h2 style="margin-top: 0; color: #721c24;">❌ <?php esc_html_e( 'Application Decision', 'addify-affiliate-program' ); ?></h2>
				<p style="font-size: 16px; margin: 0;"><?php esc_html_e( 'We appreciate your interest in joining our affiliate program.', 'addify-affiliate-program' ); ?></p>
			</div>

			<div class="message-content">
				<p><?php esc_html_e( 'After careful review, we are sorry to inform you that your application has not been approved at this time.', 'addify-affiliate-program' ); ?></p>
				
				<p>
					<?php
					printf(
						/* translators: %1$s: site name; %2$s: support link label (plain text) */
						esc_html__( 'If you would like more information about this decision or believe there has been a mistake, please contact our support team for %s.', 'addify-affiliate-program' ),
						'<strong>' . esc_html($addify_ad_pr_site_name) . '</strong>'
					);
					?>
				</p>
			</div>


			<div class="closing">
				<p>🙏 <?php esc_html_e( 'Thank you for your interest, and we wish you the best of luck in your future endeavors.', 'addify-affiliate-program' ); ?></p>
			</div>
		</div>

		<div class="signature">
			<p><?php esc_html_e( 'Sincerely,', 'addify-affiliate-program' ); ?></p>
			<p class="team-name"><?php echo esc_html($addify_ad_pr_blog_name); ?></p>
		</div>

		<div class="footer">
			<p><?php esc_html_e( 'We appreciate your understanding.', 'addify-affiliate-program' ); ?></p>
		</div>
	</div>
</body>
</html>