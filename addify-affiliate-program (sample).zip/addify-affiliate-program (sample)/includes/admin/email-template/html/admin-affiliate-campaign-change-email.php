<?php
if (!defined('ABSPATH')) {
	exit;
}

$addify_ad_pr_affiliate_name  = isset($new_form_data['{affiliate_name}']) ? $new_form_data['{affiliate_name}'] : '';
$addify_ad_pr_campaign_name   = isset($new_form_data['{campaign_name}']) ? $new_form_data['{campaign_name}'] : '';
$addify_ad_pr_changes_summary = isset($new_form_data['{changes_summary}']) ? wp_strip_all_tags($new_form_data['{changes_summary}']) : '';
$addify_ad_pr_effective_date  = isset($new_form_data['{effective_date}']) ? $new_form_data['{effective_date}'] : '';
$addify_ad_pr_blog_name       = get_bloginfo('name');
?>

<!DOCTYPE html>
<html>

<head>
	<meta charset="UTF-8">
	<style>
		body {
			font-family: Arial, sans-serif;
			line-height: 1.6;
			color: #333;
			max-width: 600px;
			margin: 0 auto;
			padding: 20px;
			background-color: #f9f9f9;
		}

		.email-container {
			background: #ffffff;
			border-radius: 8px;
			padding: 30px;
			box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
		}

		.header {
			text-align: center;
			margin-bottom: 30px;
			border-bottom: 2px solid #f0f0f0;
			padding-bottom: 20px;
		}

		.header h1 {
			color: #2c3e50;
			margin: 0;
			font-size: 24px;
		}

		.content {
			margin-bottom: 30px;
		}

		.greeting {
			font-size: 16px;
			margin-bottom: 20px;
		}

		.details-card {
			background: #f8f9fa;
			border-left: 4px solid #3498db;
			padding: 20px;
			border-radius: 4px;
			margin: 20px 0;
		}

		.detail-item {
			margin-bottom: 12px;
			padding: 8px 0;
		}

		.detail-label {
			font-weight: bold;
			color: #555;
			display: inline-block;
			min-width: 120px;
		}

		.detail-value {
			color: #2c3e50;
		}

		.changes-section {
			background: #fff3cd;
			border-left: 4px solid #ffc107;
			padding: 20px;
			border-radius: 4px;
			margin: 20px 0;
		}

		.changes-summary {
			white-space: pre-line;
			line-height: 1.8;
		}

		.footer {
			text-align: center;
			margin-top: 30px;
			padding-top: 20px;
			border-top: 2px solid #f0f0f0;
			color: #7f8c8d;
			font-size: 14px;
		}

		.support-note {
			background: #e7f4ff;
			padding: 15px;
			border-radius: 4px;
			margin: 20px 0;
			border-left: 4px solid #3498db;
		}

		.thank-you {
			font-style: italic;
			color: #7f8c8d;
			text-align: center;
			margin-top: 25px;
		}
	</style>
</head>

<body>
	<div class="email-container">
		<div class="header">
			<h1>📋 <?php esc_html_e('Campaign Update Notification', 'addify-affiliate-program'); ?></h1>
		</div>

		<div class="content">
			<div class="greeting">

				<p>
					<?php
					// translators: %s: customer name.
					printf(esc_html__('Hello %s,', 'addify-affiliate-program'), esc_html($addify_ad_pr_affiliate_name));
					?>
				</p>
				<p><?php esc_html_e('We wanted to inform you about important updates to your affiliate campaign.', 'addify-affiliate-program'); ?></p>
			</div>

			<div class="details-card">
				<div class="detail-item">
					<span class="detail-label"><?php esc_html_e('Campaign Name:', 'addify-affiliate-program'); ?></span>
					<span class="detail-value"><?php echo esc_html($addify_ad_pr_campaign_name); ?></span>
				</div>

				<div class="detail-item">
					<span class="detail-label"><?php esc_html_e('Effective Date:', 'addify-affiliate-program'); ?></span>
					<span class="detail-value"><?php echo esc_html($addify_ad_pr_effective_date); ?></span>
				</div>
			</div>

			<div class="changes-section">
				<h3 style="margin-top: 0; color: #856404;"><?php esc_html_e('Summary of Changes:', 'addify-affiliate-program'); ?></h3>
				<div class="changes-summary"><?php echo nl2br(esc_html($addify_ad_pr_changes_summary)); ?>
				</div>
			</div>

			<div class="support-note">
				<p><strong>💡 <?php esc_html_e('Action Required:', 'addify-affiliate-program'); ?></strong></p>
				<p><?php esc_html_e('Please review these changes and adjust your promotions accordingly.', 'addify-affiliate-program'); ?></p>
				<p><?php esc_html_e('If you have any questions, please contact our support team.', 'addify-affiliate-program'); ?></p>
			</div>

			<div class="thank-you">
				<p><?php esc_html_e('Thank you for being a valued affiliate partner!', 'addify-affiliate-program'); ?></p>
			</div>
		</div>

		<div class="footer">
			<p><?php echo esc_html($addify_ad_pr_blog_name); ?></p>
			<p><?php esc_html_e('This is an automated notification. Please do not reply to this email.', 'addify-affiliate-program'); ?></p>
		</div>
	</div>
</body>

</html>