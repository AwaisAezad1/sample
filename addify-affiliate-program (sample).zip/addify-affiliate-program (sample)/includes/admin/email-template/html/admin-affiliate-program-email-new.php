<?php
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}


// Extract and sanitize data
$addify_ad_pr_affiliate_id  = isset($new_form_data['{affiliate_id}']) ? esc_html($new_form_data['{affiliate_id}']) : '';
$addify_ad_pr_user_name     = isset($new_form_data['{User_name}']) ? esc_html($new_form_data['{User_name}']) : '';
$addify_ad_pr_addify_user_email    = isset($new_form_data['{User_email}']) ? esc_html($new_form_data['{User_email}']) : '';
$addify_ad_pr_blog_name = esc_html(get_bloginfo('name'));
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<style>
		body {
			font-family: Arial, sans-serif;
			line-height: 1.6;
			color: #333;
			max-width: 600px;
			margin: 0 auto;
			padding: 20px;
			background-color: #f9f9f9;
		}
		.email-container {
			background: #ffffff;
			border-radius: 8px;
			padding: 30px;
			box-shadow: 0 2px 10px rgba(0,0,0,0.1);
		}
		.header {
			text-align: center;
			margin-bottom: 30px;
			border-bottom: 2px solid #f0f0f0;
			padding-bottom: 20px;
		}
		.header h1 {
			color: #3498db;
			margin: 0;
			font-size: 24px;
		}
		.content {
			margin-bottom: 30px;
		}
		.notification-banner {
			background: #d4edda;
			border-left: 4px solid #28a745;
			padding: 25px;
			border-radius: 4px;
			margin: 25px 0;
			text-align: center;
		}
		.affiliate-details {
			background: #f8f9fa;
			border-left: 4px solid #3498db;
			padding: 20px;
			border-radius: 4px;
			margin: 25px 0;
		}
		.detail-list {
			list-style: none;
			padding: 0;
			margin: 0;
		}
		.detail-list li {
			padding: 12px 0;
			border-bottom: 1px solid #eee;
			display: flex;
			justify-content: space-between;
		}
		.detail-list li:last-child {
			border-bottom: none;
		}
		.detail-label {
			font-weight: bold;
			color: #555;
			min-width: 120px;
		}
		.detail-value {
			color: #2c3e50;
			text-align: right;
		}
		.affiliate-id {
			background: #e7f4ff;
			padding: 8px 15px;
			border-radius: 20px;
			font-weight: bold;
			color: #3498db;
		}
		.action-section {
			background: #fff3cd;
			border-left: 4px solid #ffc107;
			padding: 20px;
			border-radius: 4px;
			margin: 25px 0;
		}
		.signature {
			text-align: center;
			margin-top: 30px;
			padding-top: 20px;
			border-top: 2px solid #f0f0f0;
		}
		.team-name {
			font-weight: bold;
			color: #2c3e50;
		}
		.footer {
			text-align: center;
			margin-top: 30px;
			color: #7f8c8d;
			font-size: 14px;
		}
	</style>
</head>
<body>
	<div class="email-container">
		<div class="header">
			<h1>👥 <?php esc_html_e('New Affiliate Registration', 'addify-affiliate-program'); ?></h1>
		</div>

		<div class="content">
			<div class="notification-banner">
				<h2 style="margin-top: 0; color: #155724;">🎉 <?php esc_html_e('New Affiliate Joined!', 'addify-affiliate-program'); ?></h2>
				<p style="font-size: 16px; margin: 0;">
					<?php
					printf(
						/* translators: 1: Affiliate ID, 2: Amount */
						esc_html__('A new affiliation has been registered with Affiliate ID: %1$s', 'addify-affiliate-program'),
						'<span class="affiliate-id">#' . esc_html($addify_ad_pr_affiliate_id) . '</span>'
					);
					?>
				</p>
			</div>

			<div class="affiliate-details">
				<h3 style="margin-top: 0; color: #2c3e50;"><?php esc_html_e('Affiliate Details:', 'addify-affiliate-program'); ?></h3>
				
				<ul class="detail-list">
					<li>
						<span class="detail-label"><?php esc_html_e('Name:', 'addify-affiliate-program'); ?></span>
						<span class="detail-value">
							<?php
							printf(
								esc_html('%s', 'addify-affiliate-program'),
								esc_html($addify_ad_pr_user_name)
							);
							?>
						</span>
					</li>
					
					<li>
						<span class="detail-label"><?php esc_html_e('Email:', 'addify-affiliate-program'); ?></span>
						<span class="detail-value">
							<?php
							printf(
								esc_html('%s', 'addify-affiliate-program'),
								esc_html($addify_ad_pr_addify_user_email)
							);
							?>
						</span>
					</li>
					
					<li>
						<span class="detail-label"><?php esc_html_e('Affiliate ID:', 'addify-affiliate-program'); ?></span>
						<span class="detail-value">
							<span class="affiliate-id">#<?php echo esc_html($addify_ad_pr_affiliate_id); ?></span>
						</span>
					</li>
				</ul>
			</div>

			<div class="action-section">
				<p><strong>💡 <?php esc_html_e('Next Steps:', 'addify-affiliate-program'); ?></strong></p>
				<p><?php esc_html_e('Please review the new affiliate registration in your admin dashboard and process accordingly.', 'addify-affiliate-program'); ?></p>
			</div>
		</div>

		<div class="signature">
			<p><?php esc_html_e('Thank you,', 'addify-affiliate-program'); ?></p>
			<p class="team-name"><?php echo esc_html($addify_ad_pr_blog_name); ?></p>
		</div>

		<div class="footer">
			<p><?php esc_html_e('This is an automated notification. New affiliate registrations require admin approval.', 'addify-affiliate-program'); ?></p>
		</div>
	</div>
</body>
</html>