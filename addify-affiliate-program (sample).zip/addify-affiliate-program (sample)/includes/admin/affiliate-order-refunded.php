<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Addify_Affiliate_Order_Refunded' ) ) :

	class Addify_Affiliate_Order_Refunded {

	
		/**
		 * Runs when any WooCommerce order is refunded (partial or full)
		 */
		public function handle_order_refunded( $order_id, $refund_id ) {
			$order  = wc_get_order( $order_id );
			$refund = wc_get_order( $refund_id );

			if ( ! $order || ! $refund ) {
				return;
			}

			$refund_amount = (float) $refund->get_amount();
			$affiliate_id  = $order->get_user_id();

			if ( ! $affiliate_id ) {
				return; // No affiliate tied to this order
			}

			// ✅ 1. Get affiliate post (type = affiliate_user_post)
			$affiliate_posts = get_posts( array(
				'post_type'      => 'affiliate_user_post',
				'posts_per_page' => 1,
				'post_status'    => 'publish',
				'author'         => $affiliate_id,
				'fields'         => 'ids',
			) );

			if ( empty( $affiliate_posts ) ) {
				return;
			}

			$affiliate_post_id = $affiliate_posts[0];

			// ✅ 2. Subtract refunded commission from affiliate post
			$previous_paid = (float) get_post_meta( $affiliate_post_id, 'payout_save_paid_amount', true );
			$updated_paid  = max( 0, $previous_paid - $refund_amount );
			update_post_meta( $affiliate_post_id, 'payout_save_paid_amount', $updated_paid );

			// ✅ 3. Log the refund
			$existing_logs = get_post_meta( $affiliate_post_id, 'payout_save_log', true );
			if ( ! is_array( $existing_logs ) ) {
				$existing_logs = array();
			}

			$existing_logs[] = array(
				'type'        => 'refund',
				'order_id'    => $order_id,
				'refund_id'   => $refund_id,
				'refund_amt'  => $refund_amount,
				'timestamp'   => current_time( 'mysql' ),
			);

			update_post_meta( $affiliate_post_id, 'payout_save_log', $existing_logs );

			// ✅ 4. Adjust hourly stats
			$this->update_hourly_stats( $affiliate_post_id, $refund_amount );

			// ✅ 5. Update payout posts
			$this->update_payout_posts( $affiliate_id, $refund_amount, $order_id, $refund_id );
		}


		/**
		 * Update payout posts linked to affiliate
		 */
		private function update_payout_posts( $affiliate_id, $refund_amount, $order_id, $refund_id ) {
			// Get all payout posts
			$all_payout_posts = get_posts( array(
				'post_type'      => 'payout_post',
				'posts_per_page' => -1,
				'post_status'    => 'any',
				'fields'         => 'ids',
			) );

			foreach ( $all_payout_posts as $payout_id ) {
				$payout_affiliate = get_post_meta( $payout_id, 'affiliate_id', true );

				if ( (int) $payout_affiliate === (int) $affiliate_id ) {

					// ✅ Reduce paid/unpaid amounts
					$paid_amount   = (float) get_post_meta( $payout_id, 'paid_amount', true );
					$unpaid_amount = (float) get_post_meta( $payout_id, 'unpaid_amount', true );
					$total_earned  = (float) get_post_meta( $payout_id, 'total_earned', true );
					$total_refunds = (float) get_post_meta( $payout_id, 'total_refunds', true );

					// Adjust values
					$new_paid   = max( 0, $paid_amount - $refund_amount );
					$new_unpaid = max( 0, $unpaid_amount - $refund_amount );
					$new_earned = max( 0, $total_earned - $refund_amount );
					$new_refund = $total_refunds + $refund_amount;

					update_post_meta( $payout_id, 'paid_amount', $new_paid );
					update_post_meta( $payout_id, 'unpaid_amount', $new_unpaid );
					update_post_meta( $payout_id, 'total_earned', $new_earned );
					update_post_meta( $payout_id, 'total_refunds', $new_refund );

					// ✅ Log inside payout
					$refund_log = get_post_meta( $payout_id, 'payout_refund_log', true );
					if ( ! is_array( $refund_log ) ) {
						$refund_log = array();
					}

					$refund_log[] = array(
						'order_id'   => $order_id,
						'refund_id'  => $refund_id,
						'amount'     => $refund_amount,
						'timestamp'  => current_time( 'mysql' ),
					);

					update_post_meta( $payout_id, 'payout_refund_log', $refund_log );
				}
			}
		}


		/**
		 * Update hourly stats meta
		 */
		private function update_hourly_stats( $affiliate_post_id, $refund_amount ) {
			$hourly_log = get_post_meta( $affiliate_post_id, 'hourly_stats', true );
			if ( ! is_array( $hourly_log ) ) {
				$hourly_log = array();
			}

			$wp_timezone = get_option( 'timezone_string' );
			if ( ! $wp_timezone ) {
				$offset = (float) get_option( 'gmt_offset' );
				$sign   = ( $offset <= 0 ) ? '+' : '-';
				$hours  = abs( $offset );
				$wp_timezone = 'Etc/GMT' . $sign . $hours;
			}

			$tz  = new DateTimeZone( $wp_timezone );
			$now = new DateTime( 'now', $tz );
			$hour_key = $now->format( 'Y-m-d H:00' );

			if ( ! isset( $hourly_log[ $hour_key ] ) ) {
				$hourly_log[ $hour_key ] = array(
					'clicks'   => 0,
					'paid'     => 0,
					'unpaid'   => 0,
					'earnings' => 0,
					'refunds'  => 0,
				);
			}

			$hourly_log[ $hour_key ]['refunds'] += $refund_amount;
			update_post_meta( $affiliate_post_id, 'hourly_stats', $hourly_log );
		}
	}

	new Addify_Affiliate_Order_Refunded();

endif;
