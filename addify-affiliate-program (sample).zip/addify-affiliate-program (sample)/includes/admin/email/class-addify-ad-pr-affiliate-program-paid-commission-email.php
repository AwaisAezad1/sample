<?php
if (!defined('ABSPATH')) {
	exit; 
}

class Addify_Ad_Pr_Affiliate_Paid_Commission_Email extends WC_Email {

	public function __construct() {
		$this->id             = 'affiliate_paid_commission_email';
		$this->title          = __('For Paid Commission', 'addify-affiliate-program');
		$this->description    = __('This email is sent to the affiliate when an admin pays a commission.', 'addify-affiliate-program');
		$this->subject        = __('Affiliate Paid Commission', 'addify-affiliate-program');
		$this->heading        = __('Affiliate Paid Commission', 'addify-affiliate-program');
		$this->customer_email = true;
		$this->template_base  = AD_AFFILIATE_DIR;
		$this->template_html  = 'includes/admin/email-template/html/admin-affiliate-program-paid-commission-email.php';
		$this->template_plain = 'includes/admin/email-template/plain/admin-affiliate-program-paid-commission-email.php';
		
		// No recipient here anymore

		$this->placeholders = array(
			'{affiliate_id}'  => '',
			'{paid_amount}'   => '',
			'{User_name}'     => '',
			'{User_email}'    => '',
		);

		add_action('addify_affiliate_paid_commission', array( $this, 'trigger' ), 10, 1);

		parent::__construct();
	}

	public function trigger( $new_form_data ) {
		$this->setup_locale();

		// Set recipient to affiliate's email
		if (isset($new_form_data['User_email']) && !empty($new_form_data['User_email'])) {
			$this->recipient = sanitize_email($new_form_data['User_email']);
		} else {
			return; // No email found, don't send
		}

		if (!$this->is_enabled() || !$this->get_recipient()) {
			return;
		}

		$this->placeholders = array(
			'{affiliate_id}'  => isset($new_form_data['affiliate_id']) ? $new_form_data['affiliate_id'] : '-',
			'{paid_amount}'   => isset($new_form_data['paid_amount']) ? $new_form_data['paid_amount'] : '-',
			'{User_name}'     => isset($new_form_data['User_name']) ? $new_form_data['User_name'] : '-',
			'{User_email}'    => isset($new_form_data['User_email']) ? $new_form_data['User_email'] : '-',
		);

		$this->send(
			$this->get_recipient(),
			$this->get_subject(),
			$this->get_content(),
			$this->get_headers(),
			$this->get_attachments()
		);

		$this->restore_locale();
	}

	public function get_content_html() {
		return wc_get_template_html(
			$this->template_html,
			array( 'new_form_data' => $this->placeholders ),
			'',
			$this->template_base
		);
	}

	public function get_content_plain() {
		return wc_get_template(
			$this->template_plain,
			array( 'new_form_data' => $this->placeholders ),
			'',
			$this->template_base
		);
	}
}
