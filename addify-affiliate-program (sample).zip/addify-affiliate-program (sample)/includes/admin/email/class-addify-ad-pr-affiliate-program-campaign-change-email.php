<?php
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}

class Addify_Ad_Pr_Affiliate_Campaign_Change_Email extends WC_Email {

	public function __construct() {
		$this->id             = 'affiliate_campaign_change_email';
		$this->title          = __('Affiliate Campaign Update', 'addify-affiliate-program');
		$this->customer_email = true;
		$this->description    = __('This email is sent to affiliates when there are changes to the campaign they are part of.', 'addify-affiliate-program');
		$this->subject        = __('Important Update: Changes to Your Affiliate Campaign', 'addify-affiliate-program');
		$this->heading        = __('Campaign Update Notification', 'addify-affiliate-program');
		$this->template_base  = AD_AFFILIATE_DIR;
		$this->template_html  = 'includes/admin/email-template/html/admin-affiliate-campaign-change-email.php';
		$this->template_plain = 'includes/admin/email-template/plain/admin-affiliate-campaign-change-email.php';
		$this->recipient      = ''; // Will be dynamically set

		$this->placeholders = array(
			'{affiliate_name}'    => '',
			'{campaign_name}'     => '',
			'{changes_summary}'   => '',
			'{effective_date}'    => '',
		);

		add_action('addify_affiliate_campaign_change', array( $this, 'trigger' ), 10, 2);

		parent::__construct();
	}

	public function trigger( $affiliate_email, $data ) {
		$this->setup_locale();

		if (!$this->is_enabled() || empty($affiliate_email)) {
			return;
		}

		$this->recipient = $affiliate_email;

		$this->placeholders = array(
			'{affiliate_name}'  => isset($data['affiliate_name']) ? $data['affiliate_name'] : '-',
			'{campaign_name}'   => isset($data['campaign_name']) ? $data['campaign_name'] : '-',
			'{changes_summary}' => isset($data['changes_summary']) ? $data['changes_summary'] : '-',
			'{effective_date}'  => isset($data['effective_date']) ? $data['effective_date'] : '-',
		);

		$this->send(
			$this->get_recipient(),
			$this->get_subject(),
			$this->get_content(),
			$this->get_headers(),
			$this->get_attachments()
		);

		$this->restore_locale();
	}

	public function get_content_html() {
		return wc_get_template_html(
			$this->template_html,
			array( 'new_form_data' => $this->placeholders ),
			'',
			$this->template_base
		);
	}

	public function get_content_plain() {
		return wc_get_template(
			$this->template_plain,
			array( 'new_form_data' => $this->placeholders ),
			'',
			$this->template_base
		);
	}
}
