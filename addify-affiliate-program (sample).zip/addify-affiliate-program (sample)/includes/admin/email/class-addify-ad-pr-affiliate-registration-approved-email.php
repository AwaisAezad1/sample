<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Addify_Ad_Pr_Affiliate_Registration_Approved_Email extends WC_Email {

	public function __construct() {
		$this->id             = 'affiliate_registration_approved';
		$this->title          = __( 'Affiliate Registration Approved', 'addify-affiliate-program' );
		$this->description    = __( 'This email is sent to affiliates when their registration is approved.', 'addify-affiliate-program' );
		$this->subject        = __( 'Your Affiliate Registration Has Been Approved', 'addify-affiliate-program' );
		$this->heading        = __( 'Congratulations! You are now an Affiliate', 'addify-affiliate-program' );
		$this->customer_email = true;
		$this->template_base  = AD_AFFILIATE_DIR;
		$this->template_html  = 'includes/admin/email-template/html/admin-affiliate-registration-approved-email.php';
		$this->template_plain = 'includes/admin/email-template/plain/admin-affiliate-registration-approved-email.php';
		$this->recipient      = '';

		$this->placeholders = array(
			'{affiliate_name}' => '',
			'{site_name}'      => '',
		);

		add_action( 'addify_affiliate_registration_approved', array( $this, 'trigger' ), 10, 2 );

		parent::__construct();
	}

	public function trigger( $data ) {
	$this->setup_locale();

		if ( ! $this->is_enabled() ) {
			return;
		}

	// derive recipient from $data
	$this->recipient = isset( $data['affiliate_email'] ) ? $data['affiliate_email'] : get_option( 'admin_email' );

	$this->placeholders = array(
		'{affiliate_name}' => isset( $data['affiliate_name'] ) ? $data['affiliate_name'] : '-',
		'{site_name}'      => isset( $data['site_name'] ) ? $data['site_name'] : get_bloginfo('name'),
	);

	$this->send(
		$this->get_recipient(),
		$this->get_subject(),
		$this->get_content(),
		$this->get_headers(),
		$this->get_attachments()
	);

	$this->restore_locale();
	}

	public function get_content_html() {
		return wc_get_template_html(
			$this->template_html,
			array( 'data' => $this->placeholders ),
			'',
			$this->template_base
		);
	}

	public function get_content_plain() {
		return wc_get_template(
			$this->template_plain,
			array( 'data' => $this->placeholders ),
			'',
			$this->template_base
		);
	}
}
