<?php
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}

class Addify_Ad_Pr_Affiliate_New_Email extends WC_Email {

	public function __construct() {
		$this->id             = 'affiliate_email_new';
		$this->title          = __('New Affiliate Registration', 'addify-affiliate-program');
		$this->description    = __('This email is sent to the admin when a new affiliate is registered.', 'addify-affiliate-program');
		$this->subject        = __('New Affiliate Registration', 'addify-affiliate-program');
		$this->heading        = __('New Affiliate Registration', 'addify-affiliate-program');
		$this->customer_email = true;
		$this->template_base  = AD_AFFILIATE_DIR;
		$this->template_html  = 'includes/admin/email-template/html/admin-affiliate-program-email-new.php';
		$this->template_plain = 'includes/admin/email-template/plain/admin-affiliate-program-email-new.php';
		$this->recipient      = get_option('admin_email');

		$this->placeholders = array(
			'{affiliate_id}'   => '',
			'{User_name}'      => '',
			'{User_email}'     => '',
		);

		add_action('addify_affiliate_new', array( $this, 'trigger' ), 10, 1);

		parent::__construct();
	}

	public function trigger( $new_form_data ) {
		$this->setup_locale();

		if (!$this->is_enabled() || !$this->get_recipient()) {
			return;
		}

		$this->placeholders = array(
			'{affiliate_id}'   => isset($new_form_data['affiliate_id']) ? $new_form_data['affiliate_id'] : '-',
			'{User_name}'      => isset($new_form_data['User_name']) ? $new_form_data['User_name'] : '-',
			'{User_email}'     => isset($new_form_data['User_email']) ? $new_form_data['User_email'] : '-',
		);

		$this->send(
			$this->get_recipient(),
			$this->get_subject(),
			$this->get_content(),
			$this->get_headers(),
			$this->get_attachments()
		);

		$this->restore_locale();
	}

	public function get_content_html() {
		return wc_get_template_html(
			$this->template_html,
			array( 'new_form_data' => $this->placeholders ),
			'',
			$this->template_base
		);
	}

	public function get_content_plain() {
		return wc_get_template(
			$this->template_plain,
			array( 'new_form_data' => $this->placeholders ),
			'',
			$this->template_base
		);
	}
}
