<?php
if (!defined('ABSPATH')) {
	exit();
}

if (!class_exists('Addify_Affiliate_Coupon_Data_Tab')) :

	class Addify_Affiliate_Coupon_Data_Tab {

		public function addify_add_affiliate_coupon_field( $coupon_id ) {
			wp_nonce_field('addify_affiliate_save_coupon', 'addify_affiliate_nonce');
			$selected_affiliate = get_post_meta($coupon_id, 'addify_affiliate_user_id', true);

			$affiliates = get_users(array(
				'role'    => 'adf_affiliate',
				'orderby' => 'display_name',
				'order'   => 'ASC',
			));

			$options = array( '' => esc_html__('Select affiliate', 'addify-affiliate-program') );
			foreach ($affiliates as $affiliate) {
				$options[ $affiliate->ID ] = $affiliate->display_name . ' (Affiliate ID #' . $affiliate->ID . ')';
			}

			woocommerce_wp_select(array(
				'id'          => 'addify_affiliate_user_id',
				'label'       => esc_html__('Affiliate User', 'addify-affiliate-program'),
				'description' => esc_html__('Assign this coupon to an affiliate.', 'addify-affiliate-program'),
				'desc_tip'    => true,
				'options'     => $options,
				'value'       => $selected_affiliate,
			));
		}

		public function addify_save_affiliate_coupon_field( $coupon_id ) {
			if (
				!isset($_POST['addify_affiliate_nonce']) ||
				!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['addify_affiliate_nonce'])), 'addify_affiliate_save_coupon')
			) {
				return; 
			}
		
			if (isset($_POST['addify_affiliate_user_id'])) {
				update_post_meta(
					$coupon_id,
					'addify_affiliate_user_id',
					sanitize_text_field(wp_unslash($_POST['addify_affiliate_user_id']))
				);
			}
		}
	}

	new Addify_Affiliate_Coupon_Data_Tab();

endif;
