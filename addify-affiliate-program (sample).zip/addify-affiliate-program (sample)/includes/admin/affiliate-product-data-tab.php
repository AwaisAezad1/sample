<?php

if (!defined('ABSPATH')) {
	exit();
}

if (!class_exists('Affiliate_Product_Data_Tab')) :

	class Affiliate_Product_Data_Tab {



		public function addify_af_pr_product_data_panels() {
			global $post;
			wp_nonce_field('addify_af_pr_product_tab_settings_nonce', 'addify_af_pr_product_tab_settings_nonce');
			?>

			<div id="Addify_Af_Pr_product_settings" class="panel woocommerce_options_panel">
				<div class="options_group">

					<!-- User Role Field -->
					<p class="form-field">
						<label for="grouped_user_role"><?php esc_html_e('Select User Role(s)', 'addify-affiliate-program'); ?></label>
						<?php
						$addify_af_pr_user_role = (array) get_post_meta($post->ID, 'addify_Af_Pr_selected_user_role', true);
						global $wp_roles;
						$roles = $wp_roles->get_names();
						?>
						<select class="wc-enhanced-select"
							multiple="multiple"
							id="grouped_user_role"
							name="addify_Af_Pr_selected_user_role[]"
							style="min-width: 300px;">
							<?php foreach ($roles as $key => $value) { ?>
								<option value="<?php echo esc_attr($key); ?>" <?php selected(in_array((string) $key, $addify_af_pr_user_role, true)); ?>>
									<?php echo esc_html($value); ?>
								</option>
							<?php } ?>
							<option value="guest" <?php selected(in_array('guest', $addify_af_pr_user_role, true)); ?>>
								<?php esc_html_e('Guest', 'addify-affiliate-program'); ?>
							</option>
						</select>
						<?php echo wp_kses_post(wc_help_tip(__('Select user role(s) eligible for affiliate commission on this product.', 'addify-affiliate-program'))); ?>
					</p>

					<!-- Commission Type -->
					<p class="form-field">
						<label for="addify_Af_Pr_discount_amount_type">
							<?php esc_html_e('Set Commission Rate Type', 'addify-affiliate-program'); ?>
						</label>
						<?php $addify_Af_Pr_discount_amount_type = get_post_meta($post->ID, 'addify_Af_Pr_discount_amount_type', true); ?>
						<select name="addify_Af_Pr_discount_amount_type" id="addify_Af_Pr_discount_amount_type">
							<option value="fixed" <?php selected($addify_Af_Pr_discount_amount_type, 'fixed'); ?>>
								<?php esc_html_e('Fixed', 'addify-affiliate-program'); ?>
							</option>
							<option value="percentage" <?php selected($addify_Af_Pr_discount_amount_type, 'percentage'); ?>>
								<?php esc_html_e('Percentage', 'addify-affiliate-program'); ?>
							</option>
						</select>
						<?php echo wp_kses_post(wc_help_tip(__('Set commission rate type (fixed or percentage).', 'addify-affiliate-program'))); ?>
					</p>

					<!-- Commission Rate -->
					<p class="form-field">
						<label for="addify_Af_Pr_discount_amount">
							<?php esc_html_e('Set Commission Rate', 'addify-affiliate-program'); ?>
						</label>
						<?php $addify_Af_Pr_discount_amount = get_post_meta($post->ID, 'addify_Af_Pr_discount_amount', true); ?>
						<input type="number"
							class="short"
							name="addify_Af_Pr_discount_amount"
							id="addify_Af_Pr_discount_amount"
							min="0"
							step="0.01"
							placeholder="<?php esc_attr_e('Set commission rate', 'addify-affiliate-program'); ?>"
							value="<?php echo esc_attr($addify_Af_Pr_discount_amount); ?>" />
						<?php echo wp_kses_post(wc_help_tip(__('Set commission amount given to affiliate for this product.', 'addify-affiliate-program'))); ?>
					</p>

				</div>
			</div>

			<?php
		}

		public function addify_af_pr_product_custom_fields_save( $post_id ) {
			if (!current_user_can('edit_posts')) {
				return;
			}

			$exclude_statuses = array( 'auto-draft', 'trash' );
			$action_stlp = isset($_GET['action']) ? sanitize_text_field(wp_unslash($_GET['action'])) : '';

			if (!in_array(get_post_status($post_id), $exclude_statuses) && !is_ajax() && 'untrash' !== $action_stlp) {
				$nonce = isset($_POST['addify_af_pr_product_tab_settings_nonce']) ? sanitize_text_field(wp_unslash($_POST['addify_af_pr_product_tab_settings_nonce'])) : 0;
				if (!wp_verify_nonce($nonce, 'addify_af_pr_product_tab_settings_nonce')) {
					wp_die(esc_html__('Failed Security Check!', 'addify-affiliate-program'));
				}

				$selected_user_role = isset($_POST['addify_Af_Pr_selected_user_role']) ? (array) sanitize_text_field(wp_unslash($_POST['addify_Af_Pr_selected_user_role'])) : array();
				update_post_meta($post_id, 'addify_Af_Pr_selected_user_role', $selected_user_role);

				$addify_Af_Pr_discount_amount = isset($_POST['addify_Af_Pr_discount_amount']) ? sanitize_text_field(wp_unslash($_POST['addify_Af_Pr_discount_amount'])) : '';
				update_post_meta($post_id, 'addify_Af_Pr_discount_amount', $addify_Af_Pr_discount_amount);

				$addify_Af_Pr_discount_amount_type = isset($_POST['addify_Af_Pr_discount_amount_type']) ? sanitize_text_field(wp_unslash($_POST['addify_Af_Pr_discount_amount_type'])) : '';
				update_post_meta($post_id, 'addify_Af_Pr_discount_amount_type', $addify_Af_Pr_discount_amount_type);
			}
		}
	}

	new Affiliate_Product_Data_Tab();

endif;
