<?php

use OTGS\Installer\Api\SiteUrl;

if (!defined('ABSPATH')) {
	exit();
}


if (!class_exists('Addify_Affiliate_Program_Meta_Box')) :

	class Addify_Affiliate_Program_Meta_Box {
	












			// Generate Stripe connect link
			add_action('admin_action_generate_stripe_connect_link', function () {
				if (!current_user_can('manage_options')) {
					wp_die('Unauthorized');
				}
				$user_id_get = filter_input(INPUT_GET, 'user_id', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
				$post_id_get = filter_input(INPUT_GET, 'post_id', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
				$wpnonce_get = filter_input(INPUT_GET, '_wpnonce', FILTER_SANITIZE_FULL_SPECIAL_CHARS);

				$user_id = isset($user_id_get) ? intval($user_id_get) : 0;
				$post_id = isset($post_id_get) ? intval($post_id_get) : 0;

				if (!$user_id || !wp_verify_nonce($wpnonce_get, 'stripe_connect_' . $user_id)) {
					wp_die('Invalid request');
				}

				$stripe_data = get_option('woocommerce_stripe_settings');
				if (empty($stripe_data)) {
					update_option('addify_Af_Pr_admin_side_error_messages', 'Stripe settings not found.');
					wp_safe_redirect(admin_url('post.php?post=' . $post_id . '&action=edit'));
					exit;
				}

				$test_mode  = isset($stripe_data['testmode']) && 'yes' === $stripe_data['testmode'];
				$secret_key = $test_mode ? $stripe_data['test_secret_key'] : $stripe_data['secret_key'];
				$autoload = plugin_dir_path(dirname(dirname(__DIR__))) . 'addify-my-stripe-sdk-addon/vendor/autoload.php';

				if (file_exists($autoload)) {
					require_once $autoload;
				}

				\Stripe\Stripe::setApiKey($secret_key);

				try {
					$stripe_account_id = get_user_meta($user_id, 'stripe_account_id', true);

					if ($stripe_account_id) {
						// Verify that account really belongs to this platform
						$account = \Stripe\Account::retrieve($stripe_account_id);
						if (!$account || $account->id !== $stripe_account_id) {
							throw new Exception('Invalid or disconnected Stripe account.');
						}
					} else {
						// Create new account if none exists
						$account = \Stripe\Account::create(array(
							'type'    => 'express',
							'country' => 'US', // adjust
							'email'   => get_userdata($user_id)->user_email,
						));
						$stripe_account_id = $account->id;
						update_user_meta($user_id, 'stripe_account_id', $stripe_account_id);
					}

					// Generate onboarding link
					$account_link = \Stripe\AccountLink::create(array(
						'account'     => $stripe_account_id,
						'refresh_url' => site_url('/affiliate/connect-stripe?refresh=1&user_id=' . $user_id),
						'return_url'  => site_url('/affiliate/connect-stripe?success=1&user_id=' . $user_id),
						'type'        => 'account_onboarding',
					));

					wp_safe_redirect($account_link->url);
					exit;
				} catch (\Exception $e) {
					// Save the error and redirect back to affiliate post edit
					update_option('addify_Af_Pr_admin_side_error_messages', 'Stripe error: ' . $e->getMessage());
					wp_safe_redirect(admin_url('post.php?post=' . $post_id . '&action=edit'));
					exit;
				}

			// Handle Stripe connection callback
			add_action('addify_affiliate_connect_stripe_handler', function () {
				$user_id = filter_input(INPUT_GET, 'user_id', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
				$success = filter_input(INPUT_GET, 'success', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
				$refresh = filter_input(INPUT_GET, 'refresh', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
				$code = filter_input(INPUT_GET, 'code', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
				$state = filter_input(INPUT_GET, 'state', FILTER_SANITIZE_FULL_SPECIAL_CHARS);

				$user_id = isset($user_id) ? intval($user_id) : 0;
				$success = isset($success) ? $success : '';
				$refresh = isset($refresh) ? $refresh : '';
				$code = isset($code) ? $code : '';
				$state = isset($state) ? $state : '';

				if (!$user_id) {
					wp_die('Invalid request');
				}

				// Get the post ID from user meta or find the affiliate post
				$post_id = get_user_meta($user_id, 'affiliate_post_id', true);
				if (!$post_id) {
					// Find the affiliate post for this user
					$affiliate_posts = get_posts(array(
						'post_type' => 'affiliate_user_post',
						'post_author' => $user_id,
						'posts_per_page' => 1,
						'post_status' => 'any',
					));
					if (!empty($affiliate_posts)) {
						$post_id = $affiliate_posts[0]->ID;
					}
				}

				if ($success) {
					// Success case - account is connected
					$stripe_account_id = get_user_meta($user_id, 'stripe_account_id', true);
					if ($stripe_account_id) {
						// Verify the account is properly connected
						$stripe_data = get_option('woocommerce_stripe_settings');
						if (!empty($stripe_data)) {
							$test_mode         = isset($stripe_data['testmode']) && 'yes' === $stripe_data['testmode'];
							$secret_key = $test_mode ? $stripe_data['test_secret_key'] : $stripe_data['secret_key'];
							$autoload = plugin_dir_path(dirname(dirname(__DIR__))) . 'addify-my-stripe-sdk-addon/vendor/autoload.php';

							if (file_exists($autoload)) {
								require_once $autoload;
							}

							\Stripe\Stripe::setApiKey($secret_key);

							try {
								$account = \Stripe\Account::retrieve($stripe_account_id);
								if ($account && $account->id === $stripe_account_id) {
									// Check if account is fully onboarded
									$is_fully_onboarded = $account->charges_enabled && $account->payouts_enabled;

									// Account is properly connected
									update_user_meta($user_id, 'stripe_account_connected', 'yes');
									update_user_meta($user_id, 'stripe_account_status', $is_fully_onboarded ? 'Connected' : 'Incomplete Onboarding');

									// Set success message based on onboarding status
									if ($is_fully_onboarded) {
										update_option('addify_Af_Pr_admin_side_success_messages', 'Stripe account connected and fully onboarded successfully!');
									} else {
										update_option('addify_Af_Pr_admin_side_success_messages', 'Stripe account connected but onboarding is still incomplete. Please complete the onboarding process.');
									}

									// Redirect to affiliate post edit page
									if ($post_id) {
										wp_safe_redirect(admin_url('post.php?post=' . $post_id . '&action=edit&stripe_connected=1'));
									} else {
										wp_safe_redirect(admin_url('edit.php?post_type=affiliate_user_post&stripe_connected=1'));
									}
									exit;
								}
							} catch (\Exception $e) {
								// Handle error
								update_option('addify_Af_Pr_admin_side_error_messages', 'Stripe connection error: ' . $e->getMessage());
							}
						}
					}
				} elseif ($refresh) {
					// Refresh case - redirect back to connect
					$connect_url = wp_nonce_url(
						admin_url('admin.php?action=generate_stripe_connect_link&user_id=' . $user_id . '&post_id=' . $post_id),
						'stripe_connect_' . $user_id
					);
					wp_safe_redirect($connect_url);
					exit;
				}

				// Default redirect
				if ($post_id) {
					wp_safe_redirect(admin_url('post.php?post=' . $post_id . '&action=edit'));
				} else {
					wp_safe_redirect(admin_url('edit.php?post_type=affiliate_user_post'));
				}
				exit;
			});


		public function prevent_protected_post_deletion( $post_id ) {
			$post_type = get_post_type($post_id);
			$protected_types = array( 'commission_post', 'payout_post' );

			if (in_array($post_type, $protected_types)) {
				wp_die(esc_html__('Deletion of commission and payout records is not allowed.', 'addify-affiliate-program'));
			}
		}

		public function delete_user_meta_on_affiliate_post_delete( $post_id ) {
			// Verify post type - ONLY handle affiliate_user_post
			$post_type = get_post_type($post_id);
			if ('affiliate_user_post' !== $post_type) {
				return;
			}

			$user_id = get_post_field('post_author', $post_id);
			if (!$user_id) {
				return;
			}

			// First, delete all associated commission and payout posts
			$this->delete_associated_affiliate_data($user_id);

			// Then handle user meta cleanup
			$user_obj = new WP_User($user_id);
			$user_status = get_user_meta($user_id, 'affiliate_user_status', true);
			$userRoles = $user_obj->roles;
			if ('approved' === $user_status) {
				if (!in_array('adf_affiliate', (array) $userRoles, true)) {
					$user_obj->add_role('adf_affiliate');
				}
			} elseif (!in_array('adf_affiliate', (array) $userRoles, true)) {
				$user_obj->remove_role('adf_affiliate');
			}

			// Clean up user meta
			$user_meta = get_user_meta($user_id);
			foreach ($user_meta as $meta_key => $value) {
				if (0 === strpos($meta_key, 'reg_')) {
					delete_user_meta($user_id, $meta_key);
				}
			}

			$fields_to_delete = array(
				'paypal_email',
				'min_earning',
				'max_earning',
				'withdrawal_limit',
				'referral_token',
				'affiliate_request_submitted',
				'unpaid_amount',
				'affiliate_user_status',
				'affiliate_auto_payment_method',
				'stripe_account_id',
			);

			foreach ($fields_to_delete as $field) {
				delete_user_meta($user_id, $field);
			}

			delete_option('addify_affiliate_links' . $user_id);

			// Clean up post meta
			$post_meta = get_post_meta($post_id);
			foreach ($post_meta as $meta_key => $value) {
				delete_post_meta($post_id, $meta_key);
			}
		}

		// New function to delete associated commission and payout posts
		public function delete_associated_affiliate_data( $user_id ) {
			// Get all commission posts
			$all_commission_posts = get_posts(array(
				'post_type' => 'commission_post',
				'posts_per_page' => -1,
				'fields' => 'ids',
			));

			// Filter commission posts by affiliate_id using foreach
			$commission_posts = array();
			foreach ($all_commission_posts as $post_id) {
				$affiliate_id = get_post_meta($post_id, 'affiliate_id', true);
				if ($affiliate_id == $user_id) {
					$commission_posts[] = $post_id;
				}
			}

			foreach ($commission_posts as $commission_id) {
				// Bypass our protection temporarily to delete these
				remove_action('before_delete_post', array( $this, 'prevent_protected_post_deletion' ));
				wp_delete_post($commission_id, true);
				add_action('before_delete_post', array( $this, 'prevent_protected_post_deletion' ));
			}

			// Get all payout posts
			$all_payout_posts = get_posts(array(
				'post_type' => 'payout_post',
				'posts_per_page' => -1,
				'fields' => 'ids',
			));

			// Filter payout posts by affiliate_id using foreach
			$payout_posts = array();
			foreach ($all_payout_posts as $post_id) {
				$affiliate_id = get_post_meta($post_id, 'affiliate_id', true);
				if ($affiliate_id == $user_id) {
					$payout_posts[] = $post_id;
				}
			}

			foreach ($payout_posts as $payout_id) {
				// Bypass our protection temporarily to delete these
				remove_action('before_delete_post', array( $this, 'prevent_protected_post_deletion' ));
				wp_delete_post($payout_id, true);
				add_action('before_delete_post', array( $this, 'prevent_protected_post_deletion' ));
			}
		}


		public function Addify_Af_Pr_meta_box_handler() {
			check_ajax_referer('Addify_Af_Pr_meta_box', 'nonce');
			if (isset($_POST['context'])) {
				$context = sanitize_text_field(wp_unslash($_POST['context']));
			}
			if (isset($_POST['q'])) {
				$search_query = sanitize_text_field(wp_unslash($_POST['q']));
			}
			$results = array();

			if ('roles' === $context) {
				global $wp_roles;
				$roles = $wp_roles->get_names();
				$roles['guest'] = 'Guest';
				foreach ($roles as $key => $role_name) {
					if (stripos($role_name, $search_query) !== false) {
						$results[] = array(
							'id' => $key,
							'text' => $role_name,
						);
					}
				}
			} elseif ('products' === $context) {
				// Query for products
				$args = array(
					'post_type' => 'product',
					'posts_per_page' => 10, // Limit the number of results
					's' => $search_query, // Search by title
					'post_status' => 'publish',
				);

				$query = new WP_Query($args);

				if ($query->have_posts()) {
					while ($query->have_posts()) {
						$query->the_post();
						$results[] = array(
							'id' => get_the_ID(),
							'text' => get_the_title(),
						);
					}
					wp_reset_postdata();
				}
			} elseif ('categories' === $context) {
				// Query for categories
				$args = array(
					'taxonomy'   => 'product_cat',
					'hide_empty' => false,
					'search'     => $search_query,
					'number'     => 10, // Limit the number of results
				);

				$categories = get_terms($args);

				if (!is_wp_error($categories)) {
					foreach ($categories as $category) {
						$results[] = array(
							'id' => $category->term_id,
							'text' => $category->name,
						);
					}
				}
			} elseif ('restrict_affiliates' === $context) {
				// Query for restrict_affiliates
				$args = array(
					'post_type' => 'affiliate_user_post',
					'posts_per_page' => 10, // Limit the number of results
					's' => $search_query, // Search by title
					'post_status' => 'publish',
				);
				$query = new WP_Query($args);
				if ($query->have_posts()) {
					while ($query->have_posts()) {
						$query->the_post();
						$user_id = get_post_field('post_author', get_the_ID());
						$results[] = array(
							'id' => $user_id,
							'text' => get_the_title(),
						);
					}
					wp_reset_postdata();
				}
			} elseif ('restrict_affiliates2' === $context) {
				// Query for restrict_affiliates2
				$args = array(
					'post_type'      => 'affiliate_user_post',
					'posts_per_page' => 10, // Limit the number of results
					's'              => $search_query, // Search by title
					'post_status'    => 'publish',
				);
				$query = new WP_Query($args);
				if ($query->have_posts()) {
					while ($query->have_posts()) {
						$query->the_post();

						// Get the affiliate's user ID (post_author)
						$affiliate_user_id = get_post_field('post_author', get_the_ID());

						$results[] = array(
							'id'   => $affiliate_user_id, // Store the user ID, not post ID
							'text' => get_the_title(),
						);
					}
					wp_reset_postdata();
				}
			} elseif ('brands' === $context) {
				$args = array(
					'taxonomy'   => 'product_brand',
					'hide_empty' => false,
					'search'     => $search_query,
					'number'     => 10, // Limit the number of results
				);

				$brands = get_terms($args);

				if (!is_wp_error($brands)) {
					foreach ($brands as $brand) {
						$results[] = array(
							'id'   => $brand->term_id,
							'text' => $brand->name,
						);
					}
				}
			} elseif ('payments' === $context) {

				$allowed_methods = array( 'bacs', 'stripe', 'ppcp-gateway' );

				$available_gateways = WC_Payment_Gateways::instance()->payment_gateways();

				$results = array();

				foreach ($available_gateways as $gateway) {
					if (in_array($gateway->id, $allowed_methods, true)) {
						$title = $gateway->get_title();

						if ('' === $search_query || false !== stripos($title, $search_query) || false !== stripos($gateway->id, $search_query)) {
							$results[] = array(
								'id' => $gateway->id,
								'text' => $title,
							);
						}
					}
				}
			}


			wp_send_json($results);
		}
		public function Addify_Af_Pr_enqueue_scripts() {
			$screen = get_current_screen();

			if ('woocommerce_page_addify_menu_page_dashboard' === $screen->id || 'rule_setting_tab' === $screen->id || 'affiliate_user_post' === $screen->id || 'woocommerce_page_addify_menu_page_payout' === $screen->id || 'woocommerce_page_addify_menu_page' === $screen->id || 'payout_post' === $screen->id || 'commission_post' === $screen->id || 'registration_post' === $screen->id) {
				wp_enqueue_style('Addify-Af-Pr-select2-css', plugins_url('assets/css/select2.css', WC_PLUGIN_FILE), array(), '5.7.2');
				wp_enqueue_script('Addify-Af-Pr-select2-js', plugins_url('assets/js/select2/select2.min.js', WC_PLUGIN_FILE), array( 'jquery' ), '4.0.3', true);
				if ('woocommerce_page_addify_menu_page_dashboard' === $screen->id) {
					wp_enqueue_script('Addify_Af_Pr_js_call_chart', AD_AFFILIATE_URL . 'assets/js/Addify_Af_Pr_admin_chart.js', array( 'jquery' ), '1.0.2', false);
				} else {
					wp_enqueue_script('Addify_Af_Pr_js_call', AD_AFFILIATE_URL . 'assets/js/Addify_Af_Pr_admin.js', array( 'jquery' ), '1.0.2', false);
				}
				wp_enqueue_style('ad_font_awesomefont', AD_AFFILIATE_URL . 'assets/font-awesome/css/font-awesome.min.css', array(), '4.7.0');
				wp_enqueue_style('Addify_Af_Pr_admin', AD_AFFILIATE_URL . '/assets/css/Addify_Af_Pr_admin.css', false, '1.1');
				wp_enqueue_script('chart-js', AD_AFFILIATE_URL . 'assets/js/chart-umd.js', array(), '1.0.0', true);
				wp_enqueue_script('jquery');
				wp_enqueue_media();
				wp_enqueue_script('flatpickr-js', AD_AFFILIATE_URL . 'assets/js/flatpickr.min.js', array(), '4.6.13', true);
				wp_enqueue_style('flatpickr-css', AD_AFFILIATE_URL . '/assets/css/flatpickr.min.css', false, '4.6.13');

				if (class_exists('WooCommerce')) {
					wp_enqueue_script('jquery-tiptip');
					wp_enqueue_style('woocommerce_admin_styles', WC()->plugin_url() . '/assets/css/admin.css', array(), WC()->version);
				}
				$wp_timezone = get_option('timezone_string');

				if (!$wp_timezone) {
					$offset = (float) get_option('gmt_offset');
					$sign   = ( $offset <= 0 ) ? '+' : '-';
					$hours  = abs($offset);
					$wp_timezone = 'Etc/GMT' . $sign . $hours;
				}

				$tz = new DateTimeZone($wp_timezone);

				// Set start and end of today in WP timezone
				$today = new DateTime('today', $tz);
				$start = clone $today;
				$end   = new DateTime('today 23:59:59', $tz);

				// Initialize 24 hours of data
				$labels = array();
				$data_template = array();
				for ($hour = 0; $hour < 24; $hour++) {
					$key = $today->format('Y-m-d') . ' ' . str_pad($hour, 2, '0', STR_PAD_LEFT) . ':00';
					$labels[] = str_pad($hour, 2, '0', STR_PAD_LEFT) . ':00';
					$data_template[ $key ] = 0;
				}

				$unpaid_by_hour               = $data_template;
				$paid_by_hour                 = $data_template;
				$total_earnings_by_hour       = $data_template;
				$total_refunds_by_hour        = $data_template;
				$refunded_commissions_by_hour = $data_template;
				$commission_earned_by_hour    = $data_template;
				$total_clicks_by_hour         = $data_template;

				// Step 1: Collect all affiliate logs (hourly_stats)
				$all_affiliate_posts = get_posts(array(
					'post_type'      => 'affiliate_user_post',
					'post_status'    => 'any',
					'posts_per_page' => -1,
				));

				$affiliates_data = array();
				foreach ($all_affiliate_posts as $aff_post) {
					$affiliate_id  = $aff_post->ID;
					$hourly_stats  = get_post_meta($affiliate_id, 'hourly_stats', true);
					if (!empty($hourly_stats) && is_array($hourly_stats)) {
						foreach ($hourly_stats as $timestamp => $log) {
							$affiliates_data[ $affiliate_id ][ $timestamp ] = $log;
						}
					}
				}


				// Initialize time buckets (based on your labels/template)
				$key_format = 'Y-m-d H:00'; // hourly view

				// Initialize arrays
				foreach ($labels as $label) {
					$paid_by_hour[ $label ]                 = 0;
					$unpaid_by_hour[ $label ]               = 0;
					$total_earnings_by_hour[ $label ]       = 0;
					$total_refunds_by_hour[ $label ]        = 0;
					$total_clicks_by_hour[ $label ]         = 0;
					$commission_earned_by_hour[ $label ]    = 0;
					$refunded_commissions_by_hour[ $label ] = 0;
				}

				// Step 2: Process affiliate logs (hourly_stats)
				foreach ($affiliates_data as $affiliate_id => $logs) {
					foreach ($logs as $timestamp => $log) {
						try {
							$log_dt = new DateTime($timestamp, $tz);
						} catch (Exception $e) {
							continue;
						}

						// Only include logs within the range
						if ($log_dt < $start || $log_dt > $end) {
							continue;
						}

						$key = $log_dt->format($key_format);
						if (!isset($paid_by_hour[ $key ])) {
							continue;
						}

						$paid   = isset($log['paid']) ? (float) $log['paid'] : 0;
						$unpaid = isset($log['unpaid']) ? (float) $log['unpaid'] : 0;
						$refund = isset($log['refunds']) ? (float) $log['refunds'] : 0;
						$clicks = isset($log['clicks']) ? (int) $log['clicks'] : 0;
						$earned = isset($log['earnings']) ? (float) $log['earnings'] : 0;

						// Aggregate paid/unpaid safely
						$paid_by_hour[ $key ]   += $paid;
						$unpaid_by_hour[ $key ] += max(0, $unpaid - $paid);

						// Add totals
						$total_earnings_by_hour[ $key ] += $earned;
						$total_refunds_by_hour[ $key ]  += $refund;
						$total_clicks_by_hour[ $key ]   += $clicks;
					}
				}

				// Step 3: Process commission posts (count, refunded commissions, refund totals)
				$all_commission_posts = get_posts(array(
					'post_type'      => 'commission_post',
					'post_status'    => 'any',
					'posts_per_page' => -1,
					'date_query'     => array(
						array(
							'after'     => $start->format('Y-m-d H:i:s'),
							'before'    => $end->format('Y-m-d H:i:s'),
							'inclusive' => true,
						),
					),
				));

				foreach ($all_commission_posts as $commission_post) {
					try {
						$dt = new DateTime($commission_post->post_date, $tz);
					} catch (Exception $e) {
						continue;
					}

					$key = $dt->format($key_format);
					if (!isset($commission_earned_by_hour[ $key ])) {
						continue;
					}

					$commission_earned_by_hour[ $key ]++;

					$amount = (float) get_post_meta($commission_post->ID, 'unpaid_amount', true);
					$status = get_post_meta($commission_post->ID, 'commission_status', true);

					if ('refunded' == $status) {
						// Add refunded commission amount
						$refunded_commissions_by_hour[ $key ] += $amount;

						// Increase refund count
						$total_refunds_by_hour[ $key ] += 1;

						// Deduct refund amount from total earnings (if previously counted)
						$total_earnings_by_hour[ $key ] = max(0, $total_earnings_by_hour[ $key ] - $amount);

						// Reduce unpaid by refunded amount (avoid negatives)
						$unpaid_by_hour[ $key ] = max(0, $unpaid_by_hour[ $key ] - $amount);
					}
				}


				// Step 4: Format JSON output
				$start_clone = clone $start;
				$end_clone   = clone $end;

				$json_start = array(
					'date'           => $start_clone->format('Y-m-d H:i:s') . '.000000',
					'timezone_type'  => 3,
					'timezone'       => $wp_timezone,
				);

				$json_end = array(
					'date'           => $end_clone->format('Y-m-d H:i:s') . '.000000',
					'timezone_type'  => 3,
					'timezone'       => $wp_timezone,
				);

				$wsp_data = array(
					'chart_data' => array(
						'unpaid_earnings'           => array_values($unpaid_by_hour),
						'paid_earnings'             => array_values($paid_by_hour),
						'total_earnings'            => array_values($total_earnings_by_hour),
						'total_refunds'             => array_values($total_refunds_by_hour),
						'total_refunded_commission' => array_values($refunded_commissions_by_hour),
						'total_commission_earned'   => array_values($commission_earned_by_hour),
						'total_clicks'              => array_values($total_clicks_by_hour),
						'labels'                    => array_values($labels),
						'start_date'                => $json_start,
						'end_date'                  => $json_end,
						'range'                     => 'today',

					),

					'admin_url' => admin_url('admin-ajax.php'),
					'nonce'     => wp_create_nonce('Addify_Af_Pr_meta_box'),
					'choose_role' => esc_html__('Choose role', 'addify-affiliate-program'),
					'choose_products' => esc_html__('Choose products', 'addify-affiliate-program'),
					'choose_categories' => esc_html__('Choose categories', 'addify-affiliate-program'),
					'choose_affiliate' => esc_html__('Choose affiliate', 'addify-affiliate-program'),
					'choose_brands' => esc_html__('Choose Brand', 'addify-affiliate-program'),
					'choose_payment' => esc_html__('Choose payment method', 'addify-affiliate-program'),
					'remove' => esc_html__('Remove', 'addify-affiliate-program'),
					'active' => esc_html__('Active', 'addify-affiliate-program'),
					'inactive' => esc_html__('Inactive', 'addify-affiliate-program'),
					'fixed' => esc_html__('Fixed', 'addify-affiliate-program'),
					'percentage' => esc_html__('Percentage', 'addify-affiliate-program'),
					'enabled_text' => esc_html__('Enabled', 'addify-affiliate-program'),
					'disabled_text' => esc_html__('Disabled', 'addify-affiliate-program'),
				);
				if ('woocommerce_page_addify_menu_page_dashboard' === $screen->id) {
					wp_localize_script(
						'Addify_Af_Pr_js_call_chart',
						'wsp_php_vars',
						$wsp_data
					);
				} else {
					wp_localize_script(
						'Addify_Af_Pr_js_call',
						'wsp_php_vars',
						$wsp_data
					);
				}
			}
		}
		public function Addify_Af_Pr_meta_box() {
			add_meta_box('Addify_Af_Pr_meta_box', esc_html__('Campaigns', 'addify-affiliate-program'), array( $this, 'Addify_Af_Pr_rule_meta_box_callback' ), 'rule_setting_tab', 'normal', 'default');
			add_meta_box('Addify_Af_Pr_meta_box', esc_html__('Affiliate Details', 'addify-affiliate-program'), array( $this, 'Addify_Af_Pr_affiliate_meta_box_callback' ), 'affiliate_user_post', 'normal', 'default');
			add_meta_box('Addify_Af_Pr_meta_box_1', esc_html__('Affiliate Payout log', 'addify-affiliate-program'), array( $this, 'Addify_Af_Pr_affiliate_payout_meta_box_callback' ), 'affiliate_user_post', 'normal', 'default');
			add_meta_box('Addify_Af_Pr_meta_box', esc_html__('Commission Information', 'addify-affiliate-program'), array( $this, 'Addify_Af_Pr_commission_meta_box_callback' ), 'commission_post', 'normal', 'default');
			add_meta_box('Addify_Af_Pr_meta_box', esc_html__('Payout Information', 'addify-affiliate-program'), array( $this, 'Addify_Af_Pr_payout_meta_box_callback' ), 'payout_post', 'normal', 'default');
			add_meta_box('Addify_Af_Pr_meta_box', esc_html__('Registration Settings', 'addify-affiliate-program'), array( $this, 'Addify_Af_Pr_registration_meta_box_callback' ), 'registration_post', 'normal', 'default');
		}
		public function Addify_Af_Pr_rule_meta_box_callback( $post ) {
			wp_nonce_field('Addify_Af_Pr_meta_box', 'Addify_Af_Pr_meta_box_nonce');
			$Addify_Af_Pr_applied_products =  (array) get_post_meta(intval($post->ID), 'Addify_Af_Pr_applied_products', true);
			$Addify_Af_Pr_applied_categories =  (array) get_post_meta(intval($post->ID), 'Addify_Af_Pr_applied_categories', true);
			$Addify_Af_Pr_applied_brands =  (array) get_post_meta(intval($post->ID), 'Addify_Af_Pr_applied_brands', true);
			$cart_content_check = get_post_meta(intval($post->ID), 'Addify_Af_Pr_apply_all', true);
			$Addify_Af_Pr_inform_existing_affiliates = get_post_meta(intval($post->ID), 'Addify_Af_Pr_inform_existing_affiliates', true);
			?>
			<div class="Addify-Af-Pr-main-admin-body">
				<table class="form-table threat-settings-table">

					<!-- Apply on all -->
					<tr>
						<th>
							<label for="Addify_Af_Pr_apply_all">
								<strong><?php echo esc_html__('Apply On All Products And Categories', 'addify-affiliate-program'); ?></strong>
							</label>
						</th>
						<td>
							<?php echo wp_kses_post(wc_help_tip(esc_html__('Enable to show all products in link generation dropdown.', 'addify-affiliate-program'))); ?>
							<input type="checkbox" id="Addify_Af_Pr_apply_all" class="Addify_Af_Pr_check" name="Addify_Af_Pr_apply_all" value="yes" <?php checked($cart_content_check, 'yes'); ?>>
						</td>
					</tr>
					<!-- Select Products -->
					<tr>
						<th>
							<label for="Addify_Af_Pr_applied_products">
								<?php echo esc_html__('Apply On Specific Products', 'addify-affiliate-program'); ?>
							</label>
						</th>
						<td>
							<?php echo wp_kses_post(wc_help_tip(esc_html__('Select products to show in link generation dropdown.', 'addify-affiliate-program'))); ?>
							<select class="sel_pros" name="Addify_Af_Pr_applied_products[]" id="Addify_Af_Pr_applied_products" multiple>
								<?php
								if (!empty($Addify_Af_Pr_applied_products)) {
									foreach ($Addify_Af_Pr_applied_products as $select_product) {
										$prod_post = wc_get_product($select_product);
										if (!is_object($prod_post)) {
											continue;
										}
										?>
										<option value="<?php echo intval($select_product); ?>" selected="selected">
											<?php echo esc_html($prod_post->get_name()); ?>
										</option>
								<?php
									}
								}
								?>
							</select>
						</td>
					</tr>

					<!-- Select Categories -->
					<tr>
						<th>
							<label for="Addify_Af_Pr_applied_categories">
								<?php echo esc_html__('Apply On Specific Categories', 'addify-affiliate-program'); ?>
							</label>
						</th>
						<td>
							<?php echo wp_kses_post(wc_help_tip(esc_html__('Select categories to show it\'s related products in link generation dropdown.', 'addify-affiliate-program'))); ?>
							<select class="sel_categories af-cp-prd-scroll" name="Addify_Af_Pr_applied_categories[]" multiple>
								<?php
								foreach ($Addify_Af_Pr_applied_categories as $value) {
									if ($value) {
										$term = get_term($value);
										if (is_object($term)) {
											?>
											<option value="<?php echo esc_attr($value); ?>" selected>
												<?php echo esc_html($term->name); ?>
											</option>
								<?php
										}
									}
								}
								?>
							</select>
						</td>
					</tr>
					<!-- Select Brands -->
					<tr>
						<th>
							<label for="Addify_Af_Pr_applied_brands">
								<?php echo esc_html__('Apply On Specific Brands', 'addify-affiliate-program'); ?>
							</label>
						</th>
						<td>
							<?php echo wp_kses_post(wc_help_tip(esc_html__('Select brands to show it\'s related products in link generation dropdown.', 'addify-affiliate-program'))); ?>
							<select class="sel_brands af-cp-prd-scroll" name="Addify_Af_Pr_applied_brands[]" multiple>
								<?php
								if (!empty($Addify_Af_Pr_applied_brands)) {
									foreach ($Addify_Af_Pr_applied_brands as $brand_id) {
										if ($brand_id) {
											$brand = get_term($brand_id, 'product_brand');

											if (is_object($brand)) {
												?>
												<option value="<?php echo esc_attr($brand->term_id); ?>" selected>
													<?php echo esc_html($brand->name); ?>
												</option>
								<?php
											}
										}
									}
								}
								?>
							</select>
						</td>
					</tr>


					<!-- product price restriction -->
					<tr>
						<th>
							<label for="Addify_Af_Pr_product_price">
								<?php echo esc_html__('Set Price Range For Affiliates ', 'addify-affiliate-program'); ?>
							</label>
						</th>
						<td>
							<?php echo wp_kses_post(wc_help_tip(esc_html__('Apply to include only the products in the minimum and maximum range.', 'addify-affiliate-program'))); ?>
							<input type="number" id="Addify_Af_Pr_value_min" placeholder="<?php echo esc_html__('Minimum Range', 'addify-affiliate-program'); ?>" name="Addify_Af_Pr_value_min" value="<?php echo esc_attr(get_post_meta(intval($post->ID), 'Addify_Af_Pr_value_min', true)); ?>" />
							-
							<input type="number" id="Addify_Af_Pr_value_max" placeholder="<?php echo esc_html__('Maximum Range', 'addify-affiliate-program'); ?>" name="Addify_Af_Pr_value_max" value="<?php echo esc_attr(get_post_meta(intval($post->ID), 'Addify_Af_Pr_value_max', true)); ?>" />

						</td>
					</tr>
					<!-- Enable to inform existing affiliates about new campaigns -->
					<tr>
						<th>
							<label for="Addify_Af_Pr_inform_existing_affiliates">
								<strong><?php echo esc_html__('Inform Existing Affiliates About New Campaigns', 'addify-affiliate-program'); ?></strong>
							</label>
						</th>
						<td>
							<?php echo wp_kses_post(wc_help_tip(esc_html__('Enable to inform existing affiliates about new campaigns.', 'addify-affiliate-program'))); ?>
							<input type="checkbox" id="Addify_Af_Pr_inform_existing_affiliates" class="Addify_Af_Pr_check" name="Addify_Af_Pr_inform_existing_affiliates" value="yes" <?php checked($Addify_Af_Pr_inform_existing_affiliates, 'yes'); ?>>
						</td>
					</tr>
					<!-- Commission rate select field to select fixed or percentage  -->
					<tr>
						<th>
							<label for="Addify_Af_Pr_rule_commission_rate_type">
								<?php echo esc_html__('Affiliate Commission ', 'addify-affiliate-program'); ?>
							</label>
						</th>
						<td>
							<?php echo wp_kses_post(wc_help_tip(esc_html__('Select to apply affiliate commission rate as fixed or percentage.', 'addify-affiliate-program'))); ?>
							<select name="Addify_Af_Pr_rule_commission_rate_type" id="Addify_Af_Pr_rule_commission_rate_type">
								<option value="fixed" <?php selected(get_post_meta(intval($post->ID), 'Addify_Af_Pr_rule_commission_rate_type', true), 'fixed'); ?>><?php echo esc_html__('Fixed', 'addify-affiliate-program'); ?></option>
								<option value="percentage" <?php selected(get_post_meta(intval($post->ID), 'Addify_Af_Pr_rule_commission_rate_type', true), 'percentage'); ?>><?php echo esc_html__('Percentage', 'addify-affiliate-program'); ?></option>
							</select>
						</td>
					</tr>

					<!-- Commission rate -->
					<tr>
						<th>
							<label for="Addify_Af_Pr_rule_commission_rate_value">
								<?php echo esc_html__('Commission Rate', 'addify-affiliate-program'); ?>
							</label>
						</th>
						<td>
							<?php echo wp_kses_post(wc_help_tip(esc_html__('Enter the commission rate value.', 'addify-affiliate-program'))); ?>
							<input type="number" min="0" id="Addify_Af_Pr_rule_commission_rate_value" name="Addify_Af_Pr_rule_commission_rate_value" value="<?php echo esc_attr(get_post_meta(intval($post->ID), 'Addify_Af_Pr_rule_commission_rate_value', true)); ?>" />
						</td>
					</tr>

					<!-- Expiry date -->
					<tr>
						<th>
							<label for="Addify_Af_Pr_rule_expiry_date">
								<?php echo esc_html__('Expiry Date', 'addify-affiliate-program'); ?>
							</label>
						</th>
						<td>
							<?php echo wp_kses_post(wc_help_tip(esc_html__('Expiry date of rule.', 'addify-affiliate-program'))); ?>
							<input type="date" id="Addify_Af_Pr_rule_expiry_date" name="Addify_Af_Pr_rule_expiry_date" value="<?php echo esc_attr(get_post_meta(intval($post->ID), 'Addify_Af_Pr_rule_expiry_date', true)); ?>" />
						</td>
					</tr>
				</table>
			</div>
		<?php
		}
		public function Addify_Af_Pr_commission_meta_box_callback( $post ) {
			wp_nonce_field('Addify_Af_Pr_meta_box', 'Addify_Af_Pr_meta_box_nonce');
			$order_id          = get_post_meta($post->ID, 'order_id', true);
			$order              = wc_get_order($order_id);
			$product_id        = get_post_meta($post->ID, 'product_id', true);
			$commission_amount = floatval(get_post_meta($post->ID, 'unpaid_amount', true));

			$product = wc_get_product($product_id);
			$product_name = $product ? '<a href="' . esc_url(get_edit_post_link($product->get_id())) . '" target="_blank">' . esc_html($product->get_name()) . '</a>' : 'N/A';
			$product_price = $product ? wc_price($product->get_price()) : wc_price(0);
			$product_sku = $product ? $product->get_sku() : '';
			$product_price_clean = preg_replace('/[^\d.]/', '', $product_price);
			$product_price = floatval($product_price_clean);
			$order_link = $order_id ? admin_url("post.php?post=$order_id&action=edit") : '#';

			?>
			<div class="commission_body">
				<div class="commission_body">
					<div class="commission-box">
						<h3><?php echo esc_html__('Order #', 'addify-affiliate-program'); ?><a href="<?php echo esc_url($order_link); ?>"><?php echo esc_html($order_id); ?></a> <?php echo esc_html__('details', 'addify-affiliate-program'); ?></h3>
						<?php if ($order) : ?>
							<p class="commission-note"><?php echo esc_html__('Payment via', 'addify-affiliate-program'); ?><?php echo esc_html($order->get_payment_method_title()); ?>. <?php echo esc_html__('Paid on', 'addify-affiliate-program'); ?> <?php echo esc_html($order->get_date_paid()->date('F j, Y @ g:i a')); ?>. <?php echo esc_html__('Customer IP', 'addify-affiliate-program'); ?>: <?php echo esc_html($order->get_customer_ip_address()); ?></p>
							<div class="commission-columns">
								<!-- General -->
								<div class="commission-column">
									<h4><?php echo esc_html__('General', 'addify-affiliate-program'); ?></h4>
									<p><strong><?php echo esc_html__('Date created', 'addify-affiliate-program'); ?>:</strong><br> <?php echo esc_html($order->get_date_created()->date('Y-m-d')); ?> @ <?php echo esc_html($order->get_date_created()->date('H:i')); ?></p>
									<p><strong><?php echo esc_html__('Status', 'addify-affiliate-program'); ?>:</strong><br> <?php echo esc_html(wc_get_order_status_name($order->get_status())); ?></p>
									<p><strong><?php echo esc_html__('Customer', 'addify-affiliate-program'); ?>:</strong><br>
										<a href="<?php echo esc_url(get_edit_user_link($order->get_customer_id())); ?>">
											<?php echo esc_html($order->get_formatted_billing_full_name()); ?> (#<?php echo esc_html($order->get_customer_id()); ?> - <?php echo esc_html($order->get_billing_email()); ?>)
										</a>
									</p>
								</div>

								<!-- Billing -->
								<div class="commission-column">
									<h4><?php echo esc_html__('Billing', 'addify-affiliate-program'); ?></h4>
									<p><?php echo esc_html($order->get_formatted_billing_full_name()); ?></p>
									<p><?php echo nl2br(esc_html($order->get_billing_address_1())); ?></p>
									<p><?php echo esc_html($order->get_billing_city()); ?></p>
									<p><?php echo esc_html($order->get_billing_postcode()); ?></p>
									<p><?php echo esc_html($order->get_billing_country()); ?></p>
									<p><strong><?php echo esc_html__('Email address', 'addify-affiliate-program'); ?>:</strong><br> <?php echo esc_html($order->get_billing_email()); ?></p>
									<p><strong><?php echo esc_html__('Phone', 'addify-affiliate-program'); ?>:</strong><br> <?php echo esc_html($order->get_billing_phone()); ?></p>
								</div>

								<!-- Shipping -->
								<div class="commission-column">
									<h4><?php echo esc_html__('Shipping', 'addify-affiliate-program'); ?></h4>
									<p><?php echo esc_html($order->get_formatted_shipping_full_name()); ?></p>
									<p><?php echo nl2br(esc_html($order->get_shipping_address_1())); ?></p>
									<p><?php echo esc_html($order->get_shipping_city()); ?></p>
									<p><?php echo esc_html($order->get_shipping_postcode()); ?></p>
									<p><?php echo esc_html($order->get_shipping_country()); ?></p>
								</div>
							</div>
						<?php else : ?>
							<p><em><?php echo esc_html__('Order details not available.', 'addify-affiliate-program'); ?></em></p>
							<?php return; ?>
						<?php endif; ?>
					</div>
				</div>
				<br>

				<table class="widefat fixed striped">
					<?php

					$affiliate_product = wc_get_product($product_id); // $product_id = affiliate product ID
					if (!empty($affiliate_product)) {
						?>
						<thead>
							<th colspan="5" style="text-align: center;"><?php echo esc_html__('Link Based Commission', 'addify-affiliate-program'); ?>
								<br>
								<?php echo esc_html__('Total Commission', 'addify-affiliate-program') . ': ' . wp_kses_post(wc_price($commission_amount)); ?>
							</th>


							<tr>
								<th><?php echo esc_html__('Product', 'addify-affiliate-program'); ?></th>
								<th><?php echo esc_html__('SKU', 'addify-affiliate-program'); ?></th>
								<th><?php echo esc_html__('Cost', 'addify-affiliate-program'); ?></th>
								<th><?php echo esc_html__('Qty', 'addify-affiliate-program'); ?></th>
								<th><?php echo esc_html__('Total', 'addify-affiliate-program'); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php
							$matched_items = array();

							if (! $affiliate_product) {
								return;
							}

							if ($affiliate_product->is_type('grouped')) {
								// For grouped product, get children
								$child_ids = $affiliate_product->get_children();

								foreach ($order->get_items() as $item_id => $item) {
									$item_product_id = (int) $item->get_product_id();
									if (in_array($item_product_id, $child_ids, true)) {
										$matched_items[ $item_id ] = $item;
									}
								}
							} else {
								// For simple or variable product
								foreach ($order->get_items() as $item_id => $item) {
									$item_product_id = (int) $item->get_product_id();
									if ($item_product_id === (int) $affiliate_product->get_id()) {
										$matched_items[ $item_id ] = $item;
									}
								}
							}

							$is_grouped = $affiliate_product->is_type('grouped');
							$commission_amount = floatval(get_post_meta($post->ID, 'unpaid_amount', true));

							// Prepare commission distribution for grouped product
							$total_group_value = 0;
							$grouped_item_totals = array();

							if ($is_grouped) {
								$child_ids = $affiliate_product->get_children();

								// Step 1: calculate total of child items from order
								foreach ($matched_items as $item) {
									$pid = isset($item['product_id']) ? $item['product_id'] : 0;
									if (in_array($pid, $child_ids)) {
										$value = floatval($item->get_total());
										$total_group_value += $value;
										$grouped_item_totals[ $pid ] = $value;
									}
								}
							}

							foreach ($matched_items as $item) :
								$product_id = isset($item['product_id']) ? $item['product_id'] : 0;
								$product    = wc_get_product($product_id);
								if (!$product) {
									continue;
								}

								$product_name  = '<a href="' . esc_url(get_edit_post_link($product_id)) . '" target="_blank">' . esc_html($product->get_name()) . '</a>';
								$product_sku   = $product->get_sku();
								$product_price_raw = floatval($product->get_price());
								$product_price = wc_price($product_price_raw);
								$quantity      = $item->get_quantity();
								$line_total_raw = floatval($item->get_total());
								$line_total    = wc_price($line_total_raw);


								$thumbnail_id = $product->get_image_id();
								$image_html = wp_get_attachment_image($thumbnail_id, 'thumbnail', false, array(
									'style' => 'width:40px; height:auto; margin-right:10px; vertical-align:middle;',
								));

								?>
								<tr>
									<td><?php echo wp_kses_post($image_html . ' ' . $product_name); ?></td>
									<td><?php echo wp_kses_post($product_sku); ?></td>
									<td><?php echo wp_kses_post($product_price); ?></td>
									<td><?php echo wp_kses_post($quantity); ?></td>
									<td><?php echo wp_kses_post($line_total); ?></td>

								</tr>
							<?php
							endforeach;
					} else {

						?>
							<thead>
								<th colspan="5" style="text-align: center;"><?php echo esc_html__('Coupon Based Commission', 'addify-affiliate-program'); ?>
									<br>
								<?php echo esc_html__('Total Commission', 'addify-affiliate-program') . ': ' . wp_kses_post(wc_price($commission_amount)); ?>
								</th>
								<tr>
									<th><?php echo esc_html__('Product', 'addify-affiliate-program'); ?></th>
									<th><?php echo esc_html__('SKU', 'addify-affiliate-program'); ?></th>
									<th><?php echo esc_html__('Cost', 'addify-affiliate-program'); ?></th>
									<th><?php echo esc_html__('Qty', 'addify-affiliate-program'); ?></th>
									<th><?php echo esc_html__('Total', 'addify-affiliate-program'); ?></th>
								</tr>
							</thead>
						<tbody>
							<?php
							// If no product is found, assume it's a coupon-based commission
							foreach ($order->get_items() as $item) {
								$product_id = isset($item['product_id']) ? $item['product_id'] : 0;
								$product    = wc_get_product($product_id);
								if (!$product) {
									continue;
								}
								$product_name  = '<a href="' . esc_url(get_edit_post_link($product_id)) . '" target="_blank">' . esc_html($product->get_name()) . '</a>';
								$product_sku   = $product->get_sku();
								$product_price_raw = floatval($product->get_price());
								$product_price = wc_price($product_price_raw);
								$quantity      = $item->get_quantity();
								$line_total_raw = floatval($item->get_total());
								$line_total    = wc_price($line_total_raw);
								$thumbnail_id = $product->get_image_id();
								$image_html = wp_get_attachment_image($thumbnail_id, 'thumbnail', false, array(
									'style' => 'width:40px; height:auto; margin-right:10px; vertical-align:middle;',
								));

								?>
								<tr>

									<td><?php echo wp_kses_post($image_html . ' ' . $product_name); ?></td>
									<td><?php echo wp_kses_post($product_sku); ?></td>
									<td><?php echo wp_kses_post($product_price); ?></td>
									<td><?php echo wp_kses_post($quantity); ?></td>
									<td><?php echo wp_kses_post($line_total); ?></td>

								</tr>
						<?php
							}
					}
					?>


						</tbody>

				</table>
			</div>
		<?php
		}
		public function Addify_Af_Pr_payout_meta_box_callback( $post ) {
			wp_nonce_field('Addify_Af_Pr_meta_box', 'Addify_Af_Pr_meta_box_nonce');

			$affiliate_id      = intval(get_post_meta($post->ID, 'affiliate_id', true));
			$commission_amount = round(floatval(get_post_meta($post->ID, 'unpaid_amount', true)), 2);


			$affiliate_user = get_user_by('ID', $affiliate_id);

			$affiliate_name = $affiliate_user ? $affiliate_user->display_name : 'Unknown';
			$payment_restriction = get_option('Addify_Af_Pr_payment_method_restriction');

			// Allowed methods
			$allowed_methods = array( 'bacs', 'stripe', 'ppcp-gateway' );

			// Remove restricted methods from allowed
			if (!empty($payment_restriction) && is_array($payment_restriction)) {
				$allowed_methods = array_diff($allowed_methods, $payment_restriction);
			}


			// Get all payment gateways
			$available_gateways = WC_Payment_Gateways::instance()->payment_gateways();

			// Filter to get only allowed methods
			$selected_payment_methods = array_filter($available_gateways, function ( $method ) use ( $allowed_methods ) {
				return in_array($method->id, $allowed_methods, true);
			});

			// Get enabled gateway IDs
			$enabled_gateways = array_keys(array_filter($available_gateways, function ( $gateway ) {
				return isset($gateway->enabled) && 'yes' === $gateway->enabled;
			}));
			?>
			<div class="Addify-Af-Pr-main-admin-body">
				<table class="form-table threat-settings-table">

					<!-- Affiliate Name -->
					<tr>
						<th><label for="Addify_Af_Pr_affiliate_name"><strong><?php echo esc_html__('Affiliate Name', 'addify-affiliate-program'); ?></strong></label></th>
						<td>
							<?php echo wp_kses_post(wc_help_tip(esc_html__('Affiliate name of current payout.', 'addify-affiliate-program'))); ?>
							<input type="text" id="Addify_Af_Pr_affiliate_name" name="Addify_Af_Pr_affiliate_name" value="<?php echo esc_attr($affiliate_name); ?>" readonly />
						</td>
					</tr>

					<!-- Affiliate Email -->
					<tr>
						<th><label for="Addify_Af_Pr_affiliate_email"><strong><?php echo esc_html__('Affiliate Email of Current Payout', 'addify-affiliate-program'); ?></strong></label></th>
						<td>
							<?php echo wp_kses_post(wc_help_tip(esc_html__('Affiliate email.', 'addify-affiliate-program'))); ?>
							<input type="text" id="Addify_Af_Pr_affiliate_email" name="Addify_Af_Pr_affiliate_email" value="<?php echo esc_attr($affiliate_user->user_email); ?>" readonly />
						</td>
					</tr>

					<!-- Payout Amount -->
					<tr>
						<th><label for="Addify_Af_Pr_commission_amount"><strong><?php echo esc_html__('Payout Amount', 'addify-affiliate-program'); ?></strong></label></th>
						<td>
							<?php echo wp_kses_post(wc_help_tip(esc_html__('Payout amount of current affiliate.', 'addify-affiliate-program'))); ?>
							<input type="text" id="Addify_Af_Pr_commission_amount" name="Addify_Af_Pr_commission_amount" value="<?php echo esc_attr($commission_amount); ?>" readonly />
						</td>
					</tr>

					<!-- Custom Payout -->
					<tr>
						<th><label for="Addify_Af_Pr_custom_payout"><strong><?php echo esc_html__('Custom Payout', 'addify-affiliate-program'); ?></strong></label></th>
						<td>
							<?php echo wp_kses_post(wc_help_tip(esc_html__('Enable to enter custom payout amount if you do not wish to payout the full amount.', 'addify-affiliate-program'))); ?>
							<input type="checkbox" id="Addify_Af_Pr_custom_payout" class="Addify_Af_Pr_check" name="Addify_Af_Pr_custom_payout" value="yes" />
						</td>
					</tr>

					<!-- Custom Payout Amount -->
					<tr>
						<th><label for="Addify_Af_Pr_custom_payout_amount"><strong><?php echo esc_html__('Custom Payout Amount', 'addify-affiliate-program'); ?></strong></label></th>
						<td>
							<?php echo wp_kses_post(wc_help_tip(esc_html__('Enter custom payout amount for this payout transaction.', 'addify-affiliate-program'))); ?>
							<input type="number" id="Addify_Af_Pr_custom_payout_amount" name="Addify_Af_Pr_custom_payout_amount" min="0.01" step=".01" max="<?php echo esc_attr($commission_amount); ?>" />
						</td>
					</tr>

					<!-- Withdrawal Payment Method -->
					<tr>
						<th><label for="Addify_Af_Pr_withdrawal_payment_method"><strong><?php echo esc_html__('Payment Method', 'addify-affiliate-program'); ?></strong></label></th>
						<td>
							<?php echo wp_kses_post(wc_help_tip(esc_html__('Choose the payment method with which you want to payout the affiliate.', 'addify-affiliate-program'))); ?>
							<select class="Addify_Af_Pr_withdrawal_payment_method" id="Addify_Af_Pr_withdrawal_payment_method" name="Addify_Af_Pr_withdrawal_payment_method">
								<?php
								if (!empty($selected_payment_methods)) {
									foreach ($selected_payment_methods as $method) {
										$is_enabled = in_array($method->id, $enabled_gateways, true);
										$option_disabled = $is_enabled ? '' : 'disabled';
										echo '<option value="' . esc_attr($method->id) . '" ' . esc_attr($option_disabled) . '>' . esc_html($method->get_title()) . '</option>';
									}
								} else {
									echo '<option value="">' . esc_html__('No Payment Method', 'addify-affiliate-program') . '</option>';
								}
								?>
							</select>
						</td>
					</tr>

					<!-- Transaction ID -->
					<tr>
						<th><label for="Addify_Af_Pr_transaction_id"><strong><?php echo esc_html__('Transaction ID', 'addify-affiliate-program'); ?></strong></label></th>
						<td>
							<?php echo wp_kses_post(wc_help_tip(esc_html__('Enter the transaction id of payout transaction.', 'addify-affiliate-program'))); ?>
							<input type="text" id="Addify_Af_Pr_transaction_id" name="Addify_Af_Pr_transaction_id" required />
						</td>
					</tr>

				</table>
			</div>
		<?php
		}
		
		
		public function Addify_Af_Pr_save_meta_box_data( $post_id ) {


						$account_resp = wp_remote_get(
							'https://api.stripe.com/v1/accounts/' . $receiver_account_id,
							array(
								'headers' => array(
									'Authorization' => 'Bearer ' . $secret_key,
								),
								'timeout' => 60,
							)
						);


						$body = wp_remote_retrieve_body($account_resp);

						if (is_wp_error($account_resp)) {
							update_option('addify_Af_Pr_admin_side_error_messages', 'Stripe API error (account check): ' . $account_resp->get_error_message());
							return;
						}

						$account_data = json_decode(wp_remote_retrieve_body($account_resp), true);

						if (!empty($account_data['error'])) {
							update_option('addify_Af_Pr_admin_side_error_messages', 'Stripe account check failed: ' . $account_data['error']['message']);
							return;
						}

						$account_type = isset($account_data['type']) ? $account_data['type'] : 'standard';

						// ✅ Step 2: Only allow payouts for Express/Custom accounts
						if ('standard' == $account_type) {
							update_option('addify_Af_Pr_admin_side_error_messages', 'Affiliate is using a Standard Stripe account. Either payout manually for standard stripe account or use PayPal.');
							return;
						}

						// ✅ Step 3: Perform transfer (Express/Custom only)
						$response = wp_remote_post('https://api.stripe.com/v1/payouts', array(
							'method'  => 'POST',
							'headers' => array(
								'Authorization' => 'Bearer ' . $secret_key,
								'Stripe-Account' => 'acct_1Rbc7JFs0wSZoZou', // the connected account
								'Content-Type'  => 'application/x-www-form-urlencoded',
							),
							'body'    => array(
								'amount'      => (int) ( $paid_amount * 100 ), // cents
								'currency' => 'usd',
							),
						));


						if (is_wp_error($response)) {
							update_option('addify_Af_Pr_admin_side_error_messages', 'Stripe API error: ' . $response->get_error_message());
							return;
						}

						$response_body = wp_remote_retrieve_body($response);
						$data = json_decode($response_body, true);

						if (!empty($data['error'])) {
							update_option('addify_Af_Pr_admin_side_error_messages', $data['error']['message']);
							return;
						}

						if (!empty($data['id'])) {
							$transaction_id = sanitize_text_field($data['id']);
							update_post_meta($post_id, 'transaction_id', $transaction_id);
						} else {
							update_option('addify_Af_Pr_admin_side_error_messages', 'Stripe transfer response does not contain a transaction ID.');
							return;
						}
					} else if ('ppcp-gateway' == $withdrawal_payment_method) {
						$bearer_object = json_decode(get_option('_transient_ppcp-paypal-bearerppcp-bearer'));
						if (!$bearer_object || empty($bearer_object->access_token)) {
							update_option('addify_Af_Pr_admin_side_error_messages', 'PayPal bearer token missing or invalid');
							return;
						}
						$paypal_common_data = get_option('woocommerce-ppcp-data-common');
						if (!is_array($paypal_common_data) || empty($paypal_common_data['merchant_email']) || empty($paypal_common_data['client_id'])) {
							update_option('addify_Af_Pr_admin_side_error_messages', 'PayPal common data is missing or malformed');
							return;
						}
						$bearer_access_token = $bearer_object->access_token;
						$merchant_email = $paypal_common_data['merchant_email'];
						$client_id = $paypal_common_data['client_id'];
						$use_sandbox = $paypal_common_data['use_sandbox'];
						$receiver_email = get_user_meta($user_id, 'paypal_email', true);
						if (!is_email($receiver_email)) {
							update_option('addify_Af_Pr_admin_side_error_messages', 'Invalid affiliate email address for PayPal payout');
							return;
						}
						if ($use_sandbox) {
							$response = wp_remote_post('https://api.sandbox.paypal.com/v1/payments/payouts', array(
								'headers' => array(
									'Content-Type'  => 'application/json',
									'Authorization' => 'Bearer ' . $bearer_access_token,
								),
								'body' => json_encode(array(
									'sender_batch_header' => array(
										'sender_batch_id' => uniqid(),
										'email_subject' => 'You have a payout!',
									),
									'items' => array(
										array(
											'recipient_type' => 'EMAIL',
											'amount' => array(
												'value' => number_format($paid_amount, 2, '.', ''),
												'currency' => 'USD',
											),
											'receiver' => $receiver_email,
											'note' => 'Thanks for your work!',
											'sender_item_id' => $post_id,
										),
									),
								)),
							));
						} else {
							$response = wp_remote_post('https://api.paypal.com/v1/payments/payouts', array(
								'headers' => array(
									'Content-Type'  => 'application/json',
									'Authorization' => 'Bearer ' . $bearer_access_token,
								),
								'body' => json_encode(array(
									'sender_batch_header' => array(
										'sender_batch_id' => uniqid(),
										'email_subject' => 'You have a payout!',
									),
									'items' => array(
										array(
											'recipient_type' => 'EMAIL',
											'amount' => array(
												'value' => number_format($paid_amount, 2, '.', ''),
												'currency' => 'USD',
											),
											'receiver' => $receiver_email,
											'note' => 'Thanks for your work!',
											'sender_item_id' => $post_id,
										),
									),
								)),
							));
						}
						if (is_wp_error($response)) {
							update_option('addify_Af_Pr_admin_side_error_messages', $response->get_error_message());
							return;
						} else {
							$body = json_decode(wp_remote_retrieve_body($response), true);
							$transaction_id = $body['batch_header']['payout_batch_id'];
						}
					}
				}


				$affiliates = get_posts(array(
					'post_type'      => 'affiliate_user_post',
					'posts_per_page' => -1,
					'post_status'    => 'publish',
					'author'         => $user_id,
				));

				$paid_commission_check = false;
				foreach ($affiliates as $affiliate) {
					$paid_commission_check = get_post_meta($affiliate->ID, 'notify_paid_commission', true);

					$log = array(
						'transaction_id'       => $transaction_id,
						'method'               => isset($_POST['Addify_Af_Pr_withdrawal_payment_method'])
							? sanitize_text_field(wp_unslash($_POST['Addify_Af_Pr_withdrawal_payment_method']))
							: '',
						'custom_payout_check'  => $custom_payout,
						'payout_amount'        => $paid_amount,
						'timestamp'            => current_time('mysql'), // WP local time
					);

					$existing_logs = get_post_meta($affiliate->ID, 'payout_save_log', true);
					if (!is_array($existing_logs)) {
						$existing_logs = array();
					}

					$existing_logs[] = $log;

					$previous_paid = (float) get_post_meta($affiliate->ID, 'payout_save_paid_amount', true);
					$updated_paid = $previous_paid + $paid_amount;

					update_post_meta($affiliate->ID, 'payout_save_log', $existing_logs);
					update_post_meta($affiliate->ID, 'payout_save_paid_amount', $updated_paid);

					// --- Ensure correct timezone (with fallback for gmt_offset) ---
					$wp_timezone = get_option('timezone_string');
					if (!$wp_timezone) {
						$offset = (float) get_option('gmt_offset');
						$sign   = ( $offset <= 0 ) ? '+' : '-';
						$hours  = abs($offset);
						$wp_timezone = 'Etc/GMT' . $sign . $hours;
					}

					$tz = new DateTimeZone($wp_timezone);
					$now = new DateTime('now', $tz);
					$hour_key = $now->format('Y-m-d H:00'); // Local hour bucket

					$hourly_log = get_post_meta($affiliate->ID, 'hourly_stats', true);
					if (!is_array($hourly_log)) {
						$hourly_log = array();
					}

					if (!isset($hourly_log[ $hour_key ])) {
						$hourly_log[ $hour_key ] = array(
							'clicks'   => 0,
							'paid'     => 0,
							'unpaid'   => 0,
							'earnings' => 0,
							'refunds'  => 0,
						);
					}

					// Add to the paid field
					$hourly_log[ $hour_key ]['paid'] += $paid_amount;

					update_post_meta($affiliate->ID, 'hourly_stats', $hourly_log);
				}

				$remaining_unpaid = $commission_amount - $paid_amount;
				// Update post & user meta with remaining unpaid
				update_post_meta($post_id, 'unpaid_amount', $remaining_unpaid);
				update_user_meta($user_id, 'unpaid_amount', $remaining_unpaid);

				// Record this payout into payout_data (inside payout_post)
				$payout_data = get_post_meta($post_id, 'payout_data', true);
				if (!is_array($payout_data)) {
					$payout_data = array();
				}

				// Append a new payout entry
				$payout_data[] = array(
					'amount'  => (float) $paid_amount,
					'status'  => 'paid',
					'created' => current_time('mysql'), // saves local WP time
				);

				update_post_meta($post_id, 'payout_data', $payout_data);


				// ✅ Update payout_status based on remaining unpaid amount
				if ($remaining_unpaid <= 0) {
					update_post_meta($post_id, 'payout_status', 'paid');
				} else {
					update_post_meta($post_id, 'payout_status', 'unpaid');
				}

				if ('yes' == $paid_commission_check) {
					$new_form_data = array();
					$get_woo_currency = get_option('woocommerce_currency');
					$new_form_data = array(
						'affiliate_id'      => $user_id,
						'paid_amount'     => $get_woo_currency . ' ' . $paid_amount,
						'User_name'         => $username,
						'User_email'        => $user_email,
					);
					// Call your custom WooCommerce email notification
					$mailer = WC()->mailer();
					$email  = $mailer->emails['Addify_Ad_Pr_Affiliate_Paid_Commission_Email'];
					if ($email) {
						$email->trigger($new_form_data);
					}
				}
			}
			// affiliate user post save if
			if (isset($_POST['post_type']) && 'affiliate_user_post' === $_POST['post_type']) {
				if (!current_user_can('edit_post', $post_id)) {
					return;
				}
				$post = get_post($post_id);
				$user_id = $post->post_author;
				$admin_affiliate = false;
				if (!empty($_POST['Addify_Af_Pr_add_new_affiliate'][0])) {
					$new_user_id = (int) $_POST['Addify_Af_Pr_add_new_affiliate'][0];
					$user_id = $new_user_id;
					update_post_meta($post_id, 'post_author', $user_id);
					update_post_meta($post_id, 'user_ID', $user_id);
					update_user_meta($user_id, 'affiliate_request_submitted', true);
					$admin_affiliate = true;

					$args_posts = array(
						'post_type'      => 'registration_post',
						'orderby'        => 'menu_order',
						'order'          => 'DESC',
						'posts_per_page' => -1,
					);

					$query = new WP_Query($args_posts);
					$count = 0;
					if ($query->have_posts()) {
						while ($query->have_posts()) {

							$query->the_post();
							$reg_post_id = get_the_ID();
							$label  = get_post_meta($reg_post_id, 'Addify_Af_Pr_field_label', true);
							$type   = get_post_meta($reg_post_id, 'Addify_Af_Pr_field_type', true);
							$status = get_post_meta($reg_post_id, 'Addify_Af_Pr_field_status', true);

							if ('active' !== $status || empty($label)) {
								continue;
							}

							$field_id = 'reg_' . sanitize_title($type) . '_' . $count;
							$value = '';

							if ('checkbox' === $type) {
								// Checkbox: value is 1 if set, otherwise 0
								$value = isset($_POST[ $field_id ]) ? 1 : 0;

								$field_id_label = $field_id . '_label';

								update_user_meta($user_id, $field_id, sanitize_text_field($value));
								update_user_meta($user_id, $field_id_label, sanitize_text_field($label));
							} else {
								$field_id_label = $field_id . '_label';
								$value = isset($_POST[ $field_id ]) ? sanitize_text_field(wp_unslash($_POST[ $field_id ])) : '';
								update_user_meta($user_id, $field_id_label, sanitize_text_field($label));
							}

							update_user_meta($user_id, $field_id, $value);

							++$count;
						}
					}
				}



				if (isset($_POST['Addify_Af_Pr_affiliate_user_default_status'])) {
					$status_array = isset($_POST['Addify_Af_Pr_affiliate_user_default_status'][0]) ? sanitize_text_field(wp_unslash($_POST['Addify_Af_Pr_affiliate_user_default_status'][0])) : '';
					$status_value = is_array($status_array) ? reset($status_array) : $status_array;
					$status_value = sanitize_text_field(wp_unslash($status_value));
					$prev_post_status = get_post_meta($post_id, 'affiliate_user_status');
					update_post_meta($post_id, 'affiliate_user_status', $status_value);

					if ($user_id) {
						update_user_meta($user_id, 'affiliate_user_status', $status_value);

						$user = new WP_User($user_id);
						$userRoles = $user->roles;
						if ('approved' === $status_value) {
							if (!in_array('adf_affiliate', $userRoles, true)) {
								$user->add_role('adf_affiliate');
							}
						} elseif (in_array('adf_affiliate', $userRoles, true)) {
							$user->remove_role('adf_affiliate');
						}

						if ($prev_post_status[0] !== $status_value) {
							// ✅ Build form data for emails
							$new_form_data   = array();
							$get_woo_currency = get_option('woocommerce_currency');
							$new_form_data   = array(
								'affiliate_name'     => $user->display_name,
								'site_name'     => get_bloginfo('name'),
							);

							// ✅ Call WooCommerce email notifications
							$mailer = WC()->mailer();

							if ('approved' === $status_value) {
								$email = $mailer->emails['Addify_Ad_Pr_Affiliate_Registration_Approved_Email'];
								if ($email) {
									$email->trigger($new_form_data);
								}
							} elseif ('pending' === $status_value) {
								$email = $mailer->emails['Addify_Ad_Pr_Affiliate_Registration_Pending_Email'];
								if ($email) {
									$email->trigger($new_form_data);
								}
							} elseif ('rejected' === $status_value) {
								$email = $mailer->emails['Addify_Ad_Pr_Affiliate_Registration_Rejected_Email'];
								if ($email) {
									$email->trigger($new_form_data);
								}
							}
						}
					}
				}

				if (isset($_POST['Addify_Af_Pr_automatic_payment_method'])) {
					$status_value = sanitize_text_field(wp_unslash($_POST['Addify_Af_Pr_automatic_payment_method']));
					update_post_meta($post_id, 'affiliate_auto_payment_method', $status_value);

					if ($user_id) {
						update_user_meta($user_id, 'affiliate_auto_payment_method', $status_value);
					}
				}
				if (isset($_POST['Addify_Af_Pr_affiliate_commission_rate_type'])) {
					$status_array = isset($_POST['Addify_Af_Pr_affiliate_commission_rate_type'][0]) ? sanitize_text_field(wp_unslash($_POST['Addify_Af_Pr_affiliate_commission_rate_type'][0])) : '';

					update_post_meta($post_id, 'affiliate_commission_rate_type', $status_array);

					if ($user_id) {
						update_user_meta($user_id, 'affiliate_commission_rate_type', $status_array);
					}
				}



				$notify_checkboxes = array(
					'notify_new_commission',
					'notify_paid_commission',
				);

				foreach ($notify_checkboxes as $key) {
					$value = isset($_POST[ $key ]) ? 'yes' : 'no';
					update_post_meta($post_id, $key, $value);
					if ($user_id) {
						update_user_meta($user_id, $key, $value);
					}
				}
			}
		}


		
	}

	new Addify_Affiliate_Program_Meta_Box();
endif;
