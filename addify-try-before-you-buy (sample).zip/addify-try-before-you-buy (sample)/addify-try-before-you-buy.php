<?php



if (!class_exists('Addify_TBYB')) {
	class Addify_TBYB {
	





		public function Addify_Try_Before_You_Buy_Constents_Vars() {
			if (!defined('AD_TBYB_URL')) {
				define('AD_TBYB_URL', plugin_dir_url(__FILE__));
			}
			if (!defined('AD_TBYB_DIR')) {
				define('AD_TBYB_DIR', plugin_dir_path(__FILE__));
			}
			if (!defined('AD_TBYB_NAME')) {
				define('AD_TBYB_NAME', plugin_basename(__DIR__));
			}
		}
		public function Addify_try_before_buy_update_options() {
			update_option('Addify_TBYB_trial_start_confirmation', 'yes');
			update_option('Addify_TBYB_trial_extension_approval_rejection', 'yes');
			update_option('Addify_TBYB_send_trial_expiry_email_alerts', 'yes');
			update_option('Addify_TBYB_send_email_alerts_expired', 'yes');
		}
		public function Addify_Try_Before_You_Buy_before_woocommerce() {
			if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
				\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
			}
		}
		public function try_before_you_buy_custom_cron_job() {
			if (!wp_next_scheduled('try_before_you_buy_cron')) {
				wp_schedule_event(time(), 'try_before_buy_once_every_hour', 'try_before_you_buy_cron');
			}
			// Register new order status
			register_post_status('wc-trial-period', array(
				'label'                     => _x('Trial Period', 'Order status', 'addify-try-before-you-buy'),
				'public'                    => true,
				'exclude_from_search'       => false,
				'show_in_admin_all_list'    => true,
				'show_in_admin_status_list' => true,
				// translators: %s: number of orders with Trial Period status.
				'label_count' => _n_noop(
					'Trial Period <span class="count">(%s)</span>',
					'Trial Period <span class="count">(%s)</span>',
					'addify-try-before-you-buy'
				),
			));
		}

		// Add to WC order statuses list
		public function addify_add_trial_to_order_statuses( $order_statuses ) {
			$new_statuses = array();
			foreach ($order_statuses as $key => $status) {
				$new_statuses[ $key ] = $status;
				// Insert trial status after 'processing'
				if ('wc-processing' === $key) {
					$new_statuses['wc-trial-period'] = _x('Trial Period', 'Order status', 'addify-try-before-you-buy');
				}
			}
			return $new_statuses;
		}
		// Add action buttons in admin orders list
		public function addify_trial_status_bulk_actions( $actions ) {
			$actions['mark_trial-period'] = __('Change status to Trial Period', 'addify-try-before-you-buy');
			return $actions;
		}
		public function addify_remove_trial_status() {
			// Remove filters and actions that added the status
			remove_action('init', 'try_before_you_buy_custom_cron_job');
			remove_filter('wc_order_statuses', 'addify_add_trial_to_order_statuses');
			remove_filter('bulk_actions-edit-shop_order', 'addify_trial_status_bulk_actions');
		}
		public function try_before_you_buy_check_interval( $schedules ) {
			$schedules['try_before_buy_once_every_hour'] = array(
				'interval' => 3600,
				'display' => esc_html__('Once Every Hour', 'addify-try-before-you-buy'),
			);

			return $schedules;
		}
		public function run_try_before_you_buy_cron() {
			$today = current_time('Y-m-d');

			$args_posts = array(
				'post_type'      => 'trial_rule_tab',
				'orderby'        => 'menu_order',
				'order'          => 'DESC',
				'posts_per_page' => -1,
			);
			$query = new WP_Query($args_posts);

			if (!$query->have_posts()) {
				return;
			}


			// Track processed orders to avoid duplicate processing
			$processed_orders = array();

			while ($query->have_posts()) {
				$query->the_post();
				$rule_post_id = get_the_ID();

				if (!get_post_meta($rule_post_id, 'Addify_TBYB_enablerule', true)) {
					continue;
				}

				$args_posts_log = array(
					'post_type'      => 'trial_log_tab',
					'orderby'        => 'menu_order',
					'order'          => 'DESC',
					'posts_per_page' => -1,
				);
				$query_log = new WP_Query($args_posts_log);

				if (!$query_log->have_posts()) {
					continue;
				}


				while ($query_log->have_posts()) {
					$query_log->the_post();
					$log_post_id = get_the_ID();

					$order_id = get_post_meta($log_post_id, 'addify_TBYB_order_id', true);

					// Skip if order already processed or invalid
					if (empty($order_id) || in_array($order_id, $processed_orders)) {
						continue;
					}

					$order = wc_get_order($order_id);
					if (!$order || !$order->get_id()) {
						continue;
					}

					$trial_products = $order->get_meta('addify_TBYB_trial_products');
					if (empty($trial_products) || !is_array($trial_products)) {
						continue;
					}

					// Extract products for this specific order - fix the array structure
					$order_products = array();
					if (isset($trial_products) && is_array($trial_products)) {
						$order_products = $trial_products;
					} else {
						// Alternative: check if it's a sequential array
						foreach ($trial_products as $key => $products) {
							if (is_array($products) && isset($products[0]['order_id']) && $products[0]['order_id'] == $order_id) {
								$order_products = $products;
								break;
							}
						}
					}

					if (empty($order_products)) {
						continue;
					}


					$product_names = array();
					$updated = false;
					$expiry_email_sent = false;
					$expired_email_sent = false;
					$should_capture = false;
					$base_capture_amount = 0;
					$has_kept = false;
					$apply_late_fee = false;
					$charge_type = '';
					$charge_amount = 0;

					// Make a copy of the products array to modify
					$modified_products = $order_products;
					$already_captured_products = array();

					// Get original authorized amount
					$authorized_amount = $order->get_total();
					$order_total_meta = $order->get_meta('addify_TBYB_total_price');
					if (!empty($order_total_meta) && is_numeric($order_total_meta)) {
						$authorized_amount = max($authorized_amount, floatval($order_total_meta));
					}


					foreach ($modified_products as $key => &$product) {
						$product_id_key = $product['product_id'] . '_' . $key;

						if (in_array($product_id_key, $already_captured_products)) {
							continue;
						}

						if (isset($product['reminder_sent']) && 1 == $product['reminder_sent']) {
							continue;
						}

						// FIXED: Check if trial has ended (changed from <= to >=)
						if (!empty($product['end'])) {
							$trial_end_date = $product['end'];

							$trial_was_extended = isset($product['trial_extension_period_check']) && 'set_once' === $product['trial_extension_period_check'];

							// Get product name for email
							if (!empty($product['product_id'])) {
								$product_obj = wc_get_product($product['product_id']);
								if ($product_obj) {
									$product_names[] = $product_obj->get_name();
								}
							}

							$user_id = $order->get_user_id();
							$user_info = get_userdata($user_id);
							$user_email = $user_info ? $user_info->user_email : '';
							$user_name = $user_info ? $user_info->display_name : '';

							// Check for expiry reminder (only for active trials)
							if ('yes' === get_option('Addify_TBYB_send_trial_expiry_email_alerts', 'no')) {
								$days_before_expiry = 1;
								$notify_date = gmdate('Y-m-d', strtotime($trial_end_date . " -$days_before_expiry days"));

								if ($today === $notify_date && empty($product['reminder_sent']) && !$expiry_email_sent) {
									// Calculate time remaining
									$time_diff = strtotime($trial_end_date) - time();
									$days_remaining = max(0, floor($time_diff / DAY_IN_SECONDS));
									$time_remaining = sprintf(
										// translators: %s: Number of days remaining in the trial period.
										_n('%s day', '%s days', $days_remaining, 'addify-try-before-you-buy'),
										$days_remaining
									);

									$order_total = $order->get_meta('addify_TBYB_total_price');
									$total = isset($order_total) ? $order_total : 0;

									// Build email data
									$new_form_data = array(
										'customer_email' => $user_email,
										'customer_name'  => $user_name,
										'order_id'       => $order->get_id(),
										'products'       => json_encode($order_products),
										'ends'           => $trial_end_date,
										'time_remaining' => $time_remaining,
										'deposit'        => wc_price($order->get_total()),
										'full_price'     => wc_price($total),
									);

									// Send expiry reminder email
									$mailer = WC()->mailer();
									$email = $mailer->emails['WC_TBYB_Trial_Expiry_Email'];
									if ($email) {
										$email->trigger($new_form_data);
									}

									$expiry_email_sent = true;
									$product['reminder_sent'] = true;
									$updated = true;
								}
							}

							// Check for expiration - FIXED LOGIC
							$Addify_TBYB_allow_return_extension_window = get_option('Addify_TBYB_allow_return_extension_window', 'no');
							$Addify_TBYB_return_extension_window = get_option('Addify_TBYB_return_extension_window', 1);
							$Addify_TBYB_send_email_alerts_expired = get_option('Addify_TBYB_send_email_alerts_expired', 'no');

							$grace_expiry = $trial_end_date;
							if ('yes' === $Addify_TBYB_allow_return_extension_window && !$trial_was_extended) {
								$grace_expiry = gmdate('Y-m-d', strtotime($trial_end_date . " +$Addify_TBYB_return_extension_window days"));
							}


							// FIXED: Changed condition to check if trial has ended
							if ($today >= $grace_expiry) {

								if ('yes' === $Addify_TBYB_send_email_alerts_expired && !$expired_email_sent) {
									$new_form_data = array(
										'customer_email' => $user_email,
										'customer_name'  => $user_name,
										'order_id'       => $order->get_id(),
									);
									$mailer = WC()->mailer();
									$email = $mailer->emails['WC_TBYB_Trial_Expired_Email'];
									if ($email) {
										$email->trigger($new_form_data);
									}
									$expired_email_sent = true;
								}

								$product['keep'] = 'yes';

								// Only add to capture if not already processed
								if (!in_array($product_id_key, $already_captured_products)) {
									$base_capture_amount += floatval($product['price']);
									$already_captured_products[] = $product_id_key;
								}

								$updated = true;
								$should_capture = true;
								$has_kept = true;

								// Check for late fee
								if (!$apply_late_fee && !empty($product['enable_late_fee']) && 'yes' === $product['enable_late_fee']) {
									$apply_late_fee = true;
									$charge_type = isset($product['charge_type']) ? $product['charge_type'] : '';
									$charge_amount = floatval(isset($product['charge_amount']) ? $product['charge_amount'] : 0);
								}
							}
						}
					}

					// Calculate late fee separately
					$late_fee_amount = 0;
					$total_capture_amount = $base_capture_amount;

					if ($apply_late_fee && $charge_amount > 0) {
						if ('fixed' === $charge_type) {
							$late_fee_amount = $charge_amount;
						} elseif ('percentage' === $charge_type) {
							$late_fee_amount = ( $base_capture_amount * $charge_amount ) / 100;
						}

						// Ensure late fee doesn't push total over authorization
						$total_with_fee = $base_capture_amount + $late_fee_amount;
						if ($total_with_fee > $authorized_amount) {
							$late_fee_amount = max(0, $authorized_amount - $base_capture_amount);
						}

						$total_capture_amount += $late_fee_amount;
					}

					// Final validation to ensure we don't exceed authorized amount
					if ($total_capture_amount > $authorized_amount) {
						$total_capture_amount = $authorized_amount;
					}


					// Update order meta if any changes were made
					if ($updated) {
						$trial_products = $modified_products;
						$order->update_meta_data('addify_TBYB_trial_products', $trial_products);
						$order->save();
					}

					// Process payment capture if needed
					if ($should_capture && $total_capture_amount > 0) {

						$payment_method = $order->get_meta('addify_TBYB_trial_products_order_payment_method');

						if ('stripe' == $payment_method) {
							$this->capture_stripe_payment($order, $total_capture_amount, $authorized_amount);
						} elseif ('ppcp-gateway' == $payment_method) {
							$this->capture_paypal_payment($order, $total_capture_amount, $authorized_amount);
						} else {
							$order->add_order_note('Try Before You Buy: Unsupported payment method for capture: ' . $payment_method);
						}
					}

					// Mark this order as processed to avoid duplicate handling
					$processed_orders[] = $order_id;
				}
			}

			wp_reset_postdata();
		}

		private function capture_stripe_payment( $order, $total_capture_amount, $authorized_amount ) {
			// Check if payment was already captured
			$already_captured = $order->get_meta('addify_TBYB_payment_captured');
			if ('yes' == $already_captured) {
				return;
			}

			// Check if we've attempted capture before and failed
			$previous_capture_attempt = $order->get_meta('addify_TBYB_capture_attempted');
			if ('yes' == $previous_capture_attempt) {
				return;
			}

			$stripe_data = get_option('woocommerce_stripe_settings');
			$test_mode = isset($stripe_data['testmode']) && 'yes' === $stripe_data['testmode'];
			$stripe_secret = $test_mode ? $stripe_data['test_secret_key'] : $stripe_data['secret_key'];
			$payment_intent_id = $order->get_meta('addify_TBYB_stripe_payment_intent');

			if (empty($payment_intent_id)) {
				$order->add_order_note('Stripe capture failed: Payment Intent ID is missing.');
				$order->update_meta_data('addify_TBYB_capture_attempted', 'yes');
				$order->save_meta_data();
				return;
			}

			$amount_cents = intval(round($total_capture_amount * 100));

			// First, check the payment intent status
			$payment_intent_details = wp_remote_get("https://api.stripe.com/v1/payment_intents/$payment_intent_id", array(
				'headers' => array( 'Authorization' => 'Bearer ' . $stripe_secret ),
			));

			$intent_data = json_decode(wp_remote_retrieve_body($payment_intent_details), true);

			if (isset($intent_data['error'])) {
				$order->add_order_note('Stripe capture failed: ' . $intent_data['error']['message']);
				$order->update_meta_data('addify_TBYB_capture_attempted', 'yes');
				$order->save_meta_data();
				return;
			}

			// Check if payment is already captured or cannot be captured
			if (isset($intent_data['status'])) {
				$status = $intent_data['status'];

				// If already captured, mark it and return
				if ('succeeded' == $status) {
					$order->update_meta_data('addify_TBYB_payment_captured', 'yes');
					$order->save_meta_data();
					return;
				}

				// If canceled or cannot be captured
				if ('canceled' == $status || 'requires_payment_method' == $status) {
					$order->update_meta_data('addify_TBYB_capture_attempted', 'yes');
					$order->add_order_note('Stripe payment cannot be captured - status: ' . $status);
					$order->save_meta_data();
					return;
				}

				// Check available amount to capture
				if (isset($intent_data['amount_capturable'])) {
					$max_capturable = $intent_data['amount_capturable'] / 100;

					// If nothing left to capture, mark as captured
					if ($max_capturable <= 0) {
						$order->update_meta_data('addify_TBYB_payment_captured', 'yes');
						$order->add_order_note('Stripe payment has no remaining capturable amount.');
						$order->save_meta_data();
						return;
					}

					if ($total_capture_amount > $max_capturable) {
						$total_capture_amount = $max_capturable;
						$amount_cents = intval(round($total_capture_amount * 100));
					}
				}
			}

			// Mark that we're attempting capture
			$order->update_meta_data('addify_TBYB_capture_attempted', 'yes');
			$order->save_meta_data();

			$capture_response = wp_remote_post("https://api.stripe.com/v1/payment_intents/$payment_intent_id/capture", array(
				'method'  => 'POST',
				'headers' => array( 'Authorization' => 'Bearer ' . $stripe_secret ),
				'body'    => array( 'amount_to_capture' => $amount_cents ),
			));

			$capture_data = json_decode(wp_remote_retrieve_body($capture_response), true);
			if (isset($capture_data['id']) &&  'succeeded' == $capture_data['status']) {
				// Mark as successfully captured
				$order->update_meta_data('addify_TBYB_payment_captured', 'yes');
				$order->update_meta_data('addify_TBYB_payment_auto_captured', 'yes');
				$order->update_meta_data('addify_TBYB_total_capture_charge', $total_capture_amount);
				$order->add_order_note('Stripe payment automatically captured: ' . $capture_data['id'] . ' Amount: ' . wc_price($total_capture_amount));

				// Only complete payment if we captured the full amount
				if ($total_capture_amount >= $authorized_amount) {
					$order->payment_complete($capture_data['id']);
					$order->update_status('completed', 'Payment captured Automatically.');
				}
				$order->save_meta_data();
			} elseif (isset($capture_data['error'])) {
				$error_message = $capture_data['error']['message'];
				$order->add_order_note('Stripe capture failed: ' . $error_message);

				// If the error indicates the payment is already captured or expired, mark it as such
				if (
					strpos($error_message, 'already been captured') !== false ||
					strpos($error_message, 'authorized amount has been released') !== false ||
					strpos($error_message, 'expired') !== false
				) {
					$order->update_meta_data('addify_TBYB_payment_captured', 'yes');
					$order->save_meta_data();
				}
			}
		}
		private function capture_paypal_payment( $order, $total_capture_amount, $authorized_amount ) {
			// Check if payment was already captured
			$already_captured = $order->get_meta('addify_TBYB_payment_captured');
			if ('yes' == $already_captured) {
				return;
			}

			// Check if we've attempted capture before
			$previous_capture_attempt = $order->get_meta('addify_TBYB_capture_attempted');
			if ('yes' == $previous_capture_attempt) {
				return;
			}

			$bearer_object = json_decode(get_option('_transient_ppcp-paypal-bearerppcp-bearer'));
			if (!$bearer_object || empty($bearer_object->access_token)) {
				$order->add_order_note('PayPal capture failed: Unable to retrieve PayPal token.');
				$order->update_meta_data('addify_TBYB_capture_attempted', 'yes');
				$order->save_meta_data();
				return;
			}

			$bearer_access_token = $bearer_object->access_token;
			$authorization_id = $order->get_meta('addify_TBYB_paypal_authorization_id');
			$paypal_common_data = get_option('woocommerce-ppcp-data-common');
			$use_sandbox = $paypal_common_data['use_sandbox'];
			$paypal_api_url = $use_sandbox ? 'https://api-m.sandbox.paypal.com' : 'https://api-m.paypal.com';

			if ($authorization_id) {
				// Mark that we're attempting capture
				$order->update_meta_data('addify_TBYB_capture_attempted', 'yes');
				$order->save_meta_data();

				$capture_response = wp_remote_post("$paypal_api_url/v2/payments/authorizations/{$authorization_id}/capture", array(
					'headers' => array(
						'Authorization' => "Bearer {$bearer_access_token}",
						'Content-Type'  => 'application/json',
					),
					'body' => json_encode(array(
						'amount' => array(
							'currency_code' => $order->get_currency(),
							'value'         => number_format($total_capture_amount, 2, '.', ''),
						),
						'final_capture' => true,
					)),
				));

				$capture_body = json_decode(wp_remote_retrieve_body($capture_response), true);
				if (!empty($capture_body['status']) && 'COMPLETED' === $capture_body['status']) {
					// Mark as successfully captured
					$order->update_meta_data('addify_TBYB_payment_auto_captured', 'yes');
					$order->update_meta_data('addify_TBYB_payment_captured', 'yes');
					$order->update_meta_data('addify_TBYB_total_capture_charge', $total_capture_amount);
					$order->save_meta_data();

					// Only complete payment if we captured the full amount
					if ($total_capture_amount >= $authorized_amount) {
						$order->payment_complete();
						$order->update_status('completed', 'Payment captured Automatically.');
					}

					$order->add_order_note('PayPal: Payment successfully captured automatically. Amount: ' . wc_price($total_capture_amount));
				} else {
					$error_message = !empty($capture_body['message']) ? $capture_body['message'] : 'Unknown error';
					$order->add_order_note('PayPal: Capture failed — ' . $error_message);

					// If authorization expired or already captured, mark it
					if (
						strpos($error_message, 'expired') !== false ||
						strpos($error_message, 'already captured') !== false ||
						strpos($error_message, 'not found') !== false
					) {
						$order->update_meta_data('addify_TBYB_payment_captured', 'yes');
						$order->save_meta_data();
					}
				}
			} else {
				$order->add_order_note('PayPal capture failed: Authorization ID is missing.');
				$order->update_meta_data('addify_TBYB_capture_attempted', 'yes');
				$order->save_meta_data();
			}
		}
	}

	new Addify_TBYB();
}
