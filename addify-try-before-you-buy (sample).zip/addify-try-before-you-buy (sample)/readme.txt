=== Addify Try Before You Buy ===
Contributors: Addify
Requires at least: 6.5
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GNU General Public License v3.0
URI: http://www.gnu.org/licenses/gpl-3.0.html