<?php

use OTGS\Installer\Api\SiteUrl;

use function WooCommerce\PayPalCommerce\OrderTracking\tr;

if (!defined('ABSPATH')) {
	exit();
}

if (!class_exists('Addify_TBYB_Meta_Box')) :
	class Addify_TBYB_Meta_Box {
	



















		public function __construct() {
			$this->Addify_TBYB_meta_box_fun();
		}

		
		public function addify_display_admin_notice() {
			if (!empty($_SESSION['addify_admin_notice'])) {
				$message = esc_html(sanitize_text_field($_SESSION['addify_admin_notice']));

				echo '<div class="notice notice-success is-dismissible">';
				echo '<p>' . wp_kses_post($message) . '</p>';
				echo '</div>';

				unset($_SESSION['addify_admin_notice']);
			}
		}
		public function addify_save_message_admin() {
			check_ajax_referer('save_message_admin_nonce', 'security');

			$message = isset($_POST['message']) ? sanitize_text_field(wp_unslash($_POST['message'])) : '';

			if (!empty($message)) {
				$_SESSION['addify_admin_notice'] = $message;
				wp_send_json_success();
			}

			wp_send_json_error('Message empty.');
		}

		public function delete_data_on_trial_post_delete( $post_id ) {
			$post_type = get_post_type($post_id);

			// Only proceed for trial log tab posts
			if ('trial_log_tab' === $post_type) {
				$user_id = get_post_field('post_author', $post_id);
				$order_id = get_post_meta($post_id, 'addify_TBYB_order_id', true);

				if (!empty($order_id)) {
					$option_key = 'addify_TBYB_trial_products_' . $user_id;
					$option_data = get_option($option_key);

					if (is_array($option_data) && isset($option_data[ $order_id ])) {
						unset($option_data[ $order_id ]);
						update_option($option_key, $option_data);
					}
				}
			}

			// If it's a rule post, clean its metadata too
			if ('trial_rule_tab' === $post_type) {
				$post_meta = get_post_meta($post_id);
				foreach ($post_meta as $meta_key => $value) {
					delete_post_meta($post_id, $meta_key);
				}
			}
		}
		public function delete_trial_log_when_order_deleted( $order_id, $order ) {
			$all_trial_posts = get_posts(array(
				'post_type'      => 'trial_log_tab',
				'numberposts'    => -1,
				'fields'         => 'ids',
				'suppress_filters' => false,
			));

			foreach ($all_trial_posts as $post_id) {
				$trial_order_id = get_post_meta($post_id, 'addify_TBYB_order_id', true);

				if ((int) $trial_order_id === (int) $order_id) {
					wp_delete_post($post_id, true);
				}
			}

			$user_id = $order->get_user_id();
			$option_key = 'addify_TBYB_trial_products_' . $user_id;
			$option_data = get_option($option_key);

			if (!empty($option_data) && isset($option_data[ $order_id ])) {
				unset($option_data[ $order_id ]);
				update_option($option_key, $option_data);
			}
		}
		public function Addify_TBYB_approve_trial_period_handler() {
			$this->handle_trial_period_action('approve_trial_reason', 'Addify_TBYB_approve_trial_period', 'Approved', 'WC_TBYB_Trial_Return_Approved_Email');
		}

		public function Addify_TBYB_reject_trial_period_handler() {
			$this->handle_trial_period_action('reject_trial_reason', 'Addify_TBYB_reject_trial_period', 'Rejected', 'WC_TBYB_Trial_Return_Rejected_Email');
		}

		// Common handler for both approve and reject actions
		private function handle_trial_period_action( $expected_action_type, $nonce_action, $status, $email_class ) {
			check_ajax_referer($nonce_action, 'security');

			$action_type = isset($_POST['action_type']) ? sanitize_text_field(wp_unslash($_POST['action_type'])) : '';
			if ($expected_action_type !== $action_type) {
				wp_send_json_error('Invalid action type.');
			}

			$order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
			$product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
			$variation_id = isset($_POST['variation_id']) ? intval($_POST['variation_id']) : 0;
			$attributes = array();
			if (isset($_POST['attributes']) && is_array($_POST['attributes'])) {
				$raw_attributes = sanitize_meta('', wp_unslash($_POST['attributes']), '');
				if (!is_array($raw_attributes)) {
					$raw_attributes = array();
				}
				foreach ($raw_attributes as $key => $value) {
					$attributes[ sanitize_key($key) ] = sanitize_text_field($value);
				}
			}
			$reject_reason_text = array();
			if (isset($_POST['reject_reason_text']) && is_array($_POST['reject_reason_text'])) {
				$raw_reject_reason_text = sanitize_meta('', wp_unslash($_POST['reject_reason_text']), '');
				if (!is_array($raw_reject_reason_text)) {
					$raw_reject_reason_text = array();
				}
				foreach ($raw_reject_reason_text as $key => $value) {
					$reject_reason_text[ sanitize_key($key) ] = sanitize_text_field($value);
				}
			}
			$order = wc_get_order($order_id);
			if (!$order) {
				wp_send_json_error('Order not found.');
			}

			$user = get_user_by('id', $order->get_user_id());
			$email = $user ? $user->user_email : '';
			$customer_name = $user ? $user->display_name : '';

			if (!$product_id) {
				wp_send_json_error('Product ID not found.');
			}

			$trial_products = $order->get_meta('addify_TBYB_trial_products');
			if (empty($trial_products)) {
				wp_send_json_error('Trial products not found.');
			}

			// Process trial products and calculate amounts
			$processing_result = $this->process_trial_products(
				$trial_products,
				$product_id,
				$variation_id,
				$attributes,
				$status,
				$email_class,
				$reject_reason_text,
				$order,
				$email,
				$customer_name
			);

			// Update order meta with processed products
			$order->update_meta_data('addify_TBYB_trial_products', $trial_products);

			// Handle payment processing if all products reviewed
			if ($processing_result['all_reviewed']) {
				$this->process_payment_capture($order, $processing_result['capture_amount'], $email, $customer_name, $trial_products);

				wp_send_json_success(array(
					'message' => 'Trial completed. Payment processed.',
					'amount' => $processing_result['capture_amount'],
					'all_processed' => true,
				));
			}

			$order->save();

			wp_send_json_success(array(
				'message' => 'Trial status updated.',
				'amount' => $processing_result['capture_amount'],
				'reject_reason_text' => $reject_reason_text,
				'all_processed' => $processing_result['all_reviewed'],
			));
		}


		// Process trial products and calculate capture amounts
		private function process_trial_products( &$products, $product_id, $variation_id, $attributes, $status, $email_class, $reject_reason_text, $order, $email, $customer_name ) {
			$all_reviewed = true;
			$capture_amount = 0;
			$apply_late_fee = false;
			$charge_type = '';
			$charge_amount = 0;

			foreach ($products as &$product) {
				if (!is_array($product)) {
					continue;
				}

				// Mark kept if already selected
				if (!isset($product['return_status']) && isset($product['keep']) && 'yes' === $product['keep']) {
					$product['return_status'] = 'Kept';
				}

				// Check if this is the target product
				if ($this->is_target_product($product, $product_id, $variation_id, $attributes)) {
					$product['return_status'] = $status;
					$product['reject_reason_text'] = $reject_reason_text;

					// Send status-specific email
					$this->send_trial_status_email($email_class, $email, $customer_name, $order->get_id(), array( $product ));
				}

				// Check review status and calculate amounts
				$return_status = isset($product['return_status']) ? $product['return_status'] : '';
				if (!in_array($return_status, array( 'Approved', 'Rejected', 'Kept' ), true)) {
					$all_reviewed = false;
				}

				$price = floatval(isset($product['price']) ? $product['price'] : 0);
				if (in_array($return_status, array( 'Rejected', 'Kept' ), true)) {
					$capture_amount += $price;

					// Check for late fee (only once)
					if (!$apply_late_fee && !empty($product['enable_late_fee']) && 'yes' === $product['enable_late_fee']) {
						$apply_late_fee = true;
						$charge_type = isset($product['charge_type']) ? $product['charge_type'] : '';
						$charge_amount = floatval(isset($product['charge_amount']) ? $product['charge_amount'] : 0);
					}
				}
			}

			// Apply late fee if applicable
			if ($apply_late_fee && $charge_amount > 0) {
				if ('fixed' === $charge_type) {
					$capture_amount += $charge_amount;
				} elseif ('percentage' === $charge_type) {
					$capture_amount += ( $capture_amount * $charge_amount ) / 100;
				}
			}

			return array(
				'all_reviewed' => $all_reviewed,
				'capture_amount' => $capture_amount,
			);
		}

		// Check if product matches the target criteria
		private function is_target_product( $product, $product_id, $variation_id, $attributes ) {
			$meta_product_id = intval(isset($product['product_id']) ? $product['product_id'] : 0);
			$meta_variation_id = intval(isset($product['variation_id']) ? $product['variation_id'] : 0);
			$trial_variable_data = isset($product['product_variation_data']) ? $product['product_variation_data'] : array();

			// Check variation match first, then product match
			if (( $variation_id && $meta_variation_id === $variation_id ) ||
				( !$variation_id && $meta_product_id === $product_id )
			) {

				// Check attributes if they exist
				if (!empty($trial_variable_data)) {
					return $attributes === $trial_variable_data;
				}
				return true;
			}

			return false;
		}

		// Send trial status email
		private function send_trial_status_email( $email_class, $email, $customer_name, $order_id, $products ) {
			$form_data = array(
				'customer_email' => $email,
				'customer_name' => $customer_name,
				'order_id' => $order_id,
				'products' => json_encode($products),
			);

			$mailer = WC()->mailer();
			$email_handler = isset($mailer->emails[ $email_class ]) ? $mailer->emails[ $email_class ] : null;

			if ($email_handler) {
				$email_handler->trigger($form_data);
			}
		}

		// Process payment capture for completed trials
		private function process_payment_capture( $order, $capture_amount, $email, $customer_name, $trial_products ) {
			$payment_method = $order->get_meta('addify_TBYB_trial_products_order_payment_method');

			if ('stripe' === $payment_method) {
				$this->process_stripe_capture($order, $capture_amount);
			} elseif ('ppcp-gateway' === $payment_method) {
				$this->process_paypal_capture($order, $capture_amount);
			}

			// Send completion emails
			$this->send_completion_emails($email, $customer_name, $order->get_id(), $trial_products);

			// Save order changes
			$order->update_meta_data('addify_TBYB_total_capture_charge', $capture_amount);
			$order->save();
		}

		// Process Stripe payment capture
		private function process_stripe_capture( $order, $capture_amount ) {
			$stripe_data = get_option('woocommerce_stripe_settings');
			$test_mode = isset($stripe_data['testmode']) && 'yes' === $stripe_data['testmode'];
			$stripe_secret = $test_mode ? $stripe_data['test_secret_key'] : $stripe_data['secret_key'];
			$payment_intent_id = $order->get_meta('addify_TBYB_stripe_payment_intent');

			if ($capture_amount >= 1) {
				if (empty($payment_intent_id)) {
					$order->add_order_note('Stripe capture failed: Payment Intent ID is missing.');
					wp_send_json_error(array( 'message' => 'Capture failed: Missing payment intent ID.' ));
				}

				$amount_cents = intval(round($capture_amount * 100));
				$capture_response = wp_remote_post("https://api.stripe.com/v1/payment_intents/$payment_intent_id/capture", array(
					'method' => 'POST',
					'headers' => array( 'Authorization' => 'Bearer ' . $stripe_secret ),
					'body' => array( 'amount_to_capture' => $amount_cents ),
				));

				$capture_data = json_decode(wp_remote_retrieve_body($capture_response), true);

				if (!empty($capture_data['id'])) {
					$order->payment_complete($capture_data['id']);
					$order->add_order_note('Stripe payment manually captured: ' . $capture_data['id']);
					$order->update_status('completed', 'Payment captured for kept/rejected products.');
				} else {
					$order->add_order_note('Stripe capture failed: ' . ( isset($capture_data['error']['message']) ? $capture_data['error']['message'] : 'Unknown error' ));
					wp_send_json_error(array( 'message' => 'Stripe capture failed.' ));
				}
			} else {
				// Cancel authorization if nothing to charge
				wp_remote_post("https://api.stripe.com/v1/payment_intents/{$payment_intent_id}/cancel", array(
					'method' => 'POST',
					'headers' => array( 'Authorization' => 'Bearer ' . $stripe_secret ),
				));
				$order->update_status('cancelled', 'Stripe authorization cancelled.');
			}
		}

		// Process PayPal payment capture
		private function process_paypal_capture( $order, $capture_amount ) {
			$bearer_object = json_decode(get_option('_transient_ppcp-paypal-bearerppcp-bearer'));
			$paypal_common_data = get_option('woocommerce-ppcp-data-common');
			$use_sandbox = !empty($paypal_common_data['use_sandbox']);
			$paypal_api_url = $use_sandbox ? 'https://api-m.sandbox.paypal.com' : 'https://api-m.paypal.com';
			$authorization_id = $order->get_meta('addify_TBYB_paypal_authorization_id');

			if ($capture_amount >= 1 && $authorization_id) {
				$capture_response = wp_remote_post("$paypal_api_url/v2/payments/authorizations/{$authorization_id}/capture", array(
					'headers' => array(
						'Authorization' => "Bearer {$bearer_object->access_token}",
						'Content-Type' => 'application/json',
					),
					'body' => json_encode(array(
						'amount' => array(
							'currency_code' => $order->get_currency(),
							'value' => number_format($capture_amount, 2, '.', ''),
						),
						'final_capture' => true,
					)),
				));

				$capture_body = json_decode(wp_remote_retrieve_body($capture_response), true);

				if (!empty($capture_body['status']) && 'COMPLETED' === $capture_body['status']) {
					$order->payment_complete();
					$order->add_order_note('PayPal: Payment successfully captured.');
					$order->update_status('completed', 'PayPal capture completed.');
				} else {
					$order->update_status('failed', 'PayPal capture failed.');
					wp_send_json_error(array( 'message' => 'PayPal capture failed.' ));
				}
			} else {
				// Void authorization if nothing to capture
				wp_remote_post("{$paypal_api_url}/v2/payments/authorizations/{$authorization_id}/void", array(
					'headers' => array(
						'Authorization' => "Bearer {$bearer_object->access_token}",
						'Content-Type' => 'application/json',
					),
				));
				$order->update_status('cancelled', 'PayPal authorization voided.');
			}
		}

		// Send completion emails
		private function send_completion_emails( $email, $customer_name, $order_id, $trial_products ) {
			$form_data = array(
				'customer_email' => $email,
				'customer_name' => $customer_name,
				'order_id' => $order_id,
				'products' => json_encode($trial_products),
			);

			$mailer = WC()->mailer();

			// Send trial completed email
			$trial_completed_email = $mailer->emails['WC_TBYB_Trial_Completed_Email'];
			if ($trial_completed_email) {
				$trial_completed_email->trigger($form_data);
			}

			// Send return completed email
			$return_completed_email = $mailer->emails['WC_TBYB_Trial_Return_Completed_Email'];
			if ($return_completed_email) {
				$return_completed_email->trigger($form_data);
			}
		}

		public function Addify_TBYB_cancel_trial_period_handler() {
			check_ajax_referer('Addify_TBYB_cancel_trial_period', 'security');
			$action_type = isset($_POST['action_type']) ? sanitize_text_field(wp_unslash($_POST['action_type'])) : '';

			if ('cancel_trial' == $action_type) {
				$order_id     = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
				$order = wc_get_order($order_id);
				if (!$order) {
					wp_send_json_error('Order not found.');
				}
				$user = get_user_by('id', $order->get_user_id());
				$email = $user ? $user->user_email : '';
				$customer_name = $user ? $user->display_name : '';
				$trial_products = $order->get_meta('addify_TBYB_trial_products');
				if (empty($trial_products) || !is_array($trial_products)) {
					wp_send_json_error('Trial products not found.');
				}

				$capture_amount = 0;
				$charge_type = get_option('Addify_TBYB_charge_amount_type', 'fixed');
				$charge_amount = 0;

				foreach ($trial_products as &$product) {
					if (!is_array($product)) {
						continue;
					}
					$price = floatval($product['price']);
					$capture_amount += $price;
					$product['trial_status'] = 'cancelled';
					$product['return_status'] = 'Kept';
					$product['keep'] = 'yes';
				}

				$order->update_meta_data('addify_TBYB_trial_products', $trial_products);
				$order->save_meta_data();
				$order->save();

				if ($charge_amount > 0) {
					if ('fixed' === $charge_type) {
						$capture_amount += $charge_amount;
					} elseif ('percentage' === $charge_type) {
						$capture_amount += ( $capture_amount * $charge_amount ) / 100;
					}
				}
				$stripe_data       = get_option('woocommerce_stripe_settings');
				$test_mode         = isset($stripe_data['testmode']) && 'yes' === $stripe_data['testmode'];
				$stripe_secret     = $test_mode ? $stripe_data['test_secret_key'] : $stripe_data['secret_key'];
				$payment_intent_id = $order->get_meta('addify_TBYB_stripe_payment_intent');
				$payment_method = $order->get_meta('addify_TBYB_trial_products_order_payment_method');
				if ($capture_amount > 0) {
					if ('stripe' == $payment_method) {

						if (empty($payment_intent_id)) {
							$order->add_order_note('Stripe capture failed: Payment Intent ID is missing.');
							wp_send_json_error(array( 'message' => 'Capture failed: Missing payment intent ID.' ));
							return;
						}

						$amount_cents = intval(round($capture_amount * 100));

						$capture_response = wp_remote_post("https://api.stripe.com/v1/payment_intents/$payment_intent_id/capture", array(
							'method'  => 'POST',
							'headers' => array( 'Authorization' => 'Bearer ' . $stripe_secret ),
							'body'    => array( 'amount_to_capture' => $amount_cents ),
						));

						$capture_data = json_decode(wp_remote_retrieve_body($capture_response), true);

						if (isset($capture_data['id'])) {
							$order->add_order_note('Stripe payment manually captured: ' . $capture_data['id']);
							$order->payment_complete($capture_data['id']);

							$order->update_meta_data('addify_TBYB_trial_status', 'cancelled');
							$order->update_status('completed', 'Payment captured for kept products.');
							$order->update_meta_data('addify_TBYB_total_capture_charge', $capture_amount);
							$order->save_meta_data();
							$new_form_data = array(
								'customer_email' => $email,
								'customer_name'  => $customer_name,
								'order_id'       => $order_id,
								'products'       => json_encode($trial_products),
							);
							$mailer = WC()->mailer();
							$tbyb_email  = $mailer->emails['WC_TBYB_Trial_Completed_Email'];
							if ($tbyb_email) {
								$tbyb_email->trigger($new_form_data);
							}

							// Send return completed email
							$return_completed_email = $mailer->emails['WC_TBYB_Trial_Return_Completed_Email'];
							if ($return_completed_email) {
								$return_completed_email->trigger($new_form_data);
							}

							wp_send_json_success(array( 'message' => 'Payment captured for kept products.' ));
						} elseif (isset($capture_data['error'])) {
							$order->add_order_note('Stripe capture failed: ' . $capture_data['error']['message']);
							wp_send_json_error(array( 'message' => 'Capture failed: ' . $capture_data['error']['message'] ));
						}
					} elseif ('ppcp-gateway' == $payment_method) {
						//  Capture PayPal Order
						$bearer_object = json_decode(get_option('_transient_ppcp-paypal-bearerppcp-bearer'));

						if (!$bearer_object || empty($bearer_object->access_token)) {
							wp_die('Unable to retrieve PayPal token.');
						}

						$bearer_access_token = $bearer_object->access_token;
						$authorization_id = $order->get_meta('addify_TBYB_paypal_authorization_id');
						$paypal_common_data = get_option('woocommerce-ppcp-data-common');
						$use_sandbox = $paypal_common_data['use_sandbox'];
						$paypal_api_url = $use_sandbox ? 'https://api-m.sandbox.paypal.com' : 'https://api-m.paypal.com';

						if ($authorization_id && !empty($bearer_object->access_token)) {
							$paypal_api_url = $paypal_common_data['use_sandbox']
								? 'https://api-m.sandbox.paypal.com'
								: 'https://api-m.paypal.com';
							$capture_response = wp_remote_post("$paypal_api_url/v2/payments/authorizations/{$authorization_id}/capture", array(
								'headers' => array(
									'Authorization' => "Bearer {$bearer_access_token}",
									'Content-Type'  => 'application/json',
								),
								'body' => json_encode(array(
									'amount' => array(
										'currency_code' => 'USD',
										'value'         => number_format($capture_amount, 2, '.', ''),
									),
									'final_capture' => true,
								)),
							));

							$capture_body = json_decode(wp_remote_retrieve_body($capture_response), true);

							if (!empty($capture_body['status']) && 'COMPLETED' === $capture_body['status']) {
								$order->update_meta_data('addify_TBYB_trial_status', 'cancelled');
								$order->update_meta_data('addify_TBYB_total_capture_charge', $capture_amount);
								$order->update_status('completed', 'Payment captured for kept products.');
								$order->save_meta_data();
								$order->payment_complete();
								$order->add_order_note('PayPal: Payment successfully captured.');
								$new_form_data = array(
									'customer_email' => $email,
									'customer_name'  => $customer_name,
									'order_id'       => $order_id,
									'products'       => json_encode($trial_products),
								);
								$mailer = WC()->mailer();
								$tbyb_email  = $mailer->emails['WC_TBYB_Trial_Completed_Email'];
								if ($tbyb_email) {
									$tbyb_email->trigger($new_form_data);
								}

								// Send return completed email
								$return_completed_email = $mailer->emails['WC_TBYB_Trial_Return_Completed_Email'];
								if ($return_completed_email) {
									$return_completed_email->trigger($new_form_data);
								}
								wp_send_json_success(array( 'message' => 'Payment captured for kept products.' ));
							} else {
								$order->update_status('failed');
								$order->add_order_note('PayPal: Capture failed — ' . wp_json_encode($capture_body));
							}
						}
					}
				}
			}
			wp_send_json_success(array(
				'message' => 'Trial period cancelled successfully.',
			));
		}

		public function Addify_TBYB_extend_trial_period_handler() {
			check_ajax_referer('Addify_TBYB_extend_trial_period', 'security');
			$action_type = isset($_POST['action_type']) ? sanitize_text_field(wp_unslash($_POST['action_type'])) : '';
			if ('extend_trial' == $action_type) {
				$order_id     = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
				$order = wc_get_order($order_id);
				if (!$order) {
					wp_send_json_error('Order not found.');
				}
				$extension_days = get_option('Addify_TBYB_return_extension_window', 7);
				$enable_late_fee = get_option('Addify_TBYB_allow_late_fee_returns', 'no');
				$charge_type = get_option('Addify_TBYB_charge_amount_type', 'fixed');
				$charge_amount = get_option('Addify_TBYB_charge_amount', 1);
				$original_deposit = $order->get_meta('addify_TBYB_total_price');
				// add fee to order if enable_late_fee is true
				if ($enable_late_fee) {
					if ('fixed' === $charge_type  && is_numeric($charge_amount) && $charge_amount > 0) {
						$fee = new WC_Order_Item_Fee();
						$fee->set_name(esc_html__('Late Fee', 'addify-try-before-you-buy'));
						$fee->set_amount($charge_amount);
						$fee->set_total($charge_amount);
						$fee->set_tax_status('none'); // or 'taxable' if needed

						$order->add_item($fee);
						$order->calculate_totals();
						$order->save();
					} elseif ('percentage' === $charge_type  && is_numeric($charge_amount) && $charge_amount > 0) {
						$percentage_fee = ( $order->get_subtotal() * $charge_amount ) / 100;
						$fee = new WC_Order_Item_Fee();
						$fee->set_name(esc_html__('Late Fee', 'addify-try-before-you-buy'));
						$fee->set_amount($percentage_fee);
						$fee->set_total($percentage_fee);
						$fee->set_tax_status('none');
						$order->add_item($fee);
						$order->calculate_totals();
						$order->save();
					}
				}
				if ($extension_days <= 0) {
					$extension_days = 7;
				}
				$trial_products = $order->get_meta('addify_TBYB_trial_products');
				if (empty($trial_products) || !is_array($trial_products)) {
					wp_send_json_error('Trial products not found.');
				}
				$order_products = isset($trial_products) ? $trial_products : array();

				$extended_products = array();

				foreach ($order_products as &$product) {
					if (!empty($product['end'])) {
						$current_end_date = DateTime::createFromFormat('Y-m-d', $product['end']);
						if ($current_end_date) {
							$current_end_date->modify("+$extension_days days");
							$product['end'] = $current_end_date->format('Y-m-d');
							$product['trial_extension_period_check'] = 'set_once';
							$product['enable_late_fee'] = $enable_late_fee;
							$product['charge_type'] = $charge_type;
							$product['charge_amount'] = $charge_amount;
						}
					}
					$extended_products[] = $product;
				}

				$order->update_meta_data('addify_TBYB_trial_products', array(
					$order_id => $extended_products,
				));
				$order->add_order_note(esc_html__('Trial period extended successfully.', 'addify-try-before-you-buy'));
				$order->save();
				$user = get_user_by('id', $order->get_user_id());
				$email = $user ? $user->user_email : '';
				$customer_name = $user ? $user->display_name : '';
				$product_names    = array();
				$new_end_date     = '';
				foreach ($extended_products as $product) {
					if (! empty($product['product_name'])) {
						$product_names[] = $product['product_name'];
					}
					if (! empty($product['end'])) {
						$new_end_date = $product['end'];
					}
				}
				$total_deposit = $order->get_meta('addify_TBYB_total_price') + $charge_amount;
				$new_form_data = array(
					'customer_email'   => $email,
					'customer_name'    => $customer_name,
					'order_id'         => $order_id,
					'product'          => implode(', ', $product_names), // string for email
					'additional_time'  => $extension_days,
					'new_end_date'     => $new_end_date,
					'extension_fee'    => ( $enable_late_fee ? $charge_amount . ' (' . $charge_type . ')' : esc_html__('No Fee', 'addify-try-before-you-buy') ),
					'total_deposit'    => wc_price($order->get_total()),
					'original_deposit' => wc_price($original_deposit),
				);

				/**
				 * ✉️ Trigger custom WooCommerce email
				 */
				$mailer = WC()->mailer();
				$tbyb_email  = isset($mailer->emails['WC_TBYB_Trial_Extension_Completion_Email']) ? $mailer->emails['WC_TBYB_Trial_Extension_Completion_Email'] : false;

				if ($tbyb_email) {
					$tbyb_email->trigger($new_form_data);
				}
				wp_send_json_success(array(
					'message' => 'Trial period extented successfully.',
					'products' => $extended_products,
				));
			}
		}
		public function Addify_TBYB_ajax_search_handler() {
			check_ajax_referer('Addify_TBYB_ajax_search', 'nonce');
			$context = isset($_POST['context']) ? sanitize_text_field(wp_unslash($_POST['context'])) : '';
			$search_query = isset($_POST['q']) ? sanitize_text_field(wp_unslash($_POST['q'])) : '';

			$results = array();

			if ('roles' === $context) {
				global $wp_roles;
				$roles = $wp_roles->get_names();
				$roles['guest'] = 'Guest';
				foreach ($roles as $key => $role_name) {
					if (stripos($role_name, $search_query) !== false) {
						$results[] = array(
							'id' => $key,
							'text' => $role_name,
						);
					}
				}
			} elseif ('products' === $context) {
				// Query for products
				$args = array(
					'post_type' => 'product',
					'posts_per_page' => 10,
					's' => $search_query,
					'post_status' => 'publish',
				);

				$query = new WP_Query($args);

				if ($query->have_posts()) {
					while ($query->have_posts()) {
						$query->the_post();
						$results[] = array(
							'id' => get_the_ID(),
							'text' => get_the_title(),
						);
					}
					wp_reset_postdata();
				}
			} elseif ('categories' === $context) {
				// Query for product categories
				$args = array(
					'taxonomy' => 'product_cat',
					'hide_empty' => false,
					'number' => 10,
					'name__like' => $search_query,
				);

				$terms = get_terms($args);

				if (!is_wp_error($terms)) {
					foreach ($terms as $term) {
						$results[] = array(
							'id' => $term->term_id,
							'text' => $term->name,
						);
					}
				}
			} elseif ('brands' === $context) {
				// Query for brands (adjust taxonomy name if needed)
				$args = array(
					'taxonomy' => 'product_brand',  // or your custom brand taxonomy
					'hide_empty' => false,
					'number' => 10,
					'name__like' => $search_query,
				);

				$terms = get_terms($args);

				if (!is_wp_error($terms)) {
					foreach ($terms as $term) {
						$results[] = array(
							'id' => $term->term_id,
							'text' => $term->name,
						);
					}
				}
			} elseif ('products2' === $context) {
				// Query for products
				$args = array(
					'post_type' => 'product',
					'posts_per_page' => 10,  // Limit the number of results
					's' => $search_query,  // Search by title
					'post_status' => 'publish',
				);

				$query = new WP_Query($args);

				if ($query->have_posts()) {
					while ($query->have_posts()) {
						$query->the_post();
						$results[] = array(
							'id' => get_the_ID(),
							'text' => get_the_title(),
						);
					}
					wp_reset_postdata();
				}
			} elseif ('country' === $context) {
				if (function_exists('WC')) {
					$countries = WC()->countries->get_countries();

					foreach ($countries as $code => $name) {
						if (stripos($name, $search_query) !== false) {
							$results[] = array(
								'id' => $code,
								'text' => $name,
							);
						}
					}
				}
			} elseif ('zones' === $context) {
				if (class_exists('WC_Shipping_Zones')) {
					$zones = WC_Shipping_Zones::get_zones();

					foreach ($zones as $zone) {
						if (stripos($zone['zone_name'], $search_query) !== false) {
							$results[] = array(
								'id' => $zone['zone_id'],
								'text' => $zone['zone_name'],
							);
						}
					}

					$default_zone = new WC_Shipping_Zone(0);
					$default_zone_name = $default_zone->get_zone_name();

					if (stripos($default_zone_name, $search_query) !== false || stripos('Rest of the world', $search_query) !== false) {
						$results[] = array(
							'id' => '0',
							'text' => esc_html__('Rest of the world (default zone)', 'addify-try-before-you-buy'),
						);
					}
				}
			} elseif ('order_status' == $context) {
				$order_statuses = wc_get_order_statuses();
				foreach ($order_statuses as $status_key => $status_label) {
					if (!in_array($status_key, array( 'wc-cancelled', 'wc-refunded', 'wc-failed', 'wc-checkout-draft' ))) {
						if (stripos($status_label, $search_query) !== false) {
							$results[] = array(
								'id' => $status_key,
								'text' => $status_label,
							);
						}
					}
				}
			}

			wp_send_json($results);
		}

		public function Addify_TBYB_enqueue_scripts_admin() {
			$screen = get_current_screen();
			$valid_screens = array(
				'woocommerce_page_addify_trial_menu_page_dashboard',
				'trial_rule_tab',
				'trial_log_tab',
				'addify_trial_general_setting_tab',
			);

			if (in_array($screen->id, $valid_screens, true)) {

				// Enqueue styles and scripts
				wp_enqueue_style('Addify-TBYB-select2-css', plugins_url('assets/css/select2.css', WC_PLUGIN_FILE), array(), '5.7.2');
				wp_enqueue_script('Addify-TBYB-select2-js', plugins_url('assets/js/select2/select2.min.js', WC_PLUGIN_FILE), array( 'jquery' ), '4.0.3', true);
				wp_enqueue_script('Addify_TBYB_js_call', AD_TBYB_URL . 'assets/js/Addify_TBYB_admin.js', array( 'jquery' ), '1.0.2', false);
				wp_enqueue_style('ad_font_awesomefont', AD_TBYB_URL . 'assets/font-awesome/css/font-awesome.min.css', array(), '4.7.0');
				wp_enqueue_style('Addify_TBYB_admin', AD_TBYB_URL . '/assets/css/Addify_TBYB_admin.css', false, '1.1');
				wp_enqueue_script('chart-js', AD_TBYB_URL . 'assets/js/chart-umd.js', array(), '1.0.0', true);
				wp_enqueue_script('Addify_TBYB_js_call_chart', AD_TBYB_URL . 'assets/js/Addify_TBYB_admin_chart.js', array( 'jquery' ), '1.0.2', false);
				wp_enqueue_style('Addify-flatpickr-css', AD_TBYB_URL . 'assets/css/flatpickr.min.css', array(), '4.6.13');
				wp_enqueue_script('Addify-flatpickr-js', AD_TBYB_URL . 'assets/js/flatpickr.min.js', array( 'jquery' ), '4.6.13', true);

				wp_enqueue_style('thickbox');
				wp_enqueue_script('thickbox');
				wp_enqueue_script('media-upload');
				wp_enqueue_media();

				if (class_exists('WooCommerce')) {
					wp_enqueue_script('jquery-tiptip');
					wp_enqueue_style('woocommerce_admin_styles', WC()->plugin_url() . '/assets/css/admin.css', array(), WC()->version);
				}

				// === Setup today range (hourly) based on site timezone ===
				$tz = wp_timezone(); // Site timezone object

				$labels = array();
				$active_trial = array();
				$ending_this_week = array();
				$total_kept = array();
				$amount_of_kept_products = array();
				$shipping_cost = array();
				$total_returns = array();
				$average_return_rate = array();

				$start = new DateTime('today 00:00:00', $tz);
				$end   = new DateTime('today 23:59:59', $tz);
				$cursor = clone $start;

				while ($cursor <= $end) {
					$key = $cursor->format('Y-m-d H:00');
					$label = $cursor->format('H:i');
					$labels[] = $label;

					$active_trial[ $key ] = 0;
					$ending_this_week[ $key ] = 0;
					$total_kept[ $key ] = 0;
					$amount_of_kept_products[ $key ] = 0;
					$shipping_cost[ $key ] = 0;
					$total_returns[ $key ] = 0;
					$average_return_rate[ $key ] = 0;

					$cursor->modify('+1 hour');
				}

				// Fetch orders for today
				$args = array(
					'limit'        => -1,
					'status'       => array( 'completed', 'processing', 'refunded', 'cancelled' ),
					'type'         => 'shop_order',
					'date_created' => $start->format('Y-m-d H:i:s') . '...' . $end->format('Y-m-d H:i:s'),
				);

				$orders = wc_get_orders($args);

				foreach ($orders as $order) {
					$order_id = $order->get_id();
					$product_trial_count = 0;
					$order_date = $order->get_date_created();

					if (!$order_date) {
						continue;
					}

					// Convert to site timezone before formatting
					$order_date = $order_date->setTimezone($tz);
					$key = $order_date->format('Y-m-d H:00');
					if (!isset($active_trial[ $key ])) {
						continue;
					}

					$trial_data = $order->get_meta('addify_TBYB_trial_products');
					if (empty($trial_data) || !is_array($trial_data)) {
						continue;
					}

					$trial_products = isset($trial_data) ? $trial_data : array();

					foreach ($trial_products as $product) {

						if (!is_array($product)) {
							continue;
						}

						$price      = floatval(isset($product['price']) ? $product['price'] : 0);
						$keep       = isset($product['keep']) ? $product['keep'] : '';
						$return     = isset($product['return_status']) ? $product['return_status'] : '';
						$end_date   = isset($product['end']) ? $product['end'] : '';
						$shipping   = floatval(isset($product['shipping_cost']) ? $product['shipping_cost'] : 0);
						$trial_status   = isset($product['trial_status']) ? $product['trial_status'] : '';
						$active_status   = isset($product['status']) ? $product['status'] : '';

						$now = new DateTime('now', $tz);

						if ('cancelled' !== $trial_status && 0 == $product_trial_count) {
							$order_has_capture = ! empty($order->get_meta('addify_TBYB_total_capture_charge'));
							$is_fully_processed = in_array($return, array( 'Approved', 'Rejected', 'Kept' ), true)
								|| $order_has_capture
								|| 'cancelled' == $trial_status;
							if (!$is_fully_processed) {
								$end_ts = strtotime($end_date);
								if ($end_ts >= $now->getTimestamp()) {
									$active_trial[ $key ]++;
								}
							}
						}

						// Kept (treat cancelled as kept)
						if ('yes' == $keep  || ( 'Rejected' == $return && 'Returned' == $active_status )) {
							$total_kept[ $key ]++;
							$amount_of_kept_products[ $key ] += $price;
							$shipping_cost[ $key ] += $shipping;
						}

						// Returned
						if (!empty($return) && 'yes' !== $keep  && ( 'Approved' == $return && 'Returned' == $active_status )) {
							$total_returns[ $key ]++;
						}

						$shipping_cost[ $key ] += $shipping;
						if (
							!empty($end_date)
							&& 'expired' !== $active_status
							&& 'cancelled' !== $trial_status
							&& 0 == $product_trial_count
						) {
							$order_has_capture = ! empty($order->get_meta('addify_TBYB_total_capture_charge'));
							$is_fully_processed = in_array($return, array( 'Approved', 'Rejected', 'Kept' ), true)
								|| $order_has_capture
								|| 'cancelled' == $trial_status;

							if (!$is_fully_processed) {
								$end_ts = strtotime($end_date);
								$now_ts = $now->getTimestamp();

								// Get start (Monday) and end (Sunday) of current week based on $now
								$start_of_week = strtotime('monday this week', $now_ts);
								$end_of_week   = strtotime('sunday this week', $now_ts);

								// Count if end date falls within current week
								if ($end_ts >= $start_of_week && $end_ts <= $end_of_week) {
									$ending_this_week[ $key ]++;
								}
							}
						}

						$product_trial_count = 1;
					}
				}

				// Calculate average return rate
				foreach ($labels as $i => $label) {
					$key = array_keys($active_trial)[ $i ];
					$handled = $total_kept[ $key ] + $total_returns[ $key ];
					$average_return_rate[ $key ] = ( $handled > 0 )
						? round(( $total_returns[ $key ] / $handled ) * 100, 2)
						: 0;
				}

				// Prepare JSON start/end in site timezone
				$start_clone = clone $start;
				$end_clone   = clone $end;
				$range = 'today';

				$json_start = array(
					'date' => $start_clone->format('Y-m-d H:i:s') . '.000000',
					'timezone_type' => 3,
					'timezone' => wp_timezone_string(),
				);

				$json_end = array(
					'date' => $end_clone->format('Y-m-d H:i:s') . '.000000',
					'timezone_type' => 3,
					'timezone' => wp_timezone_string(),
				);

				// Localize to JS
				$wsp_data = array(
					'chart_data' => array(
						'active_trial' => array_values($active_trial),
						'ending_this_week' => array_values($ending_this_week),
						'total_kept' => array_values($total_kept),
						'amount_of_kept_products' => array_values($amount_of_kept_products),
						'shipping_cost' => array_values($shipping_cost),
						'total_returns' => array_values($total_returns),
						'average_return_rate' => array_values($average_return_rate),
						'labels' => $labels,
						'start_date'              => $json_start,
						'end_date'                => $json_end,
						'range'                   => $range,
					),
					'admin_url' => admin_url('admin-ajax.php'),
					'nonce' => wp_create_nonce('Addify_TBYB_ajax_search'),
					'save_message_admin_nonce' => wp_create_nonce('Addify_TBYB_extend_trial_period'),
					'admin_extend_nonce' => wp_create_nonce('Addify_TBYB_extend_trial_period'),
					'admin_cancel_nonce' => wp_create_nonce('Addify_TBYB_cancel_trial_period'),
					'admin_approve_nonce' => wp_create_nonce('Addify_TBYB_approve_trial_period'),
					'admin_reject_nonce' => wp_create_nonce('Addify_TBYB_reject_trial_period'),
					'choose_role' => esc_html__('Choose role', 'addify-try-before-you-buy'),
					'choose_products' => esc_html__('Choose products', 'addify-try-before-you-buy'),
					'choose_categories' => esc_html__('Choose category', 'addify-try-before-you-buy'),
					'choose_brands' => esc_html__('Choose brand', 'addify-try-before-you-buy'),
					'choose_country' => esc_html__('Choose country', 'addify-try-before-you-buy'),
					'choose_order_status' => esc_html__('Choose order status', 'addify-try-before-you-buy'),
					'choose_zone' => esc_html__('Choose zone', 'addify-try-before-you-buy'),
					'rejected_text' => esc_html__('Rejected', 'addify-try-before-you-buy'),
					'admin_reject_text' => esc_html__('Admin Reject Reason', 'addify-try-before-you-buy'),
					'remove' => esc_html__('Remove', 'addify-try-before-you-buy'),
				);

				wp_localize_script('Addify_TBYB_js_call', 'wsp_php_vars', $wsp_data);
			}
		}


		
		/**
		 * Match order item with a trial product entry.
		 */
		private function addify_match_trial_product( $item, $trial_products_for_order ) {

			$product_id   = $item->get_product_id();
			$variation_id = $item->get_variation_id();

			// Build attribute array from order item
			$item_attr = array();
			foreach ($item->get_meta_data() as $meta) {
				$key   = $meta->key;
				$value = $meta->value;

				if ('Trial Product' == $key) {
					continue;
				}

				// Normalize attribute keys
				if (0 !== strpos($key, 'attribute_')) {
					$key = 'attribute_' . $key;
				}
				$item_attr[ $key ] = $value;
			}

			// Loop through trial entries for this order
			foreach ($trial_products_for_order as $entry) {
				$meta_product_id   = intval($entry['product_id']);
				$meta_variation_id = intval($entry['variation_id']);
				$trial_attr        = isset($entry['product_variation_data']) ? $entry['product_variation_data'] : array();

				//  Match product or variation
				$id_match = (
					( $variation_id && $variation_id === $meta_variation_id ) ||
					( !$variation_id && $product_id === $meta_product_id )
				);
				if (!$id_match) {
					continue;
				}

				//  Match attribute set
				if (!empty($trial_attr)) {
					if ($trial_attr !== $item_attr) {
						continue;
					}
				}

				return $entry; //  FOUND MATCH
			}

			return null; // no match
		}

		

	

	}

	new Addify_TBYB_Meta_Box();
endif;
