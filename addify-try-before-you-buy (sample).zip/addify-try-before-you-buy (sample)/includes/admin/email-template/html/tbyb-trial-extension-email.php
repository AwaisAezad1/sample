<?php
if (! defined('ABSPATH')) {
	exit;
}

$Addify_TBYB_customer_name = isset($new_form_data['customer_name']) ? $new_form_data['customer_name'] : '';
$Addify_TBYB_order_id      = isset($new_form_data['order_id']) ? $new_form_data['order_id'] : '';
$Addify_TBYB_request_date  = isset($new_form_data['request_date']) ? $new_form_data['request_date'] : date_i18n('F j, Y');
$Addify_TBYB_blog_name     = esc_html(get_bloginfo('name'));
?>

<!DOCTYPE html>
<html>

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php echo esc_html__('Trial Extension Request Confirmation', 'addify-try-before-you-buy'); ?></title>
	<style>
		* {
			margin: 0;
			padding: 0;
			box-sizing: border-box;
			font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
		}

		body {
			background-color: #f7f9fc;
			color: #333;
			line-height: 1.6;
			padding: 20px;
		}

		.email-container {
			max-width: 600px;
			margin: 0 auto;
			background: white;
			border-radius: 12px;
			overflow: hidden;
			box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
		}

		.email-header {
			background: linear-gradient(135deg, #4f46e5, #7c3aed);
			color: white;
			padding: 30px 20px;
		}

		.email-header h1 {
			text-align: center;
			color: white;
			font-size: 28px;
			margin-bottom: 10px;
			font-weight: 600;
		}

		.email-header p {
			opacity: 0.9;
			font-size: 16px;
		}

		.email-body {
			padding: 30px;
		}

		.greeting {
			font-size: 18px;
			margin-bottom: 25px;
			color: #374151;
		}

		.order-info {
			background: #f9fafb;
			border-radius: 8px;
			padding: 20px;
			margin: 20px 0;
			border-left: 4px solid #4f46e5;
		}

		.info-row {
			display: flex;
			margin-bottom: 12px;
		}

		.info-label {
			font-weight: 600;
			width: 140px;
			color: #4b5563;
		}

		.info-value {
			flex: 1;
			color: #1f2937;
		}

		.status-badge {
			display: inline-block;
			padding: 6px 12px;
			background: #fef3c7;
			color: #92400e;
			border-radius: 50px;
			font-size: 14px;
			font-weight: 500;
		}

		.message-box {
			background: #f0f9ff;
			border: 1px solid #bae6fd;
			border-radius: 8px;
			padding: 20px;
			margin: 25px 0;
		}

		.message-title {
			font-weight: 600;
			color: #0369a1;
			margin-bottom: 10px;
			display: flex;
			align-items: center;
			gap: 8px;
		}

		.next-steps {
			background: #f0fdf4;
			border: 1px solid #bbf7d0;
			border-radius: 8px;
			padding: 20px;
			margin: 25px 0;
		}

		.next-steps-title {
			font-weight: 600;
			color: #166534;
			margin-bottom: 10px;
			display: flex;
			align-items: center;
			gap: 8px;
		}

		.steps-list {
			padding-left: 20px;
		}

		.steps-list li {
			margin-bottom: 8px;
		}

		.support-note {
			text-align: center;
			margin: 30px 0 20px;
			color: #6b7280;
			font-size: 15px;
		}

		.email-footer {
			background: #f9fafb;
			padding: 20px;
			text-align: center;
			color: #6b7280;
			font-size: 14px;
			border-top: 1px solid #e5e7eb;
		}

		.logo {
			font-size: 20px;
			font-weight: 700;
			color: #4f46e5;
			margin-bottom: 10px;
		}

		@media (max-width: 600px) {
			.email-body {
				padding: 20px;
			}

			.info-row {
				flex-direction: column;
				margin-bottom: 15px;
			}

			.info-label {
				width: 100%;
				margin-bottom: 5px;
			}
		}
	</style>
</head>

<body>
	<div class="email-container">
		<div class="email-header">
			<h1><?php echo esc_html__('Trial Extension Request Received', 'addify-try-before-you-buy'); ?></h1>
			<p><?php echo esc_html__('We\'ve received your request and will process it shortly', 'addify-try-before-you-buy'); ?></p>
		</div>

		<div class="email-body">
			<div class="greeting">
				<p>
				<?php
					printf(
						// translators: %s shows the customer name.
						esc_html__('Hi %s,', 'addify-try-before-you-buy'),
						'<strong>' . esc_html($Addify_TBYB_customer_name) . '</strong>'
					);
					?>
					</p>
			</div>

			<p><?php echo esc_html__('Thank you for submitting a trial extension request. We\'ve received your request and our team will review it shortly.', 'addify-try-before-you-buy'); ?></p>

			<div class="order-info">
				<div class="info-row">
					<div class="info-label"><?php echo esc_html__('Order Number:', 'addify-try-before-you-buy'); ?></div>
					<div class="info-value">#<?php echo esc_html($Addify_TBYB_order_id); ?></div>
				</div>
				<div class="info-row">
					<div class="info-label"><?php echo esc_html__('Request Date:', 'addify-try-before-you-buy'); ?></div>
					<div class="info-value"><?php echo esc_html($Addify_TBYB_request_date); ?></div>
				</div>
				<div class="info-row">
					<div class="info-label"><?php echo esc_html__('Current Status:', 'addify-try-before-you-buy'); ?></div>
					<div class="info-value"><span class="status-badge"><?php echo esc_html__('Under Review', 'addify-try-before-you-buy'); ?></span></div>
				</div>
			</div>

			<div class="message-box">
				<div class="message-title">
					<?php echo esc_html__('Please wait while the admin approves your trial extension request.', 'addify-try-before-you-buy'); ?>
				</div>
			</div>

			<div class="next-steps">
				<div class="next-steps-title">
					<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
						<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
					</svg>
					<?php echo esc_html__('What Happens Next?', 'addify-try-before-you-buy'); ?>
				</div>
				<ul class="steps-list">
					<li><?php echo esc_html__('Our team will review your extension request', 'addify-try-before-you-buy'); ?></li>
					<li><?php echo esc_html__('You\'ll receive an email notification once a decision is made', 'addify-try-before-you-buy'); ?></li>
					<li><?php echo esc_html__('If approved, your trial period will be extended accordingly', 'addify-try-before-you-buy'); ?></li>
				</ul>
			</div>

			<div class="support-note">
				<p><?php echo esc_html__('If you have any questions, please contact our support team.', 'addify-try-before-you-buy'); ?></p>
			</div>
		</div>

		<div class="email-footer">
			<div class="logo"><?php echo esc_html($Addify_TBYB_blog_name); ?></div>
			<p><?php echo esc_html__('This is an automated message. Please do not reply to this email.', 'addify-try-before-you-buy'); ?></p>
			<p>&copy; <?php echo wp_kses_post(gmdate('Y')); ?> <?php echo esc_html($Addify_TBYB_blog_name); ?>. <?php echo esc_html__('All rights reserved.', 'addify-try-before-you-buy'); ?></p>
		</div>
	</div>
</body>

</html>