<?php
if (!defined('ABSPATH')) {
	exit;
}

$Addify_TBYB_customer_name = isset($new_form_data['customer_name']) ? $new_form_data['customer_name'] : '';
$Addify_TBYB_order_id      = isset($new_form_data['order_id']) ? $new_form_data['order_id'] : '';
$Addify_TBYB_blog_name     = esc_html(get_bloginfo('name'));
?>

<!DOCTYPE html>
<html>

<head>
	<meta charset="UTF-8">
	<style>
		body {
			font-family: Arial, sans-serif;
			line-height: 1.6;
			color: #333;
			max-width: 600px;
			margin: 0 auto;
			padding: 20px;
			background-color: #f9f9f9;
		}

		.email-container {
			background: #ffffff;
			border-radius: 12px;
			padding: 40px;
			box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
		}

		.header {
			text-align: center;
			margin-bottom: 30px;
			border-bottom: 2px solid #f0f0f0;
			padding-bottom: 25px;
		}

		.header h1 {
			color: #dc2626;
			margin: 0;
			font-size: 28px;
			font-weight: bold;
		}

		.content {
			margin-bottom: 30px;
		}

		.greeting {
			font-size: 18px;
			margin-bottom: 25px;
			color: #374151;
		}

		.notice-card {
			background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%);
			border: 2px solid #fecaca;
			padding: 25px;
			border-radius: 12px;
			margin: 25px 0;
			box-shadow: 0 2px 10px rgba(220, 38, 38, 0.1);
			text-align: center;
		}

		.notice-card h2 {
			margin-top: 0;
			color: #991b1b;
			text-align: center;
			font-size: 20px;
			gap: 10px;
		}

		.order-details {
			background: #f8fafc;
			border: 1px solid #e2e8f0;
			padding: 20px;
			border-radius: 8px;
			margin: 20px 0;
			text-align: center;
		}

		.order-id {
			font-size: 18px;
			font-weight: bold;
			color: #374151;
		}

		.support-section {
			background: #eff6ff;
			border-left: 4px solid #3b82f6;
			padding: 20px;
			border-radius: 8px;
			margin: 25px 0;
		}

		.signature {
			text-align: center;
			margin-top: 40px;
			padding-top: 25px;
			border-top: 2px solid #f0f0f0;
		}

		.team-name {
			font-weight: bold;
			color: #374151;
			font-size: 16px;
		}

		.footer {
			text-align: center;
			margin-top: 30px;
			color: #6b7280;
			font-size: 14px;
		}

		.icon {
			margin-right: 8px;
			font-size: 18px;
		}
	</style>
</head>

<body>
	<div class="email-container">
		<div class="header">
			<h1>⏰ <?php echo esc_html($email_heading); ?></h1>
		</div>

		<div class="content">
			<div class="greeting">
				<p>
					<?php
					printf(
						// translators: %s shows the customer name.
						esc_html__('Hi %s,', 'addify-try-before-you-buy'),
						'<strong>' . esc_html($Addify_TBYB_customer_name) . '</strong>'
					);
					?>
				</p>
			</div>

			<div class="notice-card">
				<h2><span class="icon">⚠️</span> <?php esc_html_e('Trial Period Expired', 'addify-try-before-you-buy'); ?></h2>
				<p><?php esc_html_e('Your trial period has officially ended.', 'addify-try-before-you-buy'); ?></p>
			</div>

			<div class="order-details">
				<p><strong><?php echo esc_html__('Order Reference:', 'addify-try-before-you-buy'); ?></strong></p>
				<p class="order-id">#<?php echo esc_html($Addify_TBYB_order_id); ?></p>
			</div>

			<div class="support-section">
				<p><strong>❓ <?php esc_html_e('What happens next?', 'addify-try-before-you-buy'); ?></strong></p>
				<p><?php esc_html_e('You can request for a refund for your expired order if applicable. Contact our support team if you have any questions.', 'addify-try-before-you-buy'); ?></p>
			</div>
		</div>

		<div class="signature">
			<p><?php esc_html_e('Thank you,', 'addify-try-before-you-buy'); ?></p>
			<p class="team-name"><?php echo esc_html($Addify_TBYB_blog_name); ?></p>
		</div>

		<div class="footer">
			<p><?php esc_html_e('We appreciate your business.', 'addify-try-before-you-buy'); ?></p>
		</div>
	</div>
</body>

</html>