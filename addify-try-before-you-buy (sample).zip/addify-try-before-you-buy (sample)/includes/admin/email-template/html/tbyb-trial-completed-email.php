<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$Addify_TBYB_customer_name = isset( $new_form_data['customer_name'] ) ? $new_form_data['customer_name'] : '';
$Addify_TBYB_order_id      = isset( $new_form_data['order_id'] ) ? $new_form_data['order_id'] : '';
$Addify_TBYB_products      = isset( $new_form_data['products'] ) ? json_decode( $new_form_data['products'], true ) : array();

// Separate kept and returned products
$Addify_TBYB_kept_products     = array();
$Addify_TBYB_returned_products = array();

// Case-insensitive version
foreach ( $Addify_TBYB_products as $Addify_TBYB_product ) {
	$Addify_TBYB_return_status = isset( $Addify_TBYB_product['return_status'] ) ? strtolower( $Addify_TBYB_product['return_status'] ) : '';

	if ( 'approved' === $Addify_TBYB_return_status ) {
		$Addify_TBYB_returned_products[] = $Addify_TBYB_product;
	} elseif (
		( isset( $Addify_TBYB_product['keep'] ) && 'yes' === $Addify_TBYB_product['keep'] )
		|| 'rejected' === $Addify_TBYB_return_status
		|| 'kept' === $Addify_TBYB_return_status
	) {
		$Addify_TBYB_kept_products[] = $Addify_TBYB_product;
	}
}

$Addify_TBYB_has_kept     = ! empty( $Addify_TBYB_kept_products );
$Addify_TBYB_has_returned = ! empty( $Addify_TBYB_returned_products );

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<style>
		body {
			font-family: Arial, sans-serif;
			line-height: 1.6;
			color: #333;
			max-width: 600px;
			margin: 0 auto;
			padding: 20px;
			background-color: #f9f9f9;
		}
		.email-container {
			background: #ffffff;
			border-radius: 8px;
			padding: 30px;
			box-shadow: 0 2px 10px rgba(0,0,0,0.1);
		}
		.header {
			text-align: center;
			margin-bottom: 30px;
			border-bottom: 2px solid #f0f0f0;
			padding-bottom: 20px;
		}
		.header h1 {
			color: #2c3e50;
			margin: 0;
			font-size: 24px;
		}
		.content {
			margin-bottom: 30px;
		}
		.greeting {
			font-size: 16px;
			margin-bottom: 20px;
		}
		.section {
			margin: 25px 0;
			padding: 20px;
			border-radius: 4px;
		}
		.kept-section {
			background: #d4edda;
			border-left: 4px solid #28a745;
		}
		.returned-section {
			background: #f8d7da;
			border-left: 4px solid #dc3545;
		}
		.section-title {
			margin-top: 0;
			font-size: 18px;
		}
		.product-table {
			width: 100%;
			border-collapse: collapse;
			margin: 15px 0;
		}
		.product-table th {
			text-align: left;
			padding: 10px;
			border-bottom: 2px solid #ddd;
			background-color: rgba(255,255,255,0.3);
		}
		.product-table td {
			padding: 10px;
			border-bottom: 1px solid #eee;
		}
		.order-details {
			background: #f8f9fa;
			border-left: 4px solid #3498db;
			padding: 20px;
			border-radius: 4px;
			margin: 25px 0;
		}
		.detail-row {
			display: flex;
			justify-content: space-between;
			margin-bottom: 10px;
			padding: 8px 0;
		}
		.detail-label {
			font-weight: bold;
			color: #555;
			min-width: 150px;
		}
		.detail-value {
			color: #2c3e50;
		}
		.thank-you {
			text-align: center;
			margin: 25px 0;
			padding: 20px;
			background: #e7f4ff;
			border-radius: 4px;
		}
		.signature {
			text-align: center;
			margin-top: 30px;
			padding-top: 20px;
			border-top: 2px solid #f0f0f0;
		}
		.team-name {
			font-weight: bold;
			color: #2c3e50;
		}
		.footer {
			text-align: center;
			margin-top: 30px;
			color: #7f8c8d;
			font-size: 14px;
		}
	</style>
</head>
<body>
	<div class="email-container">
		<div class="header">
			<h1>✅ <?php echo esc_html( $email_heading ); ?></h1>
		</div>

		<div class="content">
			<div class="greeting">
				<p>
				<?php
				printf(
					// translators: %s shows the customer name.
					esc_html__( 'Hello %s,', 'addify-try-before-you-buy' ), 
					'<strong>' . esc_html( $Addify_TBYB_customer_name ) . '</strong>'
				);
				?>
				</p>
				<p><?php esc_html_e( 'Your Try Before You Buy trial has been completed. Here is the summary of the products from your trial:', 'addify-try-before-you-buy' ); ?></p>
			</div>

			<?php if ($Addify_TBYB_has_kept) : ?>
			<div class="section kept-section">
				<h2 class="section-title">🎉 <?php esc_html_e( 'Products You Kept', 'addify-try-before-you-buy' ); ?></h2>
				<p><?php esc_html_e( "We're thrilled that you decided to keep these products! They're now yours to keep - no need to return anything.", 'addify-try-before-you-buy' ); ?></p>
				
				<table class="product-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Product', 'addify-try-before-you-buy' ); ?></th>
							<th><?php esc_html_e( 'Price', 'addify-try-before-you-buy' ); ?></th>
						</tr>
					</thead>
					<tbody style="text-align: left;">
						<?php foreach ( $Addify_TBYB_kept_products as $Addify_TBYB_product ) : ?>
							<tr>
								<td><?php echo esc_html( isset( $Addify_TBYB_product['product'] ) ? $Addify_TBYB_product['product'] : '' ); ?></td>
								<td><?php echo wp_kses_post(wp_kses_post($Addify_TBYB_product['display_price'])); ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
			<?php endif; ?>

			<?php if ($Addify_TBYB_has_returned) : ?>
			<div class="section returned-section">
				<h2 class="section-title">📦 <?php esc_html_e( 'Products You Returned', 'addify-try-before-you-buy' ); ?></h2>
				<p><?php esc_html_e( "We've received your return for the following products. Your refund will be processed according to our return policy.", 'addify-try-before-you-buy' ); ?></p>
				
				<table class="product-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Product', 'addify-try-before-you-buy' ); ?></th>
							<th><?php esc_html_e( 'Price', 'addify-try-before-you-buy' ); ?></th>
						</tr>
					</thead>
					<tbody style="text-align: left;">
						<?php foreach ( $Addify_TBYB_returned_products as $Addify_TBYB_product ) : ?>
							<tr>
								<td><?php echo esc_html( isset( $Addify_TBYB_product['product'] ) ? $Addify_TBYB_product['product'] : '' ); ?></td>
								<td><?php echo wp_kses_post(wp_kses_post($Addify_TBYB_product['display_price'])); ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
			<?php endif; ?>

			<div class="order-details">
				<h3 style="margin-top: 0; color: #2c3e50;"><?php esc_html_e( 'Order Details', 'addify-try-before-you-buy' ); ?></h3>
				<div class="detail-row">
					<span class="detail-label"><?php esc_html_e( 'Order ID:', 'addify-try-before-you-buy' ); ?></span>
					<span class="detail-value"><?php echo esc_html( $Addify_TBYB_order_id ); ?></span>
				</div>
				<div class="detail-row">
					<span class="detail-label"><?php esc_html_e( 'Order Date:', 'addify-try-before-you-buy' ); ?></span>
					<span class="detail-value"><?php echo esc_html( date_i18n( get_option( 'date_format' ) ) ); ?></span>
				</div>
			</div>

			<div class="thank-you">
				<p>🙏 <?php esc_html_e( 'Thank you for trying our products! We hope you enjoyed the experience.', 'addify-try-before-you-buy' ); ?></p>
				<p><?php esc_html_e( "We'll send you a receipt and warranty information shortly.", 'addify-try-before-you-buy' ); ?></p>
			</div>
		</div>

		<div class="signature">
			<p><?php esc_html_e( 'Best regards,', 'addify-try-before-you-buy' ); ?></p>
			<p class="team-name"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></p>
		</div>

		<div class="footer">
			<p><?php esc_html_e( 'Thanks for trying before buying with us!', 'addify-try-before-you-buy' ); ?></p>
		</div>
	</div>
</body>
</html>