<?php if (!defined('ABSPATH')) {
	exit;
}

$Addify_TBYB_customer_name  = isset($new_form_data['customer_name']) ? $new_form_data['customer_name'] : esc_html__('there', 'addify-try-before-you-buy');
$Addify_TBYB_product_name   = isset($new_form_data['product']) ? $new_form_data['product'] : '';
$Addify_TBYB_trial_period   = isset($new_form_data['trial_period']) ? $new_form_data['trial_period'] : '';
$Addify_TBYB_trial_start    = isset($new_form_data['begin']) ? $new_form_data['begin'] : '';
$Addify_TBYB_trial_end      = isset($new_form_data['ends']) ? $new_form_data['ends'] : '';
$Addify_TBYB_deposit        = isset($new_form_data['deposit']) ? $new_form_data['deposit'] : '';
$Addify_TBYB_track_url      = isset($new_form_data['track_url']) ? $new_form_data['track_url'] : '#';
$Addify_TBYB_blog_name      = esc_html(get_bloginfo('name'));
?>

<!DOCTYPE html>
<html>

<head>
	<meta charset="UTF-8">
	<style>
		body {
			font-family: Arial, sans-serif;
			line-height: 1.6;
			color: #333;
			max-width: 600px;
			margin: 0 auto;
			padding: 20px;
			background-color: #f9f9f9;
		}

		.email-container {
			background: #ffffff;
			border-radius: 12px;
			padding: 40px;
			box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
		}

		.header {
			text-align: center;
			margin-bottom: 30px;
			border-bottom: 2px solid #f0f0f0;
			padding-bottom: 25px;
		}

		.header h1 {
			color: #22c55e;
			margin: 0;
			font-size: 28px;
			font-weight: bold;
		}

		.content {
			margin-bottom: 30px;
		}

		.greeting {
			font-size: 18px;
			margin-bottom: 25px;
			color: #374151;
		}

		.trial-card {
			background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
			border: 2px solid #bbf7d0;
			padding: 25px;
			border-radius: 12px;
			margin: 25px 0;
			box-shadow: 0 2px 10px rgba(34, 197, 94, 0.1);
		}

		.trial-card h2 {
			margin-top: 0;
			color: #166534;
			font-size: 20px;
			display: flex;
			align-items: center;
			gap: 10px;
		}

		.detail-list {
			list-style: none;
			padding: 0;
			margin: 20px 0 0 0;
		}

		.detail-list li {
			padding: 12px 0;
			border-bottom: 1px solid #d1fae5;
			display: flex;
			justify-content: space-between;
			align-items: center;
		}

		.detail-list li:last-child {
			border-bottom: none;
		}

		.detail-label {
			font-weight: 600;
			color: #374151;
			min-width: 120px;
		}

		.detail-value {
			color: #166534;
			font-weight: 500;
			text-align: right;
		}

		.shipping-note {
			background: #eff6ff;
			border-left: 4px solid #3b82f6;
			padding: 20px;
			border-radius: 8px;
			margin: 25px 0;
		}

		.cta-container {
			text-align: center;
			margin: 30px 0;
		}

		.track-button {
			display: inline-block;
			background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);
			color: white !important;
			padding: 16px 32px;
			text-decoration: none;
			border-radius: 8px;
			font-weight: 600;
			font-size: 16px;
			box-shadow: 0 4px 12px rgba(34, 197, 94, 0.3);
			transition: all 0.3s ease;
		}

		.track-button:hover {
			transform: translateY(-2px);
			box-shadow: 0 6px 16px rgba(34, 197, 94, 0.4);
		}

		.support-section {
			background: #fef3c7;
			border-left: 4px solid #f59e0b;
			padding: 20px;
			border-radius: 8px;
			margin: 25px 0;
		}

		.signature {
			text-align: center;
			margin-top: 40px;
			padding-top: 25px;
			border-top: 2px solid #f0f0f0;
		}

		.team-name {
			font-weight: bold;
			color: #374151;
			font-size: 16px;
		}

		.footer {
			text-align: center;
			margin-top: 30px;
			color: #6b7280;
			font-size: 14px;
		}

		.icon {
			margin-right: 8px;
			font-size: 18px;
		}
	</style>
</head>

<body>
	<div class="email-container">
		<div class="header">
			<h1>🎉 <?php esc_html_e('Your Trial Has Started!', 'addify-try-before-you-buy'); ?></h1>
		</div>

		<div class="content">
			<div class="greeting">
				<p>
					<?php
					printf(
						// translators: %s shows the customer name.
						esc_html__('Hi %s,', 'addify-try-before-you-buy'),
						'<strong>' . esc_html($Addify_TBYB_customer_name) . '</strong>'
					);
					?>
				</p>
				<p>
					<?php
					printf(
						// translators: %s shows the product name.
						esc_html__('Great news! Your trial for %s has officially begun.', 'addify-try-before-you-buy'),
						'<strong style="color: #166534;">' . esc_html($Addify_TBYB_product_name) . '</strong>'
					);
					?>
				</p>
			</div>

			<div class="trial-card">
				<h2><span class="icon">📋</span> <?php esc_html_e('Trial Details', 'addify-try-before-you-buy'); ?></h2>

				<ul class="detail-list">
					<li>
						<span class="detail-label"><?php esc_html_e('Product:', 'addify-try-before-you-buy'); ?></span>
						<span class="detail-value"><?php echo esc_html($Addify_TBYB_product_name); ?></span>
					</li>
					<li>
						<span class="detail-label"><?php esc_html_e('Trial Period:', 'addify-try-before-you-buy'); ?></span>
						<span class="detail-value"><?php echo esc_html($Addify_TBYB_trial_period); ?></span>
					</li>
					<li>
						<span class="detail-label"><?php esc_html_e('Started:', 'addify-try-before-you-buy'); ?></span>
						<span class="detail-value"><?php echo esc_html($Addify_TBYB_trial_start); ?></span>
					</li>
					<li>
						<span class="detail-label"><?php esc_html_e('Ends:', 'addify-try-before-you-buy'); ?></span>
						<span class="detail-value"><?php echo esc_html($Addify_TBYB_trial_end); ?></span>
					</li>
					<li>
						<span class="detail-label"><?php esc_html_e('Deposit:', 'addify-try-before-you-buy'); ?></span>
						<span class="detail-value"><?php echo esc_html($Addify_TBYB_deposit); ?> <small>(<?php esc_html_e('refundable', 'addify-try-before-you-buy'); ?>)</small></span>
					</li>
				</ul>
			</div>

			<div class="shipping-note">
				<p><strong>🚚 <?php esc_html_e('Shipping Information', 'addify-try-before-you-buy'); ?></strong></p>
				<p><?php esc_html_e('Your product is being shipped and will arrive within 2–3 business days. Once you receive it, you\'ll have the full trial period to test it out!', 'addify-try-before-you-buy'); ?></p>
			</div>

			<div class="cta-container">
				<a href="<?php echo esc_url($Addify_TBYB_track_url); ?>" class="track-button">
					📦 <?php esc_html_e('Track Your Trial Package', 'addify-try-before-you-buy'); ?>
				</a>
			</div>

			<div class="support-section">
				<p><strong>💡 <?php esc_html_e('Need Help?', 'addify-try-before-you-buy'); ?></strong></p>
				<p><?php esc_html_e('Questions? Reply to this email or contact our support team. We\'re here to help you make the most of your trial!', 'addify-try-before-you-buy'); ?></p>
			</div>
		</div>

		<div class="signature">
			<p><?php esc_html_e('Happy Testing!', 'addify-try-before-you-buy'); ?></p>
			<p class="team-name"><?php echo esc_html($Addify_TBYB_blog_name); ?></p>
		</div>

		<div class="footer">
			<p><?php esc_html_e('Thank you for choosing our Try Before You Buy program.', 'addify-try-before-you-buy'); ?></p>
		</div>
	</div>
</body>

</html>