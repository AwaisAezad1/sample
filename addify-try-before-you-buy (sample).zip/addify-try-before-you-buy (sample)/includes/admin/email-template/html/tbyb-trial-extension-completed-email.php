<?php
if (!defined('ABSPATH')) {
	exit;
}

$Addify_TBYB_customer_name   = isset($new_form_data['customer_name']) ? $new_form_data['customer_name'] : esc_html__('there', 'addify-try-before-you-buy');
$Addify_TBYB_product_name    = isset($new_form_data['product']) ? $new_form_data['product'] : '';
$Addify_TBYB_additional_time = isset($new_form_data['additional_time']) ? $new_form_data['additional_time'] : '';
$Addify_TBYB_new_end_date    = isset($new_form_data['new_end_date']) ? $new_form_data['new_end_date'] : '';
$Addify_TBYB_extension_fee   = isset($new_form_data['extension_fee']) ? $new_form_data['extension_fee'] : '';
$Addify_TBYB_total_deposit   = isset($new_form_data['total_deposit']) ? $new_form_data['total_deposit'] : '';
$Addify_TBYB_original_deposit = isset($new_form_data['original_deposit']) ? $new_form_data['original_deposit'] : '';
$Addify_TBYB_blog_name       = esc_html(get_bloginfo('name'));
?>

<!DOCTYPE html>
<html>

<head>
	<meta charset="UTF-8">
	<style>
		body {
			font-family: Arial, sans-serif;
			line-height: 1.6;
			color: #333;
			max-width: 600px;
			margin: 0 auto;
			padding: 20px;
			background-color: #f9f9f9;
		}

		.email-container {
			background: #ffffff;
			border-radius: 12px;
			padding: 40px;
			box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
		}

		.header {
			text-align: center;
			margin-bottom: 30px;
			border-bottom: 2px solid #f0f0f0;
			padding-bottom: 25px;
		}

		.header h1 {
			color: #22c55e;
			margin: 0;
			font-size: 28px;
			font-weight: bold;
		}

		.content {
			margin-bottom: 30px;
		}

		.greeting {
			font-size: 18px;
			margin-bottom: 25px;
			color: #374151;
		}

		.extension-card {
			background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
			border: 2px solid #bbf7d0;
			padding: 25px;
			border-radius: 12px;
			margin: 25px 0;
			box-shadow: 0 2px 10px rgba(34, 197, 94, 0.1);
		}

		.extension-card h2 {
			margin-top: 0;
			color: #166534;
			font-size: 20px;
			display: flex;
			align-items: center;
			gap: 10px;
		}

		.detail-list {
			list-style: none;
			padding: 0;
			margin: 20px 0 0 0;
		}

		.detail-list li {
			padding: 12px 0;
			border-bottom: 1px solid #d1fae5;
			display: flex;
			justify-content: space-between;
			align-items: center;
		}

		.detail-list li:last-child {
			border-bottom: none;
		}

		.detail-label {
			font-weight: 600;
			color: #374151;
			min-width: 120px;
		}

		.detail-value {
			color: #166534;
			font-weight: 500;
			text-align: right;
		}

		.note-section {
			background: #fffbeb;
			border-left: 4px solid #f59e0b;
			padding: 20px;
			border-radius: 8px;
			margin: 25px 0;
		}

		.support-section {
			background: #eff6ff;
			border-left: 4px solid #3b82f6;
			padding: 20px;
			border-radius: 8px;
			margin: 25px 0;
		}

		.signature {
			text-align: center;
			margin-top: 40px;
			padding-top: 25px;
			border-top: 2px solid #f0f0f0;
		}

		.team-name {
			font-weight: bold;
			color: #374151;
			font-size: 16px;
		}

		.footer {
			text-align: center;
			margin-top: 30px;
			color: #6b7280;
			font-size: 14px;
		}

		.icon {
			margin-right: 8px;
			font-size: 18px;
		}
	</style>
</head>

<body>
	<div class="email-container">
		<div class="header">
			<h1>🎉 <?php esc_html_e('Trial Extended Successfully!', 'addify-try-before-you-buy'); ?></h1>
		</div>

		<div class="content">
			<div class="greeting">
				<p>
					<?php
					printf(
						// translators: %s shows the customer name.
						esc_html__('Great news, %s!', 'addify-try-before-you-buy'),
						'<strong>' . esc_html($Addify_TBYB_customer_name) . '</strong>'
					);
					?>
				</p>
				<p>
					<?php
					printf(
						// translators: %s shows the product name.
						esc_html__('Your trial for %s has been successfully extended.', 'addify-try-before-you-buy'),
						'<strong style="color: #166534;">' . esc_html($Addify_TBYB_product_name) . '</strong>'
					);
					?>
				</p>
			</div>

			<div class="extension-card">
				<h2><span class="icon">📅</span> <?php esc_html_e('Extended Trial Details', 'addify-try-before-you-buy'); ?></h2>

				<ul class="detail-list">
					<li>
						<span class="detail-label"><?php esc_html_e('Additional Time:', 'addify-try-before-you-buy'); ?></span>
						<span class="detail-value"><?php echo esc_html($Addify_TBYB_additional_time); ?></span>
					</li>
					<li>
						<span class="detail-label"><?php esc_html_e('New End Date:', 'addify-try-before-you-buy'); ?></span>
						<span class="detail-value"><?php echo esc_html($Addify_TBYB_new_end_date); ?></span>
					</li>
					<li>
						<span class="detail-label"><?php esc_html_e('Extension Fee:', 'addify-try-before-you-buy'); ?></span>
						<span class="detail-value"><?php echo esc_html($Addify_TBYB_extension_fee); ?></span>
					</li>
					<li>
						<span class="detail-label"><?php esc_html_e('Total Deposit:', 'addify-try-before-you-buy'); ?></span>
						<span class="detail-value"><?php echo wp_kses_post($Addify_TBYB_total_deposit); ?></span>
					</li>
					<li>
						<span class="detail-label"><?php esc_html_e('Breakdown:', 'addify-try-before-you-buy'); ?></span>
						<span class="detail-value" style="font-size: 14px;">
							<?php
							printf(
								// translators: %1$s is the original deposit, %2$s is the extension fee.
								esc_html__('original %1$s + extension %2$s', 'addify-try-before-you-buy'),
								wp_kses_post($Addify_TBYB_original_deposit),
								wp_kses_post($Addify_TBYB_extension_fee)
							);
							?>

						</span>
					</li>
				</ul>
			</div>

			<div class="note-section">
				<p><strong>💡 <?php esc_html_e('Enjoy Your Extended Trial!', 'addify-try-before-you-buy'); ?></strong></p>
				<p>
					<?php
					printf(
						// translators: %s shows days.
						esc_html__('You now have %s more days to thoroughly test your product! You can purchase or return your trial products at any time.', 'addify-try-before-you-buy'),
						'<strong>' . esc_html($Addify_TBYB_additional_time) . '</strong>'
					);
					?>
				</p>
			</div>

			<div class="support-section">
				<p><strong>❓ <?php esc_html_e('Need Assistance?', 'addify-try-before-you-buy'); ?></strong></p>
				<p><?php esc_html_e('If you have any questions about your extended trial or need help with your product, our support team is here to help!', 'addify-try-before-you-buy'); ?></p>
			</div>
		</div>

		<div class="signature">
			<p><?php esc_html_e('Happy Testing!', 'addify-try-before-you-buy'); ?></p>
			<p class="team-name"><?php echo esc_html($Addify_TBYB_blog_name); ?></p>
		</div>

		<div class="footer">
			<p><?php esc_html_e('Thank you for choosing our Try Before You Buy program.', 'addify-try-before-you-buy'); ?></p>
		</div>
	</div>
</body>

</html>