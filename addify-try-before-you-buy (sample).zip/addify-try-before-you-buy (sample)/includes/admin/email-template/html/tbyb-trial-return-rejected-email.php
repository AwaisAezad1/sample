<?php
if (!defined('ABSPATH')) {
	exit;
}

$Addify_TBYB_customer_name = isset($email_data['customer_name']) ? $email_data['customer_name'] : '';
$Addify_TBYB_products = isset($email_data['products']) ? json_decode($email_data['products'], true) : array();
// filter only rejected products
$Addify_TBYB_rejected_products = array_filter($Addify_TBYB_products, function ( $p ) {
	return isset($p['return_status']) && strtolower($p['return_status']) === 'rejected';
});
?>

<!DOCTYPE html>
<html>

<head>
	<meta charset="UTF-8">
	<style>
		body {
			font-family: Arial, sans-serif;
			line-height: 1.6;
			color: #333;
			max-width: 600px;
			margin: 0 auto;
			padding: 20px;
			background-color: #f9f9f9;
		}

		.email-container {
			background: #ffffff;
			border-radius: 8px;
			padding: 30px;
			box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
		}

		.header {
			text-align: center;
			margin-bottom: 30px;
			border-bottom: 2px solid #f0f0f0;
			padding-bottom: 20px;
		}

		.header h1 {
			color: #dc3545;
			margin: 0;
			font-size: 24px;
		}

		.content {
			margin-bottom: 30px;
		}

		.greeting {
			font-size: 16px;
			margin-bottom: 20px;
		}

		.decision-section {
			background: #f8d7da;
			border-left: 4px solid #dc3545;
			padding: 25px;
			border-radius: 4px;
			margin: 25px 0;
		}

		.product-details {
			background: #f8f9fa;
			border-left: 4px solid #6c757d;
			padding: 20px;
			border-radius: 4px;
			margin: 25px 0;
		}

		.detail-row {
			display: flex;
			justify-content: space-between;
			margin-bottom: 12px;
			padding: 8px 0;
			border-bottom: 1px solid #eee;
		}

		.detail-row:last-child {
			border-bottom: none;
		}

		.detail-label {
			font-weight: bold;
			color: #555;
			min-width: 150px;
		}

		.detail-value {
			color: #2c3e50;
		}

		.reason-section {
			background: #fff3cd;
			border-left: 4px solid #ffc107;
			padding: 20px;
			border-radius: 4px;
			margin: 25px 0;
		}

		.support-section {
			background: #e7f4ff;
			border-left: 4px solid #3498db;
			padding: 20px;
			border-radius: 4px;
			margin: 25px 0;
		}

		.signature {
			text-align: center;
			margin-top: 30px;
			padding-top: 20px;
			border-top: 2px solid #f0f0f0;
		}

		.team-name {
			font-weight: bold;
			color: #2c3e50;
		}

		.footer {
			text-align: center;
			margin-top: 30px;
			color: #7f8c8d;
			font-size: 14px;
		}
	</style>
</head>

<body>
	<div class="email-container">
		<div class="header">
			<h1>❌ <?php echo esc_html($email_heading); ?></h1>
		</div>

		<div class="content">
			<div class="greeting">
				<p>
					<?php
					printf(
						// translators: %s shows the customer name.
						esc_html__('Hello %s,', 'addify-try-before-you-buy'),
						'<strong>' . esc_html($Addify_TBYB_customer_name) . '</strong>'
					);
					?>
				</p>
			</div>

			<div class="decision-section">
				<h2 style="margin-top: 0; color: #721c24;"><?php esc_html_e('Return Request Decision', 'addify-try-before-you-buy'); ?></h2>
				<p><?php esc_html_e('After a thorough review of your request, we regret to inform you that your return has been declined.', 'addify-try-before-you-buy'); ?></p>
			</div>

			<?php if (!empty($Addify_TBYB_rejected_products)) : ?>
				<div class="product-details">
					<h3 style="margin-top: 0; color: #2c3e50;"><?php esc_html_e('Rejected Products', 'addify-try-before-you-buy'); ?></h3>

					<?php foreach ($Addify_TBYB_rejected_products as $Addify_TBYB_product) : ?>
						<div class="detail-row">
							<span class="detail-label"><?php esc_html_e('Order ID:', 'addify-try-before-you-buy'); ?></span>
							<span class="detail-value">#<?php echo esc_html($Addify_TBYB_product['order_id']); ?></span>
						</div>

						<div class="detail-row">
							<span class="detail-label"><?php esc_html_e('Product:', 'addify-try-before-you-buy'); ?></span>
							<span class="detail-value"><?php echo esc_html($Addify_TBYB_product['product']); ?></span>
						</div>

						<div class="detail-row">
							<span class="detail-label"><?php esc_html_e('Status:', 'addify-try-before-you-buy'); ?></span>
							<span class="detail-value" style="color: #dc3545;">❌ <?php esc_html_e('Rejected', 'addify-try-before-you-buy'); ?></span>
						</div>

						<?php if (!empty($Addify_TBYB_product['reason'])) : ?>
							<div class="detail-row">
								<span class="detail-label"><?php esc_html_e('Customer Reason:', 'addify-try-before-you-buy'); ?></span>
								<span class="detail-value"><?php echo esc_html($Addify_TBYB_product['reason']); ?></span>
							</div>
						<?php endif; ?>

						<?php if (!empty($Addify_TBYB_product['uploaded_file'])) : ?>
							<div class="detail-row">
								<span class="detail-label"><?php esc_html_e('Uploaded File:', 'addify-try-before-you-buy'); ?></span>
								<span class="detail-value"><a href="<?php echo esc_url($Addify_TBYB_product['uploaded_file']); ?>" target="_blank"><?php esc_html_e('View Attachment', 'addify-try-before-you-buy'); ?></a></span>
							</div>
						<?php endif; ?>

						<hr style="margin:20px 0;border:0;border-top:1px solid #eee;">
					<?php endforeach; ?>
				</div>
			<?php endif; ?>



			<div class="support-section">
				<h3 style="margin-top: 0; color: #004085;"><?php esc_html_e('Need Assistance?', 'addify-try-before-you-buy'); ?></h3>
				<p><?php esc_html_e('If you have any questions regarding this decision or would like to discuss possible alternatives, please reach out to our support team.', 'addify-try-before-you-buy'); ?></p>
				<p><?php esc_html_e('We are here to assist you further.', 'addify-try-before-you-buy'); ?></p>
			</div>
		</div>

		<div class="signature">
			<p><?php esc_html_e('Sincerely,', 'addify-try-before-you-buy'); ?></p>
			<p class="team-name"><?php echo esc_html(get_bloginfo('name')); ?></p>
		</div>

		<div class="footer">
			<p><?php esc_html_e('Thank you for your understanding.', 'addify-try-before-you-buy'); ?></p>
		</div>
	</div>
</body>

</html>