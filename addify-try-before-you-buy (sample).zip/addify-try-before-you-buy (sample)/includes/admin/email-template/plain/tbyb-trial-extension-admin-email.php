<?php
if (! defined('ABSPATH')) {
	exit;
}

$Addify_TBYB_customer_name = isset($new_form_data['customer_name']) ? $new_form_data['customer_name'] : '';
$Addify_TBYB_order_id      = isset($new_form_data['order_id']) ? $new_form_data['order_id'] : '';
$Addify_TBYB_blog_name     = esc_html(get_bloginfo('name'));
?>

<?php esc_html_e('📋 Trial Extension Request', 'addify-try-before-you-buy'); ?>


<?php esc_html_e('Hello Admin,', 'addify-try-before-you-buy'); ?>


=== ⏰ New Extension Request ===
<?php esc_html_e('A customer has submitted a trial extension request.', 'addify-try-before-you-buy'); ?>


Customer:
<?php echo esc_html($Addify_TBYB_customer_name); ?>


Order Reference:
#<?php echo esc_html($Addify_TBYB_order_id); ?>


📋 <?php esc_html_e('Action Required:', 'addify-try-before-you-buy'); ?>
<?php esc_html_e('Please review this request in the admin panel and take appropriate action.', 'addify-try-before-you-buy'); ?>


<?php esc_html_e('Thank you,', 'addify-try-before-you-buy'); ?>
<?php echo esc_html($Addify_TBYB_blog_name); ?>


<?php esc_html_e('This is an automated notification. Please do not reply to this email.', 'addify-try-before-you-buy'); ?>
