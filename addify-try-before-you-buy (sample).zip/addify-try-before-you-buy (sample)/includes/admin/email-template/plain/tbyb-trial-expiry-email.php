<?php
if (!defined('ABSPATH')) {
	exit;
}

$Addify_TBYB_customer_name   = isset($new_form_data['customer_name']) ? $new_form_data['customer_name'] : esc_html__('there', 'addify-try-before-you-buy');
$Addify_TBYB_products        = isset($new_form_data['products']) ? json_decode($new_form_data['products'], true) : array();
$Addify_TBYB_deposit         = isset($new_form_data['deposit']) ? $new_form_data['deposit'] : '';
$Addify_TBYB_order_id        = isset($new_form_data['order_id']) ? $new_form_data['order_id'] : '';
$Addify_TBYB_full_price      = isset($new_form_data['full_price']) ? $new_form_data['full_price'] : '';
$Addify_TBYB_time_remaining  = isset($new_form_data['time_remaining']) ? $new_form_data['time_remaining'] : '';
$Addify_TBYB_order_url       = wc_get_endpoint_url('view-order', $Addify_TBYB_order_id, wc_get_page_permalink('myaccount'));
$Addify_TBYB_blog_name       = esc_html(get_bloginfo('name'));
?>

<?php
// Subject
esc_html_e('Your Trial Expires Today!', 'addify-try-before-you-buy');
?>

<?php
printf(
	// translators: %s shows customer name.
	esc_html__('Hi %s,', 'addify-try-before-you-buy'),
	esc_html($Addify_TBYB_customer_name)
);
?>

<?php
printf(
	// translators: %s shows order id.
	esc_html__('Just a friendly reminder that your trial for order %s will expire at midnight tonight.', 'addify-try-before-you-buy'),
	'#' . esc_html($Addify_TBYB_order_id)
);
?>


=== Important Notice ===
Trial Ending: Tonight at 11:59 PM
Automatic Purchase: <?php echo wp_kses_post($Addify_TBYB_full_price); ?>
Deposit Paid: <?php echo wp_kses_post($Addify_TBYB_deposit); ?>


<?php esc_html_e('If no action is taken by midnight, the products will be automatically purchased at full price.', 'addify-try-before-you-buy'); ?>


<?php if (!empty($Addify_TBYB_products)) : ?>
Products in this trial:
<?php foreach ($Addify_TBYB_products as $Addify_TBYB_product) : ?>
- <?php echo esc_html($Addify_TBYB_product['product']); ?>
<?php endforeach; ?>
<?php endif; ?>


<?php if (!empty($Addify_TBYB_time_remaining)) : ?>
<?php
printf(
	// translators: %s shows days.
	esc_html__('Time remaining: %s', 'addify-try-before-you-buy'),
	esc_html($Addify_TBYB_time_remaining)
);
?>
<?php endif; ?>


Take action now:
- Purchase Now: <?php echo esc_url($Addify_TBYB_order_url); ?>
- Return Now: <?php echo esc_url($Addify_TBYB_order_url); ?>


=== Need Assistance? ===
<?php esc_html_e('If you have any questions or need help with your decision, please contact our support team. We\'re here to help!', 'addify-try-before-you-buy'); ?>


<?php esc_html_e('Best regards,', 'addify-try-before-you-buy'); ?>
<?php echo esc_html($Addify_TBYB_blog_name); ?>


<?php esc_html_e('Thank you for trying our products.', 'addify-try-before-you-buy'); ?>
