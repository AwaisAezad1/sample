<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$Addify_TBYB_customer_name = isset( $new_form_data['customer_name'] ) ? $new_form_data['customer_name'] : '';
$Addify_TBYB_order_id      = isset( $new_form_data['order_id'] ) ? $new_form_data['order_id'] : '';
$Addify_TBYB_products      = isset( $new_form_data['products'] ) ? json_decode( $new_form_data['products'], true ) : array();

// Separate kept and returned products
$Addify_TBYB_kept_products     = array();
$Addify_TBYB_returned_products = array();

foreach ( $Addify_TBYB_products as $Addify_TBYB_product ) {
	$Addify_TBYB_return_status = isset( $Addify_TBYB_product['return_status'] ) ? strtolower( $Addify_TBYB_product['return_status'] ) : '';

	if ( 'approved' === $Addify_TBYB_return_status ) {
		$Addify_TBYB_returned_products[] = $Addify_TBYB_product;
	} elseif (
		( isset( $Addify_TBYB_product['keep'] ) && 'yes' === $Addify_TBYB_product['keep'] )
		|| 'rejected' === $Addify_TBYB_return_status
		|| 'kept' === $Addify_TBYB_return_status
	) {
		$Addify_TBYB_kept_products[] = $Addify_TBYB_product;
	}
}

$Addify_TBYB_has_kept     = ! empty( $Addify_TBYB_kept_products );
$Addify_TBYB_has_returned = ! empty( $Addify_TBYB_returned_products );
?>

<?php echo '✅ ' . esc_html( $email_heading ) . "\n\n"; ?>

<?php
printf(
	// translators: %s shows the customer name.
	esc_html__( 'Hello %s,', 'addify-try-before-you-buy' ),
	esc_html( $Addify_TBYB_customer_name )
);
?>

<?php esc_html_e( 'Your Try Before You Buy trial has been completed. Here is the summary of the products from your trial:', 'addify-try-before-you-buy' ); ?>


<?php if ( $Addify_TBYB_has_kept ) : ?>
------------------------------------------------------------
🎉 <?php esc_html_e( 'Products You Kept', 'addify-try-before-you-buy' ); ?>

<?php esc_html_e( "We're thrilled that you decided to keep these products! They're now yours to keep - no need to return anything.", 'addify-try-before-you-buy' ); ?>


<?php foreach ( $Addify_TBYB_kept_products as $Addify_TBYB_product ) : ?>
- <?php echo esc_html( isset( $Addify_TBYB_product['product'] ) ? $Addify_TBYB_product['product'] : '' ); ?>  
  <?php echo wp_kses_post( $Addify_TBYB_product['display_price'] ); ?>

<?php endforeach; ?>
<?php endif; ?>


<?php if ( $Addify_TBYB_has_returned ) : ?>
------------------------------------------------------------
📦 <?php esc_html_e( 'Products You Returned', 'addify-try-before-you-buy' ); ?>

<?php esc_html_e( "We've received your return for the following products. Your refund will be processed according to our return policy.", 'addify-try-before-you-buy' ); ?>


<?php foreach ( $Addify_TBYB_returned_products as $Addify_TBYB_product ) : ?>
- <?php echo esc_html( isset( $Addify_TBYB_product['product'] ) ? $Addify_TBYB_product['product'] : '' ); ?>  
  <?php echo wp_kses_post( $Addify_TBYB_product['display_price'] ); ?>

<?php endforeach; ?>
<?php endif; ?>


------------------------------------------------------------
<?php esc_html_e( 'Order Details', 'addify-try-before-you-buy' ); ?>


<?php esc_html_e( 'Order ID:', 'addify-try-before-you-buy' ); ?> <?php echo esc_html( $Addify_TBYB_order_id ); ?>  
<?php esc_html_e( 'Order Date:', 'addify-try-before-you-buy' ); ?> <?php echo esc_html( date_i18n( get_option( 'date_format' ) ) ); ?>


------------------------------------------------------------
🙏 <?php esc_html_e( 'Thank you for trying our products! We hope you enjoyed the experience.', 'addify-try-before-you-buy' ); ?>

<?php esc_html_e( "We'll send you a receipt and warranty information shortly.", 'addify-try-before-you-buy' ); ?>


<?php esc_html_e( 'Best regards,', 'addify-try-before-you-buy' ); ?>  
<?php echo esc_html( get_bloginfo( 'name' ) ); ?>


------------------------------------------------------------
<?php esc_html_e( 'Thanks for trying before buying with us!', 'addify-try-before-you-buy' ); ?>

