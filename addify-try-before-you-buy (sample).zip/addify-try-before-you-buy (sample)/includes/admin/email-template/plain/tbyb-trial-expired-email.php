<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$Addify_TBYB_customer_name = isset( $new_form_data['customer_name'] ) ? $new_form_data['customer_name'] : '';
$Addify_TBYB_order_id      = isset( $new_form_data['order_id'] ) ? $new_form_data['order_id'] : '';
$Addify_TBYB_blog_name     = esc_html( get_bloginfo( 'name' ) );
?>

⏰ <?php echo esc_html( $email_heading ) . "\n\n"; ?>

<?php
printf(
	/* translators: %s: Customer name */
	esc_html__( 'Hi %s,', 'addify-try-before-you-buy' ),
	esc_html( $Addify_TBYB_customer_name )
);
echo "\n\n";
?>

⚠️ <?php esc_html_e( 'Trial Period Expired', 'addify-try-before-you-buy' ); ?>  
<?php esc_html_e( 'Your trial period has officially ended.', 'addify-try-before-you-buy' ); ?>


------------------------------------------------------------
<?php esc_html_e( 'Order Reference:', 'addify-try-before-you-buy' ); ?>  
#<?php echo esc_html( $Addify_TBYB_order_id ); ?>


------------------------------------------------------------
❓ <?php esc_html_e( 'What happens next?', 'addify-try-before-you-buy' ); ?>  
<?php esc_html_e( 'You can request for a refund for your expired order if applicable. Contact our support team if you have any questions.', 'addify-try-before-you-buy' ); ?>


------------------------------------------------------------
<?php esc_html_e( 'Thank you,', 'addify-try-before-you-buy' ); ?>  
<?php echo esc_html($Addify_TBYB_blog_name); ?>


------------------------------------------------------------
<?php esc_html_e( 'We appreciate your business.', 'addify-try-before-you-buy' ); ?>
