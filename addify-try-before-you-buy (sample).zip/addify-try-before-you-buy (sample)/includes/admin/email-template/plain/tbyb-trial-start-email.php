<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$Addify_TBYB_customer_name  = isset( $new_form_data['customer_name'] ) ? $new_form_data['customer_name'] : esc_html__( 'there', 'addify-try-before-you-buy' );
$Addify_TBYB_product_name   = isset( $new_form_data['product'] ) ? $new_form_data['product'] : '';
$Addify_TBYB_trial_period   = isset( $new_form_data['trial_period'] ) ? $new_form_data['trial_period'] : '';
$Addify_TBYB_trial_start    = isset( $new_form_data['begin'] ) ? $new_form_data['begin'] : '';
$Addify_TBYB_trial_end      = isset( $new_form_data['ends'] ) ? $new_form_data['ends'] : '';
$Addify_TBYB_deposit        = isset( $new_form_data['deposit'] ) ? $new_form_data['deposit'] : '';
$Addify_TBYB_track_url      = isset( $new_form_data['track_url'] ) ? $new_form_data['track_url'] : '#';
$Addify_TBYB_blog_name      = esc_html( get_bloginfo( 'name' ) );

// translators: %s = customer name.
printf( esc_html__( 'Hi %s,', 'addify-try-before-you-buy' ), esc_html($Addify_TBYB_customer_name) );

echo "\n\n";

// translators: %s = product name.
printf( esc_html__( 'Great news! Your trial for %s has officially begun.', 'addify-try-before-you-buy' ), esc_html($Addify_TBYB_product_name) );

echo "\n\n" . wp_kses_post(str_repeat( '=', 40 )) . "\n";
echo esc_html__( 'Trial Details', 'addify-try-before-you-buy' ) . "\n";
echo wp_kses_post(str_repeat( '=', 40 )) . "\n";

echo esc_html__( 'Product:', 'addify-try-before-you-buy' ) . ' ' . esc_html($Addify_TBYB_product_name) . "\n";
echo esc_html__( 'Trial Period:', 'addify-try-before-you-buy' ) . ' ' . esc_html($Addify_TBYB_trial_period) . "\n";
echo esc_html__( 'Started:', 'addify-try-before-you-buy' ) . ' ' . esc_html($Addify_TBYB_trial_start) . "\n";
echo esc_html__( 'Ends:', 'addify-try-before-you-buy' ) . ' ' . esc_html($Addify_TBYB_trial_end) . "\n";

printf(
	// translators: %s = deposit amount.
	esc_html__( 'Deposit: %s (refundable)', 'addify-try-before-you-buy' ),
	esc_html($Addify_TBYB_deposit)
);

echo "\n\n";
echo esc_html__( '🚚 Shipping Information', 'addify-try-before-you-buy' ) . "\n";
echo esc_html__( "Your product is being shipped and will arrive within 2–3 business days. Once you receive it, you'll have the full trial period to test it out!", 'addify-try-before-you-buy' );

echo "\n\n";
echo esc_html__( '📦 Track Your Trial Package:', 'addify-try-before-you-buy' ) . "\n";
echo esc_url( $Addify_TBYB_track_url );

echo "\n\n";
echo esc_html__( '💡 Need Help?', 'addify-try-before-you-buy' ) . "\n";
echo esc_html__( "Questions? Reply to this email or contact our support team. We're here to help you make the most of your trial!", 'addify-try-before-you-buy' );

echo "\n\n";
echo esc_html__( 'Happy Testing!', 'addify-try-before-you-buy' ) . "\n";
echo esc_html($Addify_TBYB_blog_name) . "\n\n";

echo esc_html__( 'Thank you for choosing our Try Before You Buy program.', 'addify-try-before-you-buy' ) . "\n";
