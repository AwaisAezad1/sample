<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$Addify_TBYB_customer_name = isset( $email_data['customer_name'] ) ? $email_data['customer_name'] : '';
$Addify_TBYB_products      = isset( $email_data['products'] ) ? json_decode( $email_data['products'], true ) : array();

// Separate products by status
$Addify_TBYB_approved_products = array_filter(
	$Addify_TBYB_products,
	function ( $p ) {
		return isset( $p['return_status'] ) && strtolower( $p['return_status'] ) === 'approved';
	}
);

$Addify_TBYB_rejected_products = array_filter(
	$Addify_TBYB_products,
	function ( $p ) {
		return isset( $p['return_status'] ) && strtolower( $p['return_status'] ) === 'rejected';
	}
);

$Addify_TBYB_kept_products = array_filter(
	$Addify_TBYB_products,
	function ( $p ) {
		return isset( $p['return_status'] ) && strtolower( $p['return_status'] ) === 'kept';
	}
);

echo '==== ' . esc_html( $email_heading ) . " ====\n\n";

// Greeting
printf(
	// translators: %s shows the customer name.
	esc_html__( 'Hello %s,', 'addify-try-before-you-buy' ),
	esc_html( $Addify_TBYB_customer_name )
);
echo "\n\n";

// Completion message
esc_html_e( 'Return Process Complete', 'addify-try-before-you-buy' );
echo "\n";
esc_html_e( 'We have completed the review of all your return requests. Below is a summary of the decisions made for each product in your order.', 'addify-try-before-you-buy' );
echo "\n\n";

// Approved products section
if ( ! empty( $Addify_TBYB_approved_products ) ) {
	esc_html_e( 'Approved Returns:', 'addify-try-before-you-buy' );
	echo "\n\n";

	foreach ( $Addify_TBYB_approved_products as $Addify_TBYB_product ) {
		echo esc_html__( 'Product:', 'addify-try-before-you-buy' ) . ' ' . esc_html( $Addify_TBYB_product['product'] ) . "\n";
		echo esc_html__( 'Status:', 'addify-try-before-you-buy' ) . ' ' . esc_html__( 'Approved', 'addify-try-before-you-buy' ) . "\n";

		if ( ! empty( $Addify_TBYB_product['reason'] ) ) {
			echo esc_html__( 'Reason:', 'addify-try-before-you-buy' ) . ' ' . esc_html( $Addify_TBYB_product['reason'] ) . "\n";
		}

		echo "-------------------------\n";
	}
	echo "\n";
}

// Rejected products section
if ( ! empty( $Addify_TBYB_rejected_products ) ) {
	esc_html_e( 'Rejected Returns:', 'addify-try-before-you-buy' );
	echo "\n\n";

	foreach ( $Addify_TBYB_rejected_products as $Addify_TBYB_product ) {
		echo esc_html__( 'Product:', 'addify-try-before-you-buy' ) . ' ' . esc_html( $Addify_TBYB_product['product'] ) . "\n";
		echo esc_html__( 'Status:', 'addify-try-before-you-buy' ) . ' ' . esc_html__( 'Rejected', 'addify-try-before-you-buy' ) . "\n";

		if ( ! empty( $Addify_TBYB_product['reason'] ) ) {
			echo esc_html__( 'Reason:', 'addify-try-before-you-buy' ) . ' ' . esc_html( $Addify_TBYB_product['reason'] ) . "\n";
		}

		echo "-------------------------\n";
	}
	echo "\n";
}

// Kept products section
if ( ! empty( $Addify_TBYB_kept_products ) ) {
	esc_html_e( 'Kept Products:', 'addify-try-before-you-buy' );
	echo "\n\n";

	foreach ( $Addify_TBYB_kept_products as $Addify_TBYB_product ) {
		echo esc_html__( 'Product:', 'addify-try-before-you-buy' ) . ' ' . esc_html( $Addify_TBYB_product['product'] ) . "\n";
		echo esc_html__( 'Status:', 'addify-try-before-you-buy' ) . ' ' . esc_html__( 'Kept', 'addify-try-before-you-buy' ) . "\n";

		echo "-------------------------\n";
	}
	echo "\n";
}

// What happens next section
esc_html_e( 'What Happens Next?', 'addify-try-before-you-buy' );
echo "\n";

if ( ! empty( $Addify_TBYB_approved_products ) ) {
	esc_html_e( 'For approved returns: Please prepare the items for return according to our return policy. You will receive further instructions regarding the return process.', 'addify-try-before-you-buy' );
	echo "\n";
}

if ( ! empty( $Addify_TBYB_rejected_products ) ) {
	esc_html_e( 'For rejected returns: These items will remain in your possession and payment will be processed according to your original agreement.', 'addify-try-before-you-buy' );
	echo "\n";
}

if ( ! empty( $Addify_TBYB_kept_products ) ) {
	esc_html_e( 'For kept products: Payment will be processed for these items as per your original agreement.', 'addify-try-before-you-buy' );
	echo "\n";
}

echo "\n";

// Support section
esc_html_e( 'Need Assistance?', 'addify-try-before-you-buy' );
echo "\n";
esc_html_e( 'If you have any questions about the return process or need assistance, please contact our support team.', 'addify-try-before-you-buy' );
echo "\n";
esc_html_e( 'We are here to help make your experience as smooth as possible.', 'addify-try-before-you-buy' );
echo "\n\n";

// Signature
esc_html_e( 'Sincerely,', 'addify-try-before-you-buy' );
echo "\n";
echo esc_html( get_bloginfo( 'name' ) ) . "\n\n";

// Footer
esc_html_e( 'Thank you for your business.', 'addify-try-before-you-buy' );
echo "\n";
