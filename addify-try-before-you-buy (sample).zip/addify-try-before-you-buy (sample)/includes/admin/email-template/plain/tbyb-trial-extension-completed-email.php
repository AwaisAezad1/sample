<?php
if (!defined('ABSPATH')) {
	exit;
}

$Addify_TBYB_customer_name    = isset($new_form_data['customer_name']) ? $new_form_data['customer_name'] : esc_html__('there', 'addify-try-before-you-buy');
$Addify_TBYB_product_name     = isset($new_form_data['product']) ? $new_form_data['product'] : '';
$Addify_TBYB_additional_time  = isset($new_form_data['additional_time']) ? $new_form_data['additional_time'] : '';
$Addify_TBYB_new_end_date     = isset($new_form_data['new_end_date']) ? $new_form_data['new_end_date'] : '';
$Addify_TBYB_extension_fee    = isset($new_form_data['extension_fee']) ? $new_form_data['extension_fee'] : '';
$Addify_TBYB_total_deposit    = isset($new_form_data['total_deposit']) ? $new_form_data['total_deposit'] : '';
$Addify_TBYB_original_deposit = isset($new_form_data['original_deposit']) ? $new_form_data['original_deposit'] : '';
$Addify_TBYB_blog_name        = esc_html(get_bloginfo('name'));
?>


🎉 <?php esc_html_e('Trial Extended Successfully!', 'addify-try-before-you-buy'); ?>


<?php
printf(
	// translators: %s shows the customer name.
	esc_html__('Great news, %s!', 'addify-try-before-you-buy'),
	esc_html($Addify_TBYB_customer_name)
);
?>


<?php
printf(
	// translators: %s shows the product name.
	esc_html__('Your trial for %s has been successfully extended.', 'addify-try-before-you-buy'),
	esc_html($Addify_TBYB_product_name)
);
?>


=== 📅 <?php esc_html_e('Extended Trial Details', 'addify-try-before-you-buy'); ?> ===

<?php esc_html_e('Additional Time:', 'addify-try-before-you-buy'); ?>  <?php echo esc_html($Addify_TBYB_additional_time); ?>

<?php esc_html_e('New End Date:', 'addify-try-before-you-buy'); ?>  <?php echo esc_html($Addify_TBYB_new_end_date); ?>

<?php esc_html_e('Extension Fee:', 'addify-try-before-you-buy'); ?>  <?php echo esc_html($Addify_TBYB_extension_fee); ?>

<?php esc_html_e('Total Deposit:', 'addify-try-before-you-buy'); ?>  <?php echo wp_kses_post($Addify_TBYB_total_deposit); ?>


<?php
printf(
	// translators: %1$s is the original deposit, %2$s is the extension fee.
	esc_html__('Breakdown: original %1$s + extension %2$s', 'addify-try-before-you-buy'),
	wp_kses_post($Addify_TBYB_original_deposit),
	wp_kses_post($Addify_TBYB_extension_fee)
);
?>


💡 <?php esc_html_e('Enjoy Your Extended Trial!', 'addify-try-before-you-buy'); ?>

<?php
printf(
	// translators: %s shows days.
	esc_html__('You now have %s more days to thoroughly test your product! You can purchase or return your trial products at any time.', 'addify-try-before-you-buy'),
	esc_html($Addify_TBYB_additional_time)
);
?>


❓ <?php esc_html_e('Need Assistance?', 'addify-try-before-you-buy'); ?>

<?php esc_html_e('If you have any questions about your extended trial or need help with your product, our support team is here to help!', 'addify-try-before-you-buy'); ?>


<?php esc_html_e('Happy Testing!', 'addify-try-before-you-buy'); ?>

<?php echo esc_html($Addify_TBYB_blog_name); ?>


<?php esc_html_e('Thank you for choosing our Try Before You Buy program.', 'addify-try-before-you-buy'); ?>
