<?php
if (! defined('ABSPATH')) {
	exit;
}

$Addify_TBYB_customer_name = isset($new_form_data['customer_name']) ? $new_form_data['customer_name'] : '';
$Addify_TBYB_order_id      = isset($new_form_data['order_id']) ? $new_form_data['order_id'] : '';
$Addify_TBYB_request_date  = isset($new_form_data['request_date']) ? $new_form_data['request_date'] : date_i18n('F j, Y');
$Addify_TBYB_blog_name     = esc_html(get_bloginfo('name'));
?>

<?php
// Subject: Trial Extension Request Confirmation
?>

<?php
printf(
	// translators: %s shows the customer name.
	esc_html__('Hi %s,', 'addify-try-before-you-buy'),
	esc_html($Addify_TBYB_customer_name)
);
?>

<?php echo esc_html__('Thank you for submitting a trial extension request. We\'ve received your request and our team will review it shortly.', 'addify-try-before-you-buy'); ?>


<?php echo esc_html__('Order Information:', 'addify-try-before-you-buy'); ?>

<?php
echo esc_html__('Order Number:', 'addify-try-before-you-buy') . ' #' . esc_html($Addify_TBYB_order_id) . "\n";
echo esc_html__('Request Date:', 'addify-try-before-you-buy') . ' ' . esc_html($Addify_TBYB_request_date) . "\n";
echo esc_html__('Current Status:', 'addify-try-before-you-buy') . ' ' . esc_html__('Under Review', 'addify-try-before-you-buy') . "\n";
?>


<?php echo esc_html__('Please wait while the admin approves your trial extension request.', 'addify-try-before-you-buy'); ?>


<?php echo esc_html__('What Happens Next?', 'addify-try-before-you-buy'); ?>

- <?php echo esc_html__('Our team will review your extension request', 'addify-try-before-you-buy'); ?>

- <?php echo esc_html__('You\'ll receive an email notification once a decision is made', 'addify-try-before-you-buy'); ?>

- <?php echo esc_html__('If approved, your trial period will be extended accordingly', 'addify-try-before-you-buy'); ?>


<?php echo esc_html__('If you have any questions, please contact our support team.', 'addify-try-before-you-buy'); ?>


---
<?php echo esc_html($Addify_TBYB_blog_name); ?>

<?php echo esc_html__('This is an automated message. Please do not reply to this email.', 'addify-try-before-you-buy'); ?>

© <?php echo wp_kses_post(gmdate('Y')); ?> <?php echo esc_html($Addify_TBYB_blog_name); ?>. <?php echo esc_html__('All rights reserved.', 'addify-try-before-you-buy'); ?>
