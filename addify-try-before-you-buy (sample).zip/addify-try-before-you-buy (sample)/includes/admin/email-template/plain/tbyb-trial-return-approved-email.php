<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$Addify_TBYB_customer_name = isset( $email_data['customer_name'] ) ? $email_data['customer_name'] : '';
$Addify_TBYB_products      = isset( $email_data['products'] ) ? json_decode( $email_data['products'], true ) : array();

// Filter only approved products
$Addify_TBYB_approved_products = array_filter(
	$Addify_TBYB_products,
	function ( $p ) {
		return isset( $p['return_status'] ) && strtolower( $p['return_status'] ) === 'approved';
	}
);

echo '==== ' . esc_html( $email_heading ) . " ====\n\n";

// Greeting
printf(
	// translators: %s shows the customer name.
	esc_html__( 'Hello %s,', 'addify-try-before-you-buy' ),
	esc_html( $Addify_TBYB_customer_name )
);
echo "\n\n";

// Decision
esc_html_e( 'Return Request Decision', 'addify-try-before-you-buy' );
echo "\n";
esc_html_e( 'Great news! We have reviewed your return request and are pleased to inform you that it has been approved.', 'addify-try-before-you-buy' );
echo "\n\n";

// Approved products section
if ( ! empty( $Addify_TBYB_approved_products ) ) {
	esc_html_e( 'Approved Products:', 'addify-try-before-you-buy' );
	echo "\n\n";

	foreach ( $Addify_TBYB_approved_products as $Addify_TBYB_product ) {
		echo esc_html__( 'Order ID:', 'addify-try-before-you-buy' ) . ' #' . esc_html( $Addify_TBYB_product['order_id'] ) . "\n";
		echo esc_html__( 'Product:', 'addify-try-before-you-buy' ) . ' ' . esc_html( $Addify_TBYB_product['product'] ) . "\n";
		echo esc_html__( 'Status:', 'addify-try-before-you-buy' ) . ' ' . esc_html__( 'Approved', 'addify-try-before-you-buy' ) . "\n";

		if ( ! empty( $Addify_TBYB_product['reason'] ) ) {
			echo esc_html__( 'Customer Reason:', 'addify-try-before-you-buy' ) . ' ' . esc_html( $Addify_TBYB_product['reason'] ) . "\n";
		}

		if ( ! empty( $Addify_TBYB_product['uploaded_file'] ) ) {
			echo esc_html__( 'Uploaded File:', 'addify-try-before-you-buy' ) . ' ' . esc_url( $Addify_TBYB_product['uploaded_file'] ) . "\n";
		}

		echo "-------------------------\n";
	}
	echo "\n";
}

// Next steps section
esc_html_e( 'Next Steps', 'addify-try-before-you-buy' );
echo "\n";
esc_html_e( 'Please prepare the approved items for return according to our return policy. You will receive further instructions regarding the return process shortly.', 'addify-try-before-you-buy' );
echo "\n";
esc_html_e( 'Once we receive your returned items, we will process your refund according to our standard timeline.', 'addify-try-before-you-buy' );
echo "\n\n";

// Support section
esc_html_e( 'Need Assistance?', 'addify-try-before-you-buy' );
echo "\n";
esc_html_e( 'If you have any questions about the return process or need assistance with shipping, please contact our support team.', 'addify-try-before-you-buy' );
echo "\n";
esc_html_e( 'We are here to help make your return experience as smooth as possible.', 'addify-try-before-you-buy' );
echo "\n\n";

// Signature
esc_html_e( 'Sincerely,', 'addify-try-before-you-buy' );
echo "\n";
echo esc_html( get_bloginfo( 'name' ) ) . "\n\n";

// Footer
esc_html_e( 'Thank you for choosing us.', 'addify-try-before-you-buy' );
echo "\n";
