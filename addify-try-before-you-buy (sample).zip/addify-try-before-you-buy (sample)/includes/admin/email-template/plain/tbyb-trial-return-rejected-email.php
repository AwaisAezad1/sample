<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$Addify_TBYB_customer_name = isset( $email_data['customer_name'] ) ? $email_data['customer_name'] : '';
$Addify_TBYB_products      = isset( $email_data['products'] ) ? json_decode( $email_data['products'], true ) : array();

// Filter only rejected products
$Addify_TBYB_rejected_products = array_filter(
	$Addify_TBYB_products,
	function ( $p ) {
		return isset( $p['return_status'] ) && strtolower( $p['return_status'] ) === 'rejected';
	}
);

echo '==== ' . esc_html( $email_heading ) . " ====\n\n";

// Greeting
printf(
	// translators: %s shows the customer name.
	esc_html__( 'Hello %s,', 'addify-try-before-you-buy' ),
	esc_html( $Addify_TBYB_customer_name )
);
echo "\n\n";

// Decision
esc_html_e( 'Return Request Decision', 'addify-try-before-you-buy' );
echo "\n";
esc_html_e( 'After a thorough review of your request, we regret to inform you that your return has been declined.', 'addify-try-before-you-buy' );
echo "\n\n";

// Rejected products section
if ( ! empty( $Addify_TBYB_rejected_products ) ) {
	esc_html_e( 'Rejected Products:', 'addify-try-before-you-buy' );
	echo "\n\n";

	foreach ( $Addify_TBYB_rejected_products as $Addify_TBYB_product ) {
		echo esc_html__( 'Order ID:', 'addify-try-before-you-buy' ) . ' #' . esc_html( $Addify_TBYB_product['order_id'] ) . "\n";
		echo esc_html__( 'Product:', 'addify-try-before-you-buy' ) . ' ' . esc_html( $Addify_TBYB_product['product'] ) . "\n";
		echo esc_html__( 'Status:', 'addify-try-before-you-buy' ) . ' ' . esc_html__( 'Rejected', 'addify-try-before-you-buy' ) . "\n";

		if ( ! empty( $Addify_TBYB_product['reason'] ) ) {
			echo esc_html__( 'Customer Reason:', 'addify-try-before-you-buy' ) . ' ' . esc_html( $Addify_TBYB_product['reason'] ) . "\n";
		}

		if ( ! empty( $Addify_TBYB_product['uploaded_file'] ) ) {
			echo esc_html__( 'Uploaded File:', 'addify-try-before-you-buy' ) . ' ' . esc_url( $Addify_TBYB_product['uploaded_file'] ) . "\n";
		}

		echo "-------------------------\n";
	}
	echo "\n";
}

// Support section
esc_html_e( 'Need Assistance?', 'addify-try-before-you-buy' );
echo "\n";
esc_html_e( 'If you have any questions regarding this decision or would like to discuss possible alternatives, please reach out to our support team.', 'addify-try-before-you-buy' );
echo "\n";
esc_html_e( 'We are here to assist you further.', 'addify-try-before-you-buy' );
echo "\n\n";

// Signature
esc_html_e( 'Sincerely,', 'addify-try-before-you-buy' );
echo "\n";
echo esc_html( get_bloginfo( 'name' ) ) . "\n\n";

// Footer
esc_html_e( 'Thank you for your understanding.', 'addify-try-before-you-buy' );
echo "\n";
