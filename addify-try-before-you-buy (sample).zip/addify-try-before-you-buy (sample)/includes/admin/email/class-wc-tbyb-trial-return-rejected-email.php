<?php
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}

class WC_TBYB_Trial_Return_Rejected_Email extends WC_Email {

	public function __construct() {
		$this->id             = 'tbyb_return_rejected_email';
		$this->customer_email = true;
		$this->title          = esc_html__('TBYB Return Rejected (Customer)', 'addify-try-before-you-buy');
		$this->description    = esc_html__('This email is sent to the customer when their return request is rejected.', 'addify-try-before-you-buy');
		$this->subject        = esc_html__('Your return request has been reviewed', 'addify-try-before-you-buy');
		$this->heading        = esc_html__('Return Request Update', 'addify-try-before-you-buy');
		$this->template_base  = AD_TBYB_DIR;
		$this->template_html  = 'includes/admin/email-template/html/tbyb-trial-return-rejected-email.php';
		$this->template_plain = 'includes/admin/email-template/plain/tbyb-trial-return-rejected-email.php';

		$this->placeholders   = array();

		add_action('addify_tbyb_return_rejected', array( $this, 'trigger' ), 10, 1);

		parent::__construct();
	}

	public function trigger( $email_data ) {
		$this->setup_locale();

		if (empty($email_data['customer_email'])) {
			return;
		}

		$this->recipient      = $email_data['customer_email'];
		$this->placeholders   = $email_data;

		if (!$this->is_enabled() || !$this->get_recipient()) {
			return;
		}

		$this->send(
			$this->get_recipient(),
			$this->get_subject(),
			$this->get_content(),
			$this->get_headers(),
			$this->get_attachments()
		);

		$this->restore_locale();
	}

	public function get_content_html() {
		return wc_get_template_html(
			$this->template_html,
			array(
				'email_data' => $this->placeholders,
				'email_heading' => $this->get_heading(),
			),
			'',
			$this->template_base
		);
	}

	public function get_content_plain() {
		return wc_get_template(
			$this->template_plain,
			array(
				'email_data' => $this->placeholders,
				'email_heading' => $this->get_heading(),
			),
			'',
			$this->template_base
		);
	}
}
