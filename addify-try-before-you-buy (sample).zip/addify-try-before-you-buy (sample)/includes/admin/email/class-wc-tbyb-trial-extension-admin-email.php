<?php
if (!defined('ABSPATH')) {
	exit;
}

class WC_TBYB_Trial_Extension_Email_Admin extends WC_Email {

	public function __construct() {
		$this->id             = 'tbyb_trial_extension_email_admin';
		$this->title          = esc_html__('TBYB Trial Extension Admin Notification', 'addify-try-before-you-buy');
		$this->description    = esc_html__('This email is sent to the site admin when a customer requests a TBYB trial extension.', 'addify-try-before-you-buy');
		$this->subject        = esc_html__('New trial extension request from {customer_name}', 'addify-try-before-you-buy');
		$this->heading        = esc_html__('Trial Extension Request', 'addify-try-before-you-buy');

		$this->template_base  = AD_TBYB_DIR;
		$this->template_html  = 'includes/admin/email-template/html/tbyb-trial-extension-admin-email.php';
		$this->template_plain = 'includes/admin/email-template/plain/tbyb-trial-extension-admin-email.php';

		$this->placeholders   = array();

		add_action('addify_tbyb_trial_extension_request_admin', array( $this, 'trigger' ), 10, 1);

		parent::__construct();

		// Send to admin email by default
		$this->recipient = get_option('admin_email');
	}

	public function trigger( $data ) {
		$this->setup_locale();

		if (empty($this->recipient)) {
			return;
		}

		$this->placeholders = $data;

		// Replace placeholders in subject
		if (!empty($data['customer_name'])) {
			$this->subject = str_replace('{customer_name}', $data['customer_name'], $this->subject);
		}

		if (!$this->is_enabled() || !$this->get_recipient()) {
			return;
		}

		$this->send(
			$this->get_recipient(),
			$this->get_subject(),
			$this->get_content(),
			$this->get_headers(),
			$this->get_attachments()
		);

		$this->restore_locale();
	}

	public function get_content_html() {
		return wc_get_template_html(
			$this->template_html,
			array(
				'new_form_data' => $this->placeholders,
				'email_heading' => $this->get_heading(),
			),
			'',
			$this->template_base
		);
	}

	public function get_content_plain() {
		return wc_get_template(
			$this->template_plain,
			array(
				'new_form_data' => $this->placeholders,
				'email_heading' => $this->get_heading(),
			),
			'',
			$this->template_base
		);
	}
}
