<?php
if (!defined('ABSPATH')) {
	exit;
}

class WC_TBYB_Trial_Extension_Completion_Email extends WC_Email {

	public function __construct() {
		$this->id             = 'tbyb_trial_extension_completed_email';
		$this->title          = esc_html__('TBYB Trial Extension Completion Notification', 'addify-try-before-you-buy');
		$this->description    = esc_html__('This email is sent to customers when their TBYB trial extension is approved.', 'addify-try-before-you-buy');
		$this->subject        = esc_html__('Your trial extension request has been approved', 'addify-try-before-you-buy');
		$this->heading        = esc_html__('Trial Extension Request Approved', 'addify-try-before-you-buy');

		$this->template_base  = AD_TBYB_DIR;
		$this->template_html  = 'includes/admin/email-template/html/tbyb-trial-extension-completed-email.php';
		$this->template_plain = 'includes/admin/email-template/plain/tbyb-trial-extension-completed-email.php';

		$this->placeholders   = array();

		add_action('addify_tbyb_trial_extension_completed_status', array( $this, 'trigger' ), 10, 1);

		parent::__construct();

		$this->recipient = '';
	}

	public function trigger( $data ) {
		$this->setup_locale();

		if (empty($data['customer_email'])) {
			return;
		}
		$this->recipient = sanitize_email($data['customer_email']);
		$this->placeholders = $data;
		if (!$this->is_enabled() || !$this->get_recipient()) {
			return;
		}

		$this->send(
			$this->get_recipient(),
			$this->get_subject(),
			$this->get_content(),
			$this->get_headers(),
			$this->get_attachments()
		);

		$this->restore_locale();
	}

	public function get_content_html() {
		return wc_get_template_html(
			$this->template_html,
			array(
				'new_form_data' => $this->placeholders,
				'email_heading' => $this->get_heading(),
			),
			'',
			$this->template_base
		);
	}

	public function get_content_plain() {
		return wc_get_template(
			$this->template_plain,
			array(
				'new_form_data' => $this->placeholders,
				'email_heading' => $this->get_heading(),
			),
			'',
			$this->template_base
		);
	}
}
