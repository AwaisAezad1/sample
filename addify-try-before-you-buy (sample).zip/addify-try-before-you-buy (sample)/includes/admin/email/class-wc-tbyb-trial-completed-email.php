<?php
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}

class WC_TBYB_Trial_Completed_Email extends WC_Email {


	public function __construct() {
		$this->id             = 'tbyb_trial_completed_email';
		$this->customer_email = true;
		$this->title          = esc_html__('TBYB Trial Completed (Customer)', 'addify-try-before-you-buy');
		$this->description    = esc_html__('This email is sent to the customer when a Try Before You Buy trial completes.', 'addify-try-before-you-buy');
		$this->subject        = esc_html__('Your trial has been completed!', 'addify-try-before-you-buy');
		$this->heading        = esc_html__('Try Before You Buy - Trial Completed', 'addify-try-before-you-buy');
		$this->template_base  = AD_TBYB_DIR;
		$this->template_html  = 'includes/admin/email-template/html/tbyb-trial-completed-email.php';
		$this->template_plain = 'includes/admin/email-template/plain/tbyb-trial-completed-email.php';

		$this->placeholders   = array();

		add_action('addify_tbyb_trial_completed', array( $this, 'trigger' ), 10, 1);

		parent::__construct();
	}

	public function trigger( $new_form_data ) {
		$this->setup_locale();
		if (empty($new_form_data['customer_email'])) {
			return;
		}

		$this->recipient      = $new_form_data['customer_email'];
		$this->placeholders   = $new_form_data;

		if (!$this->is_enabled() || !$this->get_recipient()) {
			return;
		}

		$this->send(
			$this->get_recipient(),
			$this->get_subject(),
			$this->get_content(),
			$this->get_headers(),
			$this->get_attachments()
		);

		$this->restore_locale();
	}

	public function get_content_html() {
		return wc_get_template_html(
			$this->template_html,
			array(
				'new_form_data' => $this->placeholders,
				'email_heading' => $this->get_heading(),
			),
			'',
			$this->template_base
		);
	}

	public function get_content_plain() {
		return wc_get_template(
			$this->template_plain,
			array(
				'new_form_data' => $this->placeholders,
				'email_heading' => $this->get_heading(),
			),
			'',
			$this->template_base
		);
	}
}
