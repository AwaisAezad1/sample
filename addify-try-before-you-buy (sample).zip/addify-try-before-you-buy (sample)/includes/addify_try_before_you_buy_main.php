<?php

if (!defined('ABSPATH')) {
	exit();
}

if (!class_exists('Addify_TBYB_Main')) {
	class Addify_TBYB_Main {
	









		
		public function include_files() {

			include_once AD_TBYB_DIR . 'includes/admin/meta-box/try_before_you_buy_adding_meta_box.php';
			include_once AD_TBYB_DIR . 'includes/front/try_before_you_buy_my_account_left_tab.php';
			include_once AD_TBYB_DIR . 'includes/front/try_before_you_buy_product_page.php';
			include_once AD_TBYB_DIR . 'includes/front/try_before_you_buy_cart_page.php';
			include_once AD_TBYB_DIR . 'includes/front/try_before_you_buy_checkout_page.php';
		}

		// Populate custom columns
		public function addify_trial_log_tab_column_content( $column, $post_id ) {
			$trial_status   = '-';
			$start_date     = '-';
			$end_date       = '-';
			$username       = '-';
			$useremail      = '-';
			$return_reason  = '-';
			$return_status  = '-';

			$post_product_name = html_entity_decode(get_the_title($post_id), ENT_QUOTES, 'UTF-8');
			$order_id = get_post_meta($post_id, 'addify_TBYB_order_id', true);
			if (empty($order_id)) {
return;
			}

			$order = wc_get_order($order_id);
			if (!$order) {
return;
			}

			$user_id = get_post_field('post_author', $post_id);
			if ($user_id) {
				$user_data = get_user_by('ID', $user_id);
				if ($user_data) {
					$username = $user_data->user_login;
					$useremail = $user_data->user_email;
				}
			}

			// Get trial products data from order
			$trial_products = $order->get_meta('addify_TBYB_trial_products');

			if (!isset($trial_products)) {
return;
			}

			foreach ($trial_products as $trial_product) {
				// Skip if no product
				$product_id = isset($trial_product['product_id']) ? $trial_product['product_id'] : 0;
				if (!$product_id) {
continue;
				}

				$trial_product_name = $trial_product['product'];
				if (!empty($trial_product['product_variation_data'])) {
					$attrs = array();
					foreach ($trial_product['product_variation_data'] as $key => $value) {
						$key_clean = str_replace(array( 'attribute_pa_', 'attribute_' ), '', $key);
						$attrs[] = ucfirst($key_clean) . ': ' . $value;
					}
					$trial_product_name .= ' - ' . implode(', ', $attrs);
				}

				$normalized_post_name    = $this->normalize_dashes($post_product_name);
				$normalized_trial_name   = $this->normalize_dashes($trial_product_name);

				if (trim($normalized_trial_name) == trim($normalized_post_name)) {

					$start_date    = isset($trial_product['start']) ? $trial_product['start'] : '-';
					$end_date      = isset($trial_product['end']) ? $trial_product['end'] : '-';
					$return_reason = isset($trial_product['reason']) ? $trial_product['reason'] : '-';
					$trial_status = isset($trial_product['status']) ? $trial_product['status'] : '-';
					$trial_return_status = isset($trial_product['return_status']) ? $trial_product['return_status'] : '-';


					if ('' == $return_reason) {
						$return_reason = '-';
					}
					if ('Kept' === $trial_status) {
						$return_status = '-';
					} else {
						$order_has_capture = ! empty($order->get_meta('addify_TBYB_total_capture_charge'));

						if ($order_has_capture && 'yes' == $order->get_meta('addify_TBYB_payment_auto_captured')) {
							$trial_status = esc_html__('Automatically Captured', 'addify-try-before-you-buy');
						} else {
								$return_status = ! empty($trial_return_status) ? $trial_return_status : '-';
						}
					}
					break;
				}
			}

			// Output column content
			switch ($column) {
				case 'order_id':
					echo '<a href="' . esc_url(admin_url('post.php?post=' . $order_id . '&action=edit')) . '" target="_blank">'
						. esc_html('#' . $order_id) .
						'</a>';
					break;
				case 'customer_name':
					echo esc_html($username);
					break;
				case 'email':
					echo esc_html($useremail);
					break;
				case 'trial_start':
					echo esc_html(date_i18n(get_option('date_format'), strtotime($start_date)));
					break;
				case 'trial_end':
					echo esc_html(date_i18n(get_option('date_format'), strtotime($end_date)));
					break;
				case 'status':
					echo esc_html($trial_status);
					break;
				case 'return_reason':
					$max_length = 50;
					echo esc_html(strlen($return_reason) > $max_length ? substr($return_reason, 0, $max_length) . '...' : $return_reason);
					break;
				case 'return_status':
					echo esc_html($return_status);
					break;
			}
		}

		private function normalize_dashes( $string ) {
			$string = str_replace(array( '–', '—' ), '-', $string);
			$string = preg_replace('/\s+/', ' ', $string); // remove extra spaces
			return trim($string);
		}

		// Add custom columns to 'payout_post'
		public function addify_trial_log_tab_custom_columns( $columns ) {

			$new_columns = array();

			foreach ($columns as $key => $value) {
				if ('date' === $key) {
					// Remove 'date' column
					continue;
				}
				// Change 'title' to 'Product Name'
				if ('title' === $key) {
					$new_columns[ $key ] = esc_html__('Product Name', 'addify-try-before-you-buy');
					$new_columns['order_id'] = esc_html__('Order ID', 'addify-try-before-you-buy');
					$new_columns['customer_name'] = esc_html__('Customer Name', 'addify-try-before-you-buy');
					$new_columns['email'] = esc_html__('Email', 'addify-try-before-you-buy');
					$new_columns['trial_start'] = esc_html__('Trial Start', 'addify-try-before-you-buy');
					$new_columns['trial_end'] = esc_html__('Trial End', 'addify-try-before-you-buy');
					$new_columns['status'] = esc_html__('Trial Status', 'addify-try-before-you-buy');
					$new_columns['return_reason'] = esc_html__('Return Reason', 'addify-try-before-you-buy');
					$new_columns['return_status'] = esc_html__('Return Status', 'addify-try-before-you-buy');
				} else {
					$new_columns[ $key ] = $value;
				}
			}
			return $new_columns;
		}
		public function register_post_types() {
			// Post Type 1: Rule Settings
			$rule_labels = array(
				'name' => esc_html__('Rule', 'addify-try-before-you-buy'),
				'singular_name' => esc_html__('Rule', 'addify-try-before-you-buy'),
				'add_new' => esc_html__('Add New Rule', 'addify-try-before-you-buy'),
				'add_new_item' => esc_html__('Add Rule', 'addify-try-before-you-buy'),
				'edit_item' => esc_html__('Edit Rule', 'addify-try-before-you-buy'),
				'new_item' => esc_html__('New Rule', 'addify-try-before-you-buy'),
				'view_item' => esc_html__('View Rule', 'addify-try-before-you-buy'),
				'search_items' => esc_html__('Search Rule', 'addify-try-before-you-buy'),
				'not_found' => esc_html__('No rule found', 'addify-try-before-you-buy'),
				'not_found_in_trash' => esc_html__('No rule found in trash', 'addify-try-before-you-buy'),
				'menu_name' => esc_html__('Try Before You Buy', 'addify-try-before-you-buy'),
			);
			$rule_args = array(
				'labels' => $rule_labels,
				'public' => false,
				'publicly_queryable' => false,
				'show_ui' => true,
				'show_in_menu' => 'woocommerce',
				'query_var' => true,
				'capability_type' => 'post',
				'has_archive' => false,
				'hierarchical' => false,
				'supports' => array( 'title', 'page-attributes' ),
				'rewrite' => false,
			);

			register_post_type('trial_rule_tab', $rule_args);


			// Post Type 2: Log Settings
			$log_labels = array(
				'name' => esc_html__('Trial Log', 'addify-try-before-you-buy'),
				'singular_name' => esc_html__('Trial Log', 'addify-try-before-you-buy'),
				'add_new' => esc_html__('Add New Log', 'addify-try-before-you-buy'),
				'add_new_item' => esc_html__('Add Log', 'addify-try-before-you-buy'),
				'edit_item' => esc_html__('Edit Log', 'addify-try-before-you-buy'),
				'new_item' => esc_html__('New Log', 'addify-try-before-you-buy'),
				'view_item' => esc_html__('View Log', 'addify-try-before-you-buy'),
				'search_items' => esc_html__('Search Log', 'addify-try-before-you-buy'),
				'not_found' => esc_html__('No Log found', 'addify-try-before-you-buy'),
				'not_found_in_trash' => esc_html__('No Log found in trash', 'addify-try-before-you-buy'),
				'menu_name' => esc_html__('Try Before You Buy', 'addify-try-before-you-buy'),
			);
			$log_args = array(
				'labels' => $log_labels,
				'public' => false,
				'publicly_queryable' => false,
				'show_ui' => true,
				'show_in_menu' => 'woocommerce',
				'query_var' => true,
				'capability_type' => 'post',
				'capabilities' => array(
					'create_posts' => 'do_not_allow',
				),
				'map_meta_cap' => true,
				'has_archive' => false,
				'hierarchical' => false,
				'supports' => array( 'title', 'page-attributes' ),
				'rewrite' => false,
			);

			register_post_type('trial_log_tab', $log_args);
		}
	}
	new Addify_TBYB_Main();
}
