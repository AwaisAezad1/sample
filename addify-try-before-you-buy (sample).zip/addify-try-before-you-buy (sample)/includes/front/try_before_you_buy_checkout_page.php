<?php

if (!defined('ABSPATH')) {
	exit();
}

if (!class_exists('Addify_TBYB_Checkout_Page')) :
	class Addify_TBYB_Checkout_Page {
	

















		public function __construct() {
		
			// Start
			// Stripe specific hooks implementation for manual capture in block editor
			add_filter('wc_stripe_payment_request_capture', '__return_false');
			add_filter('wc_stripe_force_save_payment_method', '__return_true');
			add_filter('wc_stripe_payment_intent_params', function ( $params, $order ) {
				$params['capture_method'] = 'manual';
				return $params;
			}, 10, 2);
			add_action('rest_api_init', function () {
				register_rest_route('custom-stripe/v1', '/attach-method', array(
					'methods' => 'POST',
					'callback' => 'Addify_TBYB_custom_attach_payment_method',
					'permission_callback' => '__return_true',
				));
			});

			function Addify_TBYB_custom_attach_payment_method( $request ) {
				require_once AD_TBYB_DIR . '/vendor/autoload.php';

				$params = $request->get_json_params();
				$payment_method_id = sanitize_text_field($params['payment_method_id']);
				$customer_id = sanitize_text_field($params['customer_id']);
				$stripe_data = get_option('woocommerce_stripe_settings');
				$test_mode = !empty($stripe_data['testmode']) &&  'yes' === $stripe_data['testmode'];
				$stripe_secret = $test_mode ? $stripe_data['test_secret_key'] : $stripe_data['secret_key'];
				\Stripe\Stripe::setApiKey($stripe_secret);
				try {
					$payment_method = \Stripe\PaymentMethod::retrieve($payment_method_id);
					$payment_method->attach(array( 'customer' => $customer_id ));

					return array( 'success' => true );
				} catch (\Exception $e) {
					return new WP_REST_Response(array(
						'success' => false,
						'message' => $e->getMessage(),
					), 500);
				}
			}
			// Stripe specific hooks implementation for manual capture in block editor
			// End
		}
		public function addify_checkout_create_order_line_item( $item, $cart_item_key, $values, $order ) {
			if (!empty($values['addify_try_before_buy'])) {
				$item->add_meta_data(esc_html__('Trial Product', 'addify-try-before-you-buy'), 'Yes', true);
			}
		}
		public function addify_tbyb_trial_email( $email_classes ) {
			include_once AD_TBYB_DIR . 'includes/admin/email/class-wc-tbyb-trial-completed-email.php';
			include_once AD_TBYB_DIR . 'includes/admin/email/class-wc-tbyb-trial-expired-email.php';
			include_once AD_TBYB_DIR . 'includes/admin/email/class-wc-tbyb-trial-expiry-email.php';
			include_once AD_TBYB_DIR . 'includes/admin/email/class-wc-tbyb-trial-extension-email.php';
			include_once AD_TBYB_DIR . 'includes/admin/email/class-wc-tbyb-trial-extension-completed-email.php';
			include_once AD_TBYB_DIR . 'includes/admin/email/class-wc-tbyb-trial-extension-admin-email.php';
			include_once AD_TBYB_DIR . 'includes/admin/email/class-wc-tbyb-trial-start-email.php';
			include_once AD_TBYB_DIR . 'includes/admin/email/class-wc-tbyb-trial-return-rejected-email.php';
			include_once AD_TBYB_DIR . 'includes/admin/email/class-wc-tbyb-trial-return-approved-email.php';
			include_once AD_TBYB_DIR . 'includes/admin/email/class-wc-tbyb-trial-return-completed-email.php';
			$email_classes['WC_TBYB_Trial_Completed_Email'] = new WC_TBYB_Trial_Completed_Email();
			$email_classes['WC_TBYB_Trial_Expired_Email'] = new WC_TBYB_Trial_Expired_Email();
			$email_classes['WC_TBYB_Trial_Expiry_Email'] = new WC_TBYB_Trial_Expiry_Email();
			$email_classes['WC_TBYB_Trial_Extension_Email'] = new WC_TBYB_Trial_Extension_Email();
			$email_classes['WC_TBYB_Trial_Extension_Completion_Email'] = new WC_TBYB_Trial_Extension_Completion_Email();
			$email_classes['WC_TBYB_Trial_Extension_Email_Admin'] = new WC_TBYB_Trial_Extension_Email_Admin();
			$email_classes['WC_TBYB_Trial_Start_Email'] = new WC_TBYB_Trial_Start_Email();
			$email_classes['WC_TBYB_Trial_Return_Rejected_Email'] = new WC_TBYB_Trial_Return_Rejected_Email();
			$email_classes['WC_TBYB_Trial_Return_Approved_Email'] = new WC_TBYB_Trial_Return_Approved_Email();
			$email_classes['WC_TBYB_Trial_Return_Completed_Email'] = new WC_TBYB_Trial_Return_Completed_Email();
			return $email_classes;
		}


		public function addify_restrict_payment_checkout_order_processed( $order_id ) {
			$order = wc_get_order($order_id);
			if (!$order) {
				return;
			}
			// --- Check order status (failed payments)
			if ($order->has_status('failed')) {
				$order->add_order_note('Order failed, skipping trial product payment method save.');
				return;
			}
			// Check if trial product exists
			$has_trial_product = false;
			foreach ($order->get_items() as $item) {
				if (strtolower($item->get_meta('Trial Product')) === 'yes') {
					$has_trial_product = true;
					break;
				}
			}

			if ($has_trial_product) {
				$payment_method = $order->get_payment_method();
				if (in_array($payment_method, array( 'stripe', 'paypal', 'ppcp-gateway' ), true)) {
					$order->update_meta_data('addify_TBYB_trial_products_order_payment_method', $payment_method);
					$order->save();
				}
			}
		}
		public function cookie_destroy_after_order( $order_id ) {
			$order = wc_get_order($order_id);

			$payment_method = $order->get_meta('addify_TBYB_trial_products_order_payment_method');

			// --- Check order status (failed payments)
			if ($order->has_status('failed')) {
				$order->add_order_note('Order failed, skipping trial product payment method save.');
				return;
			}

			// Only proceed for supported payment methods
			if (!in_array($payment_method, array( 'stripe', 'ppcp-gateway' ), true)) {
				return;
			}

			$valid_statuses = get_option('Addify_TBYB_trial_status', array( 'wc-processing' ));
			if (!empty($trial_status) && !in_array('wc-' . $order->get_status(), (array) $trial_status, true)) {
				return;
			} elseif (empty($valid_statuses)) {
				return;
			}

			// Get trial period using min/max logic (same as product page)
			$trial_min_max_setting = get_option('Addify_TBYB_trial_min_max', 'min');

			// Ensure we have a string value, not an array
			if (is_array($trial_min_max_setting)) {
				$trial_min_max_setting = isset($trial_min_max_setting[0]) ? $trial_min_max_setting[0] : 'min';
			}

			// Ensure it's a valid value
			if (!in_array($trial_min_max_setting, array( 'min', 'max' ))) {
				$trial_min_max_setting = 'min';
			}

			// Collect trial periods from all enabled rules
			$applicable_trial_periods = array();
			$args_posts = array(
				'post_type' => 'trial_rule_tab',
				'orderby' => 'menu_order',
				'order' => 'ASC',
				'posts_per_page' => -1,
			);

			$query = new WP_Query($args_posts);
			if ($query->have_posts()) {
				while ($query->have_posts()) {
					$query->the_post();
					$post_id = get_the_ID();
					$enable_rule = get_post_meta($post_id, 'Addify_TBYB_enablerule', true);
					if ($enable_rule) {
						// Get trial period from this rule
						$rule_trial_period = get_post_meta($post_id, 'Addify_TBYB_trial_period', true);
						if (empty($rule_trial_period)) {
							$rule_trial_period = 7; // default 7 days
						}
						$applicable_trial_periods[] = intval($rule_trial_period);
					}
				}
				wp_reset_postdata();
			}

			// Apply min/max trial period logic
			if (!empty($applicable_trial_periods)) {
				if ('min' === $trial_min_max_setting) {
					$trial_days = min($applicable_trial_periods);
				} else {
					$trial_days = max($applicable_trial_periods);
				}
			} else {
				$trial_days = 7; // default 7 days
			}

			$trial_days = $trial_days > 0 ? $trial_days : 7;

			$start_date = gmdate('Y-m-d');
			$end_date = gmdate('Y-m-d', strtotime("+$trial_days days"));

			$user_id = get_current_user_id();
			$option_key = 'addify_TBYB_trial_products_' . $user_id;
			$order_id = $order->get_id();
			$existing_data = get_option($option_key, array());
			if (!isset($existing_data[ $order_id ]) || !is_array($existing_data[ $order_id ])) {
				$existing_data[ $order_id ] = array();
			}

			$total_price = 0;
			$trial_products = array();

			$order_items         = $order->get_items();

			$trial_product_ids   = array(); // Only trial-marked product IDs from the order
			$ordered_product_ids = array(); // All product IDs from the order
			$trial_item_count    = 0; // Count of trial items

			foreach ($order_items as $item) {
				$product_id = $item->get_product_id();
				$ordered_product_ids[] = $product_id;

				// Check if item has Trial Product meta
				$is_trial = $item->get_meta('Trial Product');
				if (is_string($is_trial) && strtolower($is_trial) === 'yes') {
					$trial_product_ids[] = $product_id;
					$trial_item_count++;
				}
			}

			// Calculate shipping cost per trial product
			$total_shipping = $order->get_shipping_total();
			$shipping_per_trial_product = $trial_item_count > 0 ? $total_shipping / $trial_item_count : 0;
			foreach ($_COOKIE as $cookie_name => $cookie_value) {
				if (0 === strpos($cookie_name, 'addify_try_now_data_')) {
					$data = json_decode(stripslashes($cookie_value), true);
					if (!empty($data['product_id'])) {
						$product_variation_data = array();
						$product_id  = !empty($data['variation_id']) && $data['variation_id'] > 0 ? $data['variation_id'] : $data['product_id'];
						$product     = wc_get_product($product_id);
						if ($product) {
							// For variable products, allow proper attribute-based matching
							$parent_id = $product->is_type('variation') ? $product->get_parent_id() : $product->get_id();
							$found_match = false;
							// Get COOKIE attributes
							$cookie_attrs = !empty($data['attributes']) ? $data['attributes'] : array();
							foreach ($order_items as $item) {
								$item_product = $item->get_product();
								if (!$item_product) {
continue;
								}
								$item_parent_id = $item_product->is_type('variation') ? $item_product->get_parent_id() : $item_product->get_id();
								// ✅ PARENT must match first
								if ($parent_id !== $item_parent_id) {
									continue;
								}
								// ✅ Retrieve ORDER item attributes
								$order_attrs = wc_get_order_item_meta($item->get_id(), '', true);
								$clean_order_attrs = array();
								foreach ($order_attrs as $k => $v) {
									if (strpos($k, 'attribute_') === 0) {
										$clean_order_attrs[ $k ] = $v;
									}
								}
								// ✅ Compare attributes (allow "Any")
								$attr_match = true;
								foreach ($cookie_attrs as $attr_key => $cookie_val) {
									if (!isset($clean_order_attrs[ $attr_key ])) {
										continue; // order item does not have this attribute
									}
									$order_val = $clean_order_attrs[ $attr_key ];
									// ✅ ALLOW "Any" on either side
									if ('' == $cookie_val || 'any' ==strtolower($cookie_val)) {
										continue;
									}
									if ('' == $order_val || 'any' == strtolower($order_val)) {
										continue;
									}
									// ✅ MUST MATCH if neither is "any"
									if (strtolower($cookie_val) !== strtolower($order_val)) {
										$attr_match = false;
										break;
									}
								}
								if ($attr_match) {
									$product_variation_data = $cookie_attrs;
									$found_match = true;
									break;
								}
							}
							if (!$found_match) {
								continue;
							}
							$entry = array(
								'id'            => $order_id,
								'order_id'      => (string) $order_id,
								'product'       => $product->get_name(),
								'product_id'    => $product->is_type('variation') ? $product->get_parent_id() : $product->get_id(),
								'variation_id'  => $product->is_type('variation') ? $product->get_id() : 0,
								'product_variation_data'  => $product_variation_data,
								'start'         => $start_date,
								'end'           => $end_date,
								'display_price' => wc_price($product->get_price()),
								'price'         => $product->get_price(),
								'shipping_cost' => $shipping_per_trial_product,
								'status'        => 'In Process',
								'reason'        => '',
							);
							$existing_data[ $order_id ][] = $entry;
							$trial_products[]           = $entry;
							$total_price += floatval($product->get_price());
						}
					}
				}
			}



			update_option($option_key, $existing_data);

			$trial_fee_charge = get_option('Addify_TBYB_trial_fee_charge', 0.5);
			if ($trial_fee_charge > 0) {
				$total_price += $trial_fee_charge;
			}
			$order->update_meta_data('addify_TBYB_trial_days', $trial_days);
			$order->update_meta_data('addify_TBYB_total_price', $total_price);

			foreach ($_COOKIE as $cookie_name => $cookie_value) {
				if (strpos($cookie_name, 'addify_try_now_data_') === 0) {
					setcookie($cookie_name, '', time() - 3600, COOKIEPATH, COOKIE_DOMAIN);
				}
			}

			if (!empty($valid_statuses) && is_array($valid_statuses)) {
				if (in_array('wc-' . $order->get_status(), $valid_statuses, true)) {
					$order->update_meta_data('addify_TBYB_trial_initialize_paypal', 'yes');
					$order->save_meta_data();
				} else {
					$order->update_meta_data('addify_TBYB_trial_initialize_paypal', 'no');
					$order->save_meta_data();
				}
			} else {
				$order->update_meta_data('addify_TBYB_trial_initialize_paypal', 'no');
				$order->save_meta_data();
			}

			if (!empty($trial_products) && $total_price > 0) {
				$user = get_user_by('id', $user_id);
				$email = $user ? $user->user_email : '';
				$customer_name = $user ? $user->display_name : '';
				// Payment-specific logic
				if ('stripe' === $payment_method) {
					$stripe_data = get_option('woocommerce_stripe_settings');
					$stripe_secret = ( isset($stripe_data['testmode']) ? $stripe_data['testmode'] : 'no' ) === 'yes' ? $stripe_data['test_secret_key'] : $stripe_data['secret_key'];
					$is_stripe = $order->get_payment_method() === 'stripe';
					$payment_method_id = $order->get_meta('_stripe_payment_method');
					if (!$payment_method_id) {
						$payment_method_id = $order->get_meta('_stripe_source_id');
					}
					if ($is_stripe && $payment_method_id) {
						$customer_id = null;
						$resp = wp_remote_post('https://api.stripe.com/v1/customers', array(
							'method'  => 'POST',
							'headers' => array( 'Authorization' => 'Bearer ' . $stripe_secret ),
							'body'    => array( 'email' => $email ),
						));

						$customer_data = json_decode(wp_remote_retrieve_body($resp), true);
						$customer_id = isset($customer_data['id']) ? $customer_data['id'] : null;

						if ($customer_id) {
							$pm_resp = wp_remote_get("https://api.stripe.com/v1/payment_methods/$payment_method_id", array(
								'headers' => array( 'Authorization' => 'Bearer ' . $stripe_secret ),
							));

							$pm_data = json_decode(wp_remote_retrieve_body($pm_resp), true);
							$attached_id = isset($pm_data['customer']) ? $pm_data['customer'] : null;

							if (!$attached_id) {
								wp_remote_post("https://api.stripe.com/v1/payment_methods/$payment_method_id/attach", array(
									'method'  => 'POST',
									'headers' => array( 'Authorization' => 'Bearer ' . $stripe_secret ),
									'body'    => array( 'customer' => $customer_id ),
								));
							} else {
								$customer_id = $attached_id;
							}

							$amount = intval(round($total_price * 100));

							$intent_resp = wp_remote_post('https://api.stripe.com/v1/payment_intents', array(
								'method'  => 'POST',
								'headers' => array( 'Authorization' => 'Bearer ' . $stripe_secret ),
								'body'    => array(
									'amount'         => $amount,
									'currency'       => get_woocommerce_currency(),
									'customer'       => $customer_id,
									'payment_method' => $payment_method_id,
									'off_session'    => 'true',
									'confirm'        => 'true',
									'capture_method' => 'manual',
								),
							));

							$intent_data = json_decode(wp_remote_retrieve_body($intent_resp), true);
							$intent_id = isset($intent_data['id']) ? $intent_data['id'] : null;

							if (!$intent_id) {
								wc_clear_notices();
								wc_add_notice(esc_html__('PaymentIntent creation failed.', 'addify-try-before-you-buy'), 'error');
								return;
							}

							$order->update_meta_data('addify_TBYB_stripe_customer_id', $customer_id);
							$order->update_meta_data('addify_TBYB_stripe_payment_intent', $intent_id);
							$order->add_order_note('Stripe PaymentIntent created: ' . $intent_id);
							$order->save();
						}
						$this->add_trial_log($order, $user_id, $existing_data, $order_id, $email, $customer_name, $trial_days, $start_date, $end_date);
					}
				} elseif ('ppcp-gateway' === $payment_method) {
					// Get PayPal bearer access token from transient
					$bearer_object = json_decode(get_option('_transient_ppcp-paypal-bearerppcp-bearer'));
					if (!$bearer_object || empty($bearer_object->access_token)) {
						$order->add_order_note('PayPal: Failed to retrieve bearer token.');
						return;
					}
					$paypal_common_data = get_option('woocommerce-ppcp-data-common');
					$bearer_access_token = $bearer_object->access_token;
					$use_sandbox = $paypal_common_data['use_sandbox'];
					$currency = $order->get_currency();
					if ($total_price <= 0) {
						$order->add_order_note('PayPal: No trial amount to charge.');
						return;
					}
					$paypal_api_url = $use_sandbox ? 'https://api-m.sandbox.paypal.com' : 'https://api-m.paypal.com';
					//  Create PayPal Order
					$create_order_response = wp_remote_post("$paypal_api_url/v2/checkout/orders", array(
						'headers' => array(
							'Authorization' => "Bearer $bearer_access_token",
							'Content-Type'  => 'application/json',
						),
						'body' => json_encode(array(
							'intent' => 'AUTHORIZE',
							'purchase_units' => array(
								array(
									'amount' => array(
										'currency_code' => $currency,
										'value' => number_format($total_price, 2, '.', ''),
									),
									'description' => 'Trial product authorization for Order #' . $order->get_id(),
									'custom_id' => (string) $order->get_id(), // So we can recover it on return
								),
							),
							'application_context' => array(
								'return_url' => site_url('/paypal-return'),
								'cancel_url' => site_url('/paypal-cancel'),
							),
						)),
					));
					$product_names = array();

					if (!empty($existing_data[ $order_id ])) {
						foreach ($existing_data[ $order_id ] as $item) {
							if (!empty($item['product_id'])) {
								$product = wc_get_product($item['product_id']);
								if ($product) {
									$product_names[] = $product->get_name();
								}
							}
						}
					}
					if (is_wp_error($create_order_response)) {
						$order->add_order_note('PayPal: Order creation failed - ' . $create_order_response->get_error_message());
						return;
					}

					$create_order_body = json_decode(wp_remote_retrieve_body($create_order_response), true);
					// Store trial data in order meta
					$order->update_meta_data('addify_TBYB_trial_products_names', $product_names);
					$order->update_meta_data('addify_TBYB_trial_total_price', $total_price);
					$order->update_meta_data('addify_TBYB_trial_products', $existing_data[ $order_id ]);
					$order->update_meta_data('addify_TBYB_trial_products_user_id', $user_id);
					$order->save();



					$this->add_trial_log($order, $user_id, $existing_data, $order_id, $email, $customer_name, $trial_days, $start_date, $end_date);

					//  Redirect user to approve the payment
					foreach ($create_order_body['links'] as $link) {
						if ('approve' === $link['rel']) {
							wp_safe_redirect($link['href']);
							return;
						}
					}
				}
				$this->reset_order_product_prices_to_default($order);
			}
		}
		/**
		 * Reset all product prices in an order to their default WooCommerce prices.
		 *
		 * @param int|WC_Order $order Order ID or order object.
		 */
		private function reset_order_product_prices_to_default( $order ) {
			// Get order object if ID is passed
			if (is_numeric($order)) {
				$order = wc_get_order($order);
			}

			if (!$order instanceof WC_Order) {
				return;
			}
			// Loop through line items
			foreach ($order->get_items('line_item') as $item_id => $item) {
				$product = $item->get_product();

				if ($product && $product->exists()) {
					// Reset to default product price
					$regular_price = $product->get_regular_price();
					$sale_price    = $product->get_sale_price();
					$price         = $product->is_on_sale() ? $sale_price : $regular_price;

					// Update item subtotal and total
					$quantity = $item->get_quantity();
					$item->set_subtotal($price * $quantity);
					$item->set_total($price * $quantity);
					$item->save();
				}
			}

			// Recalculate taxes and totals
			$order->calculate_totals();
			$order->save();
		}

		private function add_trial_log( $order, $user_id, $existing_data, $order_id, $email, $customer_name, $trial_days, $start_date, $end_date ) {

			// Check allowed statuses
			$trial_status = get_option('Addify_TBYB_trial_status', array( 'wc-processing' ));

			if (!empty($trial_status) && !in_array('wc-' . $order->get_status(), (array) $trial_status, true)) {
				return;
			} elseif (empty($trial_status)) {
				return;
			}

			foreach ($order->get_items() as $item_id => $item) {

				$product_obj   = $item->get_product();
				$product_id    = $item->get_product_id();
				$variation_id  = $item->get_variation_id();

				if (!$product_obj) {
					$product_name = 'Trial Product';
				} else {

					// ✅ Base product name
					if ($product_obj->is_type('variation')) {
						$parent_id   = $product_obj->get_parent_id();
						$parent_obj  = wc_get_product($parent_id);
						$base_name   = $parent_obj ? $parent_obj->get_name() : $product_obj->get_name();
					} else {
						$base_name = $product_obj->get_name();
					}

					// ✅ Get attributes FROM ORDER ITEM META (CORRECT WAY)
					$meta_data = $item->get_meta_data();
					$attr_parts = array();

					foreach ($meta_data as $meta) {
						$key   = $meta->key;
						$value = $meta->value;

						// Skip internal meta
						if (in_array($key, array( 'Trial Product' ), true)) {
							continue;
						}

						// ✅ WooCommerce attribute keys stored in order item:
						// pa_color, size, logo, attribute_pa_color, attribute_color, etc.
						if (strpos($key, 'attribute_') === 0) {
							$clean_key = str_replace('attribute_', '', $key);
							$label = wc_attribute_label($clean_key, $product_obj);
							$attr_parts[] = $label . ': ' . $value;
						} elseif (taxonomy_exists($key) || strpos($key, 'pa_') === 0) {
							// pa_color → Color
							$label = wc_attribute_label($key, $product_obj);
							$attr_parts[] = $label . ': ' . $value;
						} elseif (!empty($value)) {
							// Non-taxonomy custom attribute
							$attr_parts[] = ucfirst($key) . ': ' . $value;
						}
					}

					// ✅ Final product name with attributes
					if (!empty($attr_parts)) {
						$product_name = $base_name . ' - ' . implode(', ', $attr_parts);
					} else {
						$product_name = $base_name;
					}
				}

				$cart_variation_data = array();

				// Get variation attributes from order item meta
				$meta_data = $item->get_meta_data();
				foreach ($meta_data as $meta) {
					$key = $meta->key;
					$value = $meta->value;

					if (strpos($key, 'attribute_') === 0) {
						$clean_key = str_replace('attribute_', '', $key);
						$cart_variation_data[ $clean_key ] = $value;
					}
				}

				// ✅ Check for existing logs
				$existing_posts = get_posts(array(
					'post_type'      => 'trial_log_tab',
					'posts_per_page' => 50,
					'fields'         => 'ids',
				));

				$found_existing = false;

				if (!empty($existing_posts)) {

					foreach ($existing_posts as $log_id) {

						$log_order_id = get_post_meta($log_id, 'addify_TBYB_order_id', true);
						if ((string) $log_order_id !== (string) $order_id) {
							continue;
						}

						// Get saved trial items for this existing log
						$order = wc_get_order($log_order_id);
						$trial_products = $order->get_meta('addify_TBYB_trial_products');

						// Ensure trial_products is always an array
						if (!is_array($trial_products)) {
							continue;
						}

						foreach ($trial_products as $trial_item) {

							// Ensure trial_item is array
							if (!is_array($trial_item)) {
								continue;
							}

							$id_match =
								( $variation_id && ( isset($trial_item['variation_id']) ? $trial_item['variation_id'] : '' ) ) == $variation_id  ||
								( !$variation_id && ( isset($trial_item['product_id'] ) ? $trial_item['product_id']  : '' ) == $product_id );
							if (!$id_match) {
								continue;
							}

							$saved_attrs = isset($trial_item['product_variation_data']) && is_array($trial_item['product_variation_data'])
								? $trial_item['product_variation_data']
								: array();

							$new_attrs = is_array($cart_variation_data) ? $cart_variation_data : array();

							// Normalize and sort
							$saved_attrs = array_change_key_case($saved_attrs, CASE_LOWER);
							$new_attrs   = array_change_key_case($new_attrs, CASE_LOWER);
							ksort($saved_attrs);
							ksort($new_attrs);

							if ($saved_attrs === $new_attrs) {
								$found_existing = true;
								break 2; // exit both foreach loops
							}
						}
					}
				}



				// ✅ Create log if not found
				if (!$found_existing) {

					$trial_log_id = wp_insert_post(array(
						'post_type'   => 'trial_log_tab',
						'post_status' => 'publish',
						'post_title'  => $product_name,
						'post_author' => $user_id,
					));

					if ($trial_log_id && !is_wp_error($trial_log_id)) {

						update_post_meta($trial_log_id, 'addify_TBYB_trial_products', $existing_data);
						update_post_meta($trial_log_id, 'addify_TBYB_order_id', $order_id);
						update_post_meta($trial_log_id, 'addify_TBYB_created_at', current_time('mysql'));
					}
				}
			}

			// ✅ Store product names for email
			$product_names = array();
			if (!empty($existing_data[ $order_id ])) {
				foreach ($existing_data[ $order_id ] as $item_data) {
					if (!empty($item_data['product_id'])) {
						$product_obj = wc_get_product($item_data['product_id']);
						if ($product_obj) {
							$product_names[] = $product_obj->get_name();
						}
					}
				}
			}

			// ✅ Email handling remains unchanged…

			$order->update_meta_data('addify_TBYB_trial_products_names', $product_names);
			$order->update_meta_data('addify_TBYB_trial_products', $existing_data[ $order_id ]);
			$order->update_meta_data('addify_TBYB_trial_initialized', 'yes');
			$order->save();
		}


		public function addify_woocommerce_paypal_return_authorization_logic() {
			$request_uri = isset($_SERVER['REQUEST_URI']) ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'])) : '';

			$token = filter_input(INPUT_GET, 'token', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
			if (
				isset($token) &&
				strpos($request_uri, '/paypal-return') !== false
			) {
				$paypal_order_id = sanitize_text_field(wp_unslash($token));
				$bearer_object = json_decode(get_option('_transient_ppcp-paypal-bearerppcp-bearer'));
				$paypal_common_data = get_option('woocommerce-ppcp-data-common');

				if (!$bearer_object || empty($bearer_object->access_token)) {
					wp_die('Unable to retrieve PayPal token.');
				}

				$bearer_access_token = $bearer_object->access_token;
				$use_sandbox = $paypal_common_data['use_sandbox'];
				$paypal_api_url = $use_sandbox ? 'https://api-m.sandbox.paypal.com' : 'https://api-m.paypal.com';

				//  Get order details from PayPal
				$order_details_response = wp_remote_get("$paypal_api_url/v2/checkout/orders/{$paypal_order_id}", array(
					'headers' => array(
						'Authorization' => "Bearer $bearer_access_token",
						'Content-Type'  => 'application/json',
					),
				));

				if (is_wp_error($order_details_response)) {
					wp_die('Unable to fetch PayPal order details.');
				}

				$paypal_order = json_decode(wp_remote_retrieve_body($order_details_response), true);

				//  Get WooCommerce Order ID from PayPal custom_id
				$order_id = !empty($paypal_order['purchase_units'][0]['custom_id']) ? (int) $paypal_order['purchase_units'][0]['custom_id'] : null;
				$order = wc_get_order($order_id);
				if (!$order_id || !$order) {
					wp_die('WooCommerce order not found.');
				}


				$authorize_link = null;
				foreach ($paypal_order['links'] as $link) {
					if ('authorize' === $link['rel']) {
						$authorize_link = $link['href'];
						break;
					}
				}

				if (!$authorize_link) {
					$order->update_status('failed');
					$order->add_order_note('PayPal: No authorize link found in order.');
					wp_safe_redirect($order->get_checkout_order_received_url());
					exit;
				}

				$authorize_response = wp_remote_post($authorize_link, array(
					'headers' => array(
						'Authorization' => "Bearer $bearer_access_token",
						'Content-Type'  => 'application/json',
					),
				));

				if (is_wp_error($authorize_response)) {
					$order->update_status('failed');
					$order->add_order_note('PayPal: Authorization request failed - ' . $authorize_response->get_error_message());
					wp_safe_redirect($order->get_checkout_order_received_url());
					exit;
				}

				$authorize_body = json_decode(wp_remote_retrieve_body($authorize_response), true);

				// Extract and store the authorization ID
				$authorization_id = isset($authorize_body['purchase_units'][0]['payments']['authorizations'][0]['id']) ? $authorize_body['purchase_units'][0]['payments']['authorizations'][0]['id'] : null;

				if ($authorization_id) {
					// Store trial data in order meta
					$existing_data = $order->get_meta('addify_TBYB_trial_products');
					$product_names = array();

					if (!empty($existing_data[ $order_id ])) {
						foreach ($existing_data[ $order_id ] as $item) {
							if (!empty($item['product_id'])) {
								$product = wc_get_product($item['product_id']);
								if ($product) {
									$product_names[] = $product->get_name();
								}
							}
						}
					}
					$order->add_order_note("PayPal: Authorization successful. Authorization ID: {$authorization_id}");
					$order->update_meta_data('addify_TBYB_paypal_authorization_id', $authorization_id);
					$order->update_status('processing', 'Payment authorized, pending capture.');
					$order->save();
					wp_safe_redirect($order->get_checkout_order_received_url());
					exit;
				} else {
					$order->update_status('failed');
					$order->add_order_note('PayPal: Authorization failed. No authorization ID found.');
					$order->save();
					wp_safe_redirect($order->get_checkout_order_received_url());
					exit;
				}

				wp_safe_redirect($order->get_checkout_order_received_url());
				exit;
			}
		}



		public function addify_woocommerce_order_status_changed_action( $order_id, $from_status, $to_status, $that ) {
			$order = wc_get_order($order_id);
			if (!$order) {
				return;
			}

			// Skip if already processed or trial start email already sent
			if ('yes' === $order->get_meta('addify_TBYB_trial_initialized') || 'yes' === $order->get_meta('addify_TBYB_trial_start_email_sent')) {
				return;
			}

			// Only run for supported payment methods
			$payment_method = $order->get_meta('addify_TBYB_trial_products_order_payment_method');
			if (!in_array($payment_method, array( 'stripe', 'paypal', 'ppcp-gateway' ), true)) {
				return;
			}

			$valid_statuses = get_option('Addify_TBYB_trial_status', array( 'wc-processing' ));

			if (!is_array($valid_statuses) || !in_array('wc-' . $to_status, $valid_statuses, true)) {
				return;
			} elseif (empty($valid_statuses)) {
				return;
			}

			$user_id = $order->get_user_id();

			if (empty($user_id)) {
				return;
			}

			$option_key = 'addify_TBYB_trial_products_' . $user_id;
			$existing_data = get_option($option_key, array());

			$trial_products = isset($existing_data[ $order_id ]) ? $existing_data[ $order_id ] : array();

			if (empty($trial_products)) {
				return;
			}

			$total_price = floatval($order->get_meta('addify_TBYB_total_price'));

			if ($total_price <= 0) {
				return;
			}

			$user = get_user_by('id', $user_id);
			$email = $user ? $user->user_email : '';
			$customer_name = $user ? $user->display_name : '';

			// Get trial period using min/max logic (same as product page)
			$trial_min_max_setting = get_option('Addify_TBYB_trial_min_max', 'min');

			// Ensure we have a string value, not an array
			if (is_array($trial_min_max_setting)) {
				$trial_min_max_setting = isset($trial_min_max_setting[0]) ? $trial_min_max_setting[0] : 'min';
			}

			// Ensure it's a valid value
			if (!in_array($trial_min_max_setting, array( 'min', 'max' ))) {
				$trial_min_max_setting = 'min';
			}

			// Collect trial periods from all enabled rules
			$applicable_trial_periods = array();
			$args_posts = array(
				'post_type' => 'trial_rule_tab',
				'orderby' => 'menu_order',
				'order' => 'ASC',
				'posts_per_page' => -1,
			);

			$query = new WP_Query($args_posts);
			if ($query->have_posts()) {
				while ($query->have_posts()) {
					$query->the_post();
					$post_id = get_the_ID();
					$enable_rule = get_post_meta($post_id, 'Addify_TBYB_enablerule', true);
					if ($enable_rule) {
						// Get trial period from this rule
						$rule_trial_period = get_post_meta($post_id, 'Addify_TBYB_trial_period', true);
						if (empty($rule_trial_period)) {
							$rule_trial_period = 7;
						}
						$applicable_trial_periods[] = intval($rule_trial_period);
					}
				}
				wp_reset_postdata();
			}

			$meta_trial_days = (int) $order->get_meta('addify_TBYB_trial_days', true);
			if ($meta_trial_days > 0) {
				$trial_days = $meta_trial_days;
			} else {
				// Apply min/max trial period logic (from rule posts)
				if (! empty($applicable_trial_periods)) {
					if ('min' === $trial_min_max_setting) {
						$trial_days = (int) min($applicable_trial_periods);
					} else {
						$trial_days = (int) max($applicable_trial_periods);
					}
				} else {
					$trial_days = 7;
				}
				$trial_days = $trial_days > 0 ? $trial_days : 7;
			}

			// Use WP timezone-aware timestamps and date_i18n for consistent results
			$start_ts   = current_time('timestamp'); // WP-local timestamp
			$start_date = date_i18n('Y-m-d', $start_ts);

			// Build end timestamp safely using strtotime with base time
			$end_ts = strtotime('+' . intval($trial_days) . ' days', $start_ts);
			$end_date = date_i18n('Y-m-d', $end_ts);

			if (!empty($trial_products)) {
				foreach ($trial_products as &$product_data) {
					$product_data['start'] = $start_date;
					$product_data['end']   = $end_date;
				}
				unset($product_data);

				// ✅ Reassign updated products back into full array
				$existing_data[ $order_id ] = $trial_products;

				update_option($option_key, $existing_data);
			}

			$existing_data = get_option($option_key, array());
			$trial_products = isset($existing_data[ $order_id ]) ? $existing_data[ $order_id ] : array();

			if (empty($trial_products)) {
				return;
			}

			$this->add_trial_log($order, $user_id, $existing_data, $order_id, $email, $customer_name, $trial_days, $start_date, $end_date);

			// Send trial start email
			$product_names = array();

			if (!empty($existing_data[ $order_id ])) {
				foreach ($existing_data[ $order_id ] as $item) {
					if (!empty($item['product_id'])) {
						$product = wc_get_product($item['product_id']);
						if ($product) {
							$product_names[] = $product->get_name();
						}
					}
				}
			}

			$Addify_TBYB_trial_start_confirmation = get_option('Addify_TBYB_trial_start_confirmation', 'no');
			if ('yes' == $Addify_TBYB_trial_start_confirmation) {
				$track_url = esc_url(
					wc_get_endpoint_url(
						'view-order',
						$order->get_id(),
						wc_get_page_permalink('myaccount')
					)
				);
				$new_form_data = array(
					'customer_email' => $email,
					'customer_name'  => $customer_name,
					'product'        => implode(', ', $product_names),
					'trial_period'   => $trial_days,
					'begin'        => $start_date,
					'ends'           => $end_date,
					'deposit'        => $order->get_total(),
					'track_url'      => $track_url,
				);
				$mailer = WC()->mailer();
				$tbyb_email  = $mailer->emails['WC_TBYB_Trial_Start_Email'];
				if ($tbyb_email) {
					$tbyb_email->trigger($new_form_data);
					// Mark trial start email as sent to prevent duplicates
					$order->update_meta_data('addify_TBYB_trial_start_email_sent', 'yes');
				}
			}

			$order->update_meta_data('addify_TBYB_trial_products', $existing_data[ $order_id ]);
			$order->update_meta_data('addify_TBYB_trial_initialized', 'yes');
			$order->update_meta_data('addify_TBYB_trial_initialize_paypal', 'yes');

			// set product price to default in order
			foreach ($order->get_items() as $item_id => $item) {
				$product = $item->get_product();
				if ($product) {
					$item->set_subtotal($product->get_price() * $item->get_quantity());
					$item->set_total($product->get_price() * $item->get_quantity());
					$item->save();
				}
			}

			$this->reset_order_product_prices_to_default($order);
		}



		public function addify_tbyb_checkout_restrict_payment_method( $available_gateways ) {
			if (is_admin() && ! is_ajax()) {
				return $available_gateways;
			}

			$cart_has_trial = false;
			$cart_has_regular = false;

			foreach (WC()->cart->get_cart() as $cart_item) {
				if (! empty($cart_item['addify_try_before_buy'])) {
					$cart_has_trial = true;
				} else {
					$cart_has_regular = true;
				}
			}

			// If cart ONLY has trial products
			if ($cart_has_trial && ! $cart_has_regular) {
				foreach ($available_gateways as $gateway_id => $gateway) {
					if (! in_array($gateway_id, array( 'stripe', 'paypal', 'ppcp-gateway' ), true)) {
						unset($available_gateways[ $gateway_id ]);
					}
				}
			}

			return $available_gateways;
		}
	}

	new Addify_TBYB_Checkout_Page();
endif;
