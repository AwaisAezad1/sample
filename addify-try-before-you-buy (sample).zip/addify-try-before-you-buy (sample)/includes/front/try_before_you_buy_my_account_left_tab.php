<?php

use WPML\Collect\Support\Arr;

use function Crontrol\Event\get;
use function WPML\FP\flatMap;

if (!defined('ABSPATH')) {
	exit();
}

if (!class_exists('Addify_TBYB_My_Account_Left_Tab')) :
	class Addify_TBYB_My_Account_Left_Tab {
	









	
		public function theme_button_styling_handler( $current_theme ) {
			if ($current_theme->get('Name') == 'Divi') {
				?>
				<style>
					.return_form_loader {
						text-align: center;
						border: 3px dotted #fff;
						border-radius: 50%;
						height: 40px;
						width: 40px;
						position: absolute;
						top: 50%;
						left: 25%;
						right: 25%;
						margin: auto !important;
						z-index: 999;
						animation: spin 1s linear infinite;
					}
				</style>
			<?php
			} elseif ($current_theme->get('Name') == 'Woodmart') {
				?>
				<style>
					.return_form_loader {
						text-align: center;
						border: 3px dotted #fff;
						border-radius: 50%;
						height: 40px;
						width: 40px;
						position: absolute;
						top: 50%;
						left: 50%;
						margin: auto !important;
						z-index: 999;
						animation: spin 1s linear infinite;
					}
				</style>
			<?php
			} elseif ('Astra' == $current_theme->get('Name')) {
				?>
				<style>
					.return_form_loader {
						text-align: center;
						border: 3px dotted #fff;
						border-radius: 50%;
						height: 40px;
						width: 40px;
						position: absolute;
						top: 50%;
						left: 25%;
						right: 25%;
						margin: auto !important;
						z-index: 999;
						animation: spin 1s linear infinite;
					}
				</style>
			<?php
			} elseif ('Storefront' == $current_theme->get('Name')) {
				?>
				<style>
					.return_form_loader {
						text-align: center;
						border: 3px dotted #fff;
						border-radius: 50%;
						height: 40px;
						width: 40px;
						position: absolute;
						top: 50%;
						left: 50%;
						margin: auto !important;
						z-index: 999;
						animation: spin 1s linear infinite;
					}
				</style>
			<?php
			}
		}
		public function custom_buttons_below_product_name( $item_id, $item, $order, $plain_text ) {
			if (!is_account_page()) {
				return;
			}

			$all_item_meta = $item->get_meta_data();
			$product_variation_data = array();

			foreach ($all_item_meta as $meta_obj) {
				$meta_data = $meta_obj->get_data();
				$key = $meta_data['key'];
				$value = $meta_data['value'];

				if ('Trial Product' == $key) {
					continue; // skip trial meta
				}

				$product_variation_data[ 'attribute_' . $key ] = $value;
			}

			$product_id = $item->get_product_id();
			$variation_id = $item->get_variation_id();
			$product_name = $item->get_name();
			$trial_meta = $item->get_meta('Trial Product');
			$trial_data = null;
			$trial_expired = '';

			$trial_products_meta = $order->get_meta('addify_TBYB_trial_products');
			$trial_intent_id = $order->get_meta('addify_TBYB_stripe_payment_intent');
			$trial_paypal_initialize = $order->get_meta('addify_TBYB_trial_initialize_paypal');

			if (empty($trial_intent_id)) {
				if ('yes' == $trial_paypal_initialize) {
					$trial_intent_id = $order->get_meta('addify_TBYB_paypal_authorization_id');
				}
			}

			$start_trial = !empty($trial_intent_id);

			if (!$start_trial) {
				return;
			}

			if ($trial_products_meta && isset($trial_products_meta)) {
				$trial_products_meta_inside = $trial_products_meta;

				if (is_array($trial_products_meta_inside)) {
					foreach ($trial_products_meta_inside as $products) {
						$meta_product_id = isset($products['product_id']) ? intval($products['product_id']) : 0;
						$meta_variation_id = isset($products['variation_id']) ? intval($products['variation_id']) : 0;

						if (( $variation_id && $meta_variation_id == $variation_id ) || ( !$variation_id && $meta_product_id == $product_id )) {
							$trial_data = $products;
							$trial_expired = isset($products['trial_status']) ? $products['trial_status'] : '';

							$attributes_match = true;
							if (!empty($products['product_variation_data']) && is_array($products['product_variation_data'])) {
								foreach ($products['product_variation_data'] as $key => $value) {
									if (!isset($product_variation_data[ $key ]) || $product_variation_data[ $key ] !== $value) {
										$attributes_match = false;
										break;
									}
								}
							}

							if (!$attributes_match) {
								continue;
							}

							echo '<div class="custom-trial-buttons" data-row-id="product-row-' . esc_attr($variation_id ? $variation_id : $product_id) . '-order-' . esc_attr($order->get_id()) . '" style="margin-top:8px;">';

							if ('expired' !== $trial_expired && 'cancelled' !== $order->get_meta('addify_TBYB_trial_status')) {
								if (empty($trial_data['reason']) && empty($trial_data['keep'])) {
									$attributes_data = '';
									if (!empty($trial_data['product_variation_data']) && is_array($trial_data['product_variation_data'])) {
										foreach ($trial_data['product_variation_data'] as $key => $value) {
											$attributes_data .= ' data-' . esc_attr($key) . '="' . esc_attr($value) . '"';
										}
									}

									echo '<button class="keep-btn" data-product="' . esc_attr($product_name) . '" data-id="' . esc_attr($variation_id ? $variation_id : $product_id) . '" data-row-id="product-row-' . esc_attr($variation_id ? $variation_id : $product_id) . '-order-' . esc_attr($order->get_id()) . '" data-order-id="' . esc_attr($order->get_id()) . '"' . esc_attr($attributes_data) . '>' . esc_html__('Keep', 'addify-try-before-you-buy') . '</button>';
									echo ' <button class="return-btn" data-product="' . esc_attr($product_name) . '" data-id="' . esc_attr($variation_id ? $variation_id : $product_id) . '" data-row-id="product-row-' . esc_attr($variation_id ? $variation_id : $product_id) . '-order-' . esc_attr($order->get_id()) . '" data-order-id="' . esc_attr($order->get_id()) . '"' . esc_attr($attributes_data) . '>' . esc_html__('Return', 'addify-try-before-you-buy') . '</button>';
								} elseif (!empty($trial_data['reason'])) {
									echo '<strong>' . esc_html__('Return Reason:', 'addify-try-before-you-buy') . '</strong> ';
									echo '<div class="return-reason-text">' . esc_html($trial_data['reason']) . '</div>';
									if (isset($trial_data['reject_reason_text']) && '' !== $trial_data['reject_reason_text']) {
										echo '<strong>' . esc_html__('Admin Rejected Reason:', 'addify-try-before-you-buy') . '</strong> ';
										echo '<p class="return-reason-text ">' . esc_html($trial_data['reject_reason_text']) . '</p>';
									}
								} elseif (!empty($trial_data['keep'])) {
									echo '<div class="keep-product-text">' . esc_html__('Product Kept', 'addify-try-before-you-buy') . '</div>';
								}
							} elseif ('cancelled' == $order->get_meta('addify_TBYB_trial_status')) {
								echo esc_html__('Product Kept', 'addify-try-before-you-buy');
							} else {
								echo esc_html__('Trial Expired', 'addify-try-before-you-buy');
							}

							echo '</div>';
							break;
						}
					}
				}
			}


			$custom_reasons   = get_option('Addify_TBYB_custom_return_reason');
			$current_theme    = wp_get_theme();
			$this->theme_button_styling_handler($current_theme);
			?>
			<!-- Overlay & Modal -->
			<div id="modal-overlay" class="modal-overlay"></div>
			<div id="return-reason-modal">
				<div id="return-reason-model-scroll-auto">
					<div style="text-align:right;">
						<button id="close_return_modal">x</button>
					</div>
					<h3><?php echo esc_html__('Return Product Request', 'addify-try-before-you-buy'); ?></h3>
					<p><?php echo esc_html__('Product Name', 'addify-try-before-you-buy'); ?></p>
					<div class="custom-styled-container">
						<p><span id="popup-product-name"></span></p>
					</div>
					<form method="post" id="return-reason-form" enctype="multipart/form-data">
						<?php wp_nonce_field('addify_TBYB_return_reason_action', 'addify_TBYB_return_nonce'); ?>
						<?php wp_nonce_field('addify_TBYB_keep_product_action', 'addify_TBYB_keep_nonce'); ?>
						<input type="hidden" name="product_id" id="popup-product-id">
						<input type="hidden" name="order_id" id="popup-order-id">
						<input type="hidden" name="product_name" id="popup-product-input">
						<input type="hidden" name="row-id" id="popup-row-id">
						<p><?php echo esc_html__('Reason For Return ', 'addify-try-before-you-buy'); ?></p>
						<!-- SELECT dropdown -->
						<select name="return_reason_select" id="return_reason" required>
							<option value="" selected><?php echo esc_html__('Select reason', 'addify-try-before-you-buy'); ?></option>
							<?php
							$has_reasons = false;

							if (!empty($custom_reasons) && is_array($custom_reasons)) {
								foreach ($custom_reasons as $value) {
									if (!empty($value['return_reason'])) {
										$has_reasons = true;
										break;
									}
								}
							}

							if ($has_reasons) {
								foreach ($custom_reasons as $value) {
									if (!empty($value['return_reason']) && '1' == $value['status']) {
										echo '<option>' . esc_html($value['return_reason']) . '</option>';
									}
								}
								?>
								<option value="custom_reason"><?php echo esc_html__('Custom Return Reason', 'addify-try-before-you-buy'); ?></option>
							<?php
							} else {
								?>

								<option value="does_not_fit"><?php echo esc_html__('The product does not fit', 'addify-try-before-you-buy'); ?></option>
								<option value="wrong_size"><?php echo esc_html__('The product was the wrong size', 'addify-try-before-you-buy'); ?></option>
								<option value="not_as_described"><?php echo esc_html__('The product was not as described', 'addify-try-before-you-buy'); ?></option>
								<option value="is_defective"><?php echo esc_html__('The product is defective', 'addify-try-before-you-buy'); ?></option>
								<option value="wrong_item_shipped"><?php echo esc_html__('The wrong item was shipped', 'addify-try-before-you-buy'); ?></option>
								<option value="custom_reason"><?php echo esc_html__('Custom Return Reason', 'addify-try-before-you-buy'); ?></option>
							<?php } ?>
						</select>
						<!-- Custom reason textarea (hidden by default) -->
						<div class="custom-return-reason" style="display: none;">
							<label for="custom_reason_text"><?php echo esc_html__('Please specify:', 'addify-try-before-you-buy'); ?></label>
							<textarea name="return_reason_text" id="custom_reason_text" rows="4"></textarea>
						</div>
						<?php
						if ('yes' == get_option('Addify_TBYB_file_upload')) {
							$allowed_extension  = get_option('Addify_TBYB_file_upload_allowed_extension', '.jpg,.jpeg,.png,.pdf');
							?>
							<div class="custom-file-upload-wrapper">
								<input
									type="file"
									accept="<?php echo esc_attr($allowed_extension); ?>"
									name="return_reason_file"
									id="return_reason_file"
									hidden>

								<label for="return_reason_file" class="custom-file-upload">
									<div class="upload-icon"><i class="fa fa-cloud-upload-alt"></i></div>
									<p><?php echo esc_html__('Click to upload or drag and drop', 'addify-try-before-you-buy'); ?></p>
								</label>

								<p class="tbyb-allowed-extensions">
									<?php
									echo esc_html__('Allowed file types:', 'addify-try-before-you-buy') . ' ' . esc_html(str_replace(',', ', ', $allowed_extension));
									?>
								</p>

								<div id="file-upload-error" class="tbyb-error-message"></div>

								<div class="tbyb-file-name">
									<?php echo esc_html__('Selected File ', 'addify-try-before-you-buy'); ?>
									<div id="file-upload-name"></div>
								</div>
							</div>
						<?php
						}
						?>
						<p><input type="submit" id="submit_return_reason" value="Submit" class="button"></p>
					</form>
				</div>
			<?php
		}

		public function addify_save_message() {
			check_ajax_referer('addify_TBYB_save_message_nonce', 'security');

			$post_message = '';
			if (isset($_POST['message'])) {
				$post_message = sanitize_text_field(
					wp_unslash($_POST['message'])
				);
			}

			if (!empty($post_message)) {
				WC()->session->set('addify_tbyb_custom_message', $post_message);
			}

			wp_die();
		}
		public function addify_save_message_error() {
			check_ajax_referer('addify_TBYB_save_message_error_nonce', 'security');

			$post_message = '';
			if (isset($_POST['message'])) {
				$post_message = sanitize_text_field(
					wp_unslash($_POST['message'])
				);
			}

			if (!empty($post_message)) {
				WC()->session->set('addify_tbyb_custom_message_error', $post_message);
			}

			wp_die();
		}

		public function addify_TBYB_redirect_after_register( $redirect ) {
			$redirect = filter_input(INPUT_GET, 'redirect_to', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
			if (!empty($redirect)) {
				return esc_url_raw($redirect);
			}
			return $redirect;
		}

		public function handle_trial_product_action() {
			$action_type = isset($_POST['action_type']) ? sanitize_text_field(wp_unslash($_POST['action_type'])) : '';

			if ('keep' == $action_type) {
				check_ajax_referer('addify_TBYB_keep_product_action', 'security');
			} elseif ('return' == $action_type) {
				check_ajax_referer('addify_TBYB_return_nonce', 'security');
			} elseif ('extend_trial' == $action_type) {
				check_ajax_referer('addify_TBYB_extend_nonce', 'security');
			} else {
				wp_send_json_error('Invalid action type.');
			}
			$extend_trial = isset($_POST['extend_trial']) ? sanitize_text_field(wp_unslash($_POST['extend_trial'])) : '';
			if ($extend_trial &&  'extend_trial' == $action_type) {
				$order_id     = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
				if (!$order_id) {
					wp_send_json_error('Invalid parameters.');
				}
				$order = wc_get_order($order_id);
				if (!$order) {
					wp_send_json_error('Order not found.');
				}
				$user = get_user_by('id', $order->get_user_id());
				$email = $user ? $user->user_email : '';
				$customer_name = $user ? $user->display_name : '';
				$trial_products = $order->get_meta('addify_TBYB_trial_products');
				if (empty($trial_products) || !is_array($trial_products)) {
					wp_send_json_error('Trial products not found.');
				}
				$order_products = isset($trial_products) ? $trial_products : array();

				$extended_products = array();

				foreach ($order_products as &$product) {
					if (!empty($product['end'])) {

						$product['trial_extension_period_check'] = 'yes';
					}
					$extended_products[] = $product;
				}

				$order->update_meta_data('addify_TBYB_trial_products', array(
					$order_id => $extended_products,
				));
				$order->save();
				$trial_extension_email_check = get_option('Addify_TBYB_trial_extension_approval_rejection', 'no');
				if ('yes' == $trial_extension_email_check) {

					$new_form_data = array(
						'customer_email' => $email,
						'customer_name'  => $customer_name,
						'order_id'       => $order->get_id(),
						'request_date'   => date_i18n('F j, Y'),
					);

					$mailer = WC()->mailer();
					$tbyb_email  = $mailer->emails['WC_TBYB_Trial_Extension_Email'];
					if ($tbyb_email) {
						$tbyb_email->trigger($new_form_data);
					}
				}
				//send another email to admin
				$new_form_data = array(
					'customer_email' => $email,
					'customer_name'  => $customer_name,
					'order_id'       => $order->get_id(),
					'request_date'   => date_i18n('F j, Y'),
				);

				$mailer = WC()->mailer();
				$tbyb_email  = $mailer->emails['WC_TBYB_Trial_Extension_Email_Admin'];
				if ($tbyb_email) {
					$tbyb_email->trigger($new_form_data);
				}
				wp_send_json_success(array(
					'message' => 'Trial period extension request sent successfully.',
					'products' => $extended_products,
				));
			} else {
				$order_id     = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
				$product_id   = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
				$action_type  = isset($_POST['action_type']) ? sanitize_text_field(wp_unslash($_POST['action_type'])) : '';
				$reason       = isset($_POST['reason']) ? sanitize_text_field(wp_unslash($_POST['reason'])) : '';
				$attributes = array();
				if (isset($_POST['attributes']) && is_array($_POST['attributes'])) {
					$raw_attributes = sanitize_meta('', wp_unslash($_POST['attributes']), '');
					if (!is_array($raw_attributes)) {
						$raw_attributes = array();
					}
					foreach ($raw_attributes as $key => $value) {
						$attributes[ sanitize_key($key) ] = sanitize_text_field($value);
					}
				}
				if (!$order_id || !$product_id || !in_array($action_type, array( 'keep', 'return' ))) {
					wp_send_json_error('Invalid parameters.');
				}

				$order = wc_get_order($order_id);
				if (!$order) {
					wp_send_json_error('Order not found.');
				}

				$trial_products = $order->get_meta('addify_TBYB_trial_products');
				if (empty($trial_products) || !is_array($trial_products)) {
					wp_send_json_error(array( 'message' => 'Trial products not found.' ));
				}

				$uploaded_file_url = '';
				if (
					'return' == $action_type &&
					!empty($_FILES['return_reason_file']['name'])
				) {
					$allowed_extension = get_option('Addify_TBYB_file_upload_allowed_extension', '.jpg,.jpeg,.png,.pdf');
					$allowed_extensions = array_map('trim', explode(',', str_replace('.', '', $allowed_extension)));
					$file_name = sanitize_file_name(wp_unslash($_FILES['return_reason_file']['name']));
					$file_ext  = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
					if (!in_array($file_ext, $allowed_extensions, true)) {
						wp_send_json_error(array( 'message' => 'Invalid file type.' ));
					}
					require_once ABSPATH . 'wp-admin/includes/file.php';
					require_once ABSPATH . 'wp-admin/includes/media.php';
					require_once ABSPATH . 'wp-admin/includes/image.php';
					$upload = media_handle_upload('return_reason_file', 0);

					if (!is_wp_error($upload)) {
						$uploaded_file_url = wp_get_attachment_url($upload);
					} else {
						wp_send_json_error(array(
							'error' => true,
							'message' => is_wp_error($upload) ? $upload->error_data['db_insert_error'] : 'File upload error.',
						));
					}
				}
				$user = get_user_by('id', $order->get_user_id());
				$email = $user ? $user->user_email : '';
				$customer_name = $user ? $user->display_name : '';
				$updated = false;

				if (is_string($trial_products)) {
					$trial_products = json_decode($trial_products, true);
					if (json_last_error() !== JSON_ERROR_NONE) {
						wp_send_json_error('Invalid trial products data format.');
					}
				}

				if (empty($trial_products) || !is_array($trial_products)) {
					wp_send_json_error('Trial products data is empty or invalid.');
				}

				if (!isset($trial_products) || empty($trial_products)) {
					wp_send_json_error('Order not found in trial products list.');
				}

				$products_to_check = array();

				if (isset($trial_products['product_id'])) {
					$products_to_check = array( $trial_products );
				} elseif (is_array($trial_products) && isset($trial_products[0]) && is_array($trial_products[0])) {
					$products_to_check = $trial_products;
				} else {
					wp_send_json_error('Invalid trial products structure for this order.');
				}

				foreach ($products_to_check as &$product) {
					if (!is_array($product)) {
						continue;
					}

					$stored_product_id = isset($product['product_id']) ? intval($product['product_id']) : 0;
					$stored_variation_id = isset($product['variation_id']) ? intval($product['variation_id']) : 0;
					$trial_variable_data = isset($product['product_variation_data']) ? $product['product_variation_data'] : array();

					if (!empty($trial_variable_data)) {
						if ($attributes !== $trial_variable_data) {
							continue;
						}
					}
					if ($stored_product_id == $product_id || $stored_variation_id == $product_id) {
						$already_processed = ( isset($product['keep']) && 'yes' == $product['keep'] ) || !empty($product['reason']);

						if (!$already_processed) {
							if ('keep' == $action_type) {
								$product['keep'] = 'yes';
								$product['status'] = 'Kept';
							} elseif ('return' == $action_type) {
								$product['reason'] = $reason;
								$product['status'] = 'Returned';
								$product['return_status'] = 'Pending';
								if ($uploaded_file_url) {
									$product['uploaded_file'] = $uploaded_file_url;
								}
							}
							$updated = true;
							break;
						} else {
							wp_send_json_error('Product has already been processed.');
						}
					}
				}

				$trial_products = $products_to_check;


				if (isset($product)) {
					unset($product);
				}

				if (!$updated) {
					wp_send_json_error('Product not found in trial list for this order.');
				} else {
					$order->update_meta_data('addify_TBYB_trial_products', $trial_products);
					$order->save_meta_data();
				}
				$all_processed = true;

				foreach ($trial_products as $product) {
					if (!is_array($product)) {
						continue;
					}

					$keep   = isset($product['keep']) && 'yes' == $product['keep'];
					$return = !empty($product['reason']);

					if (!$keep && !$return) {
						$all_processed = false;
						break;
					}
				}
				// Handle payment processing if all are done
				if ($all_processed) {

					$capture_amount = 0;
					$all_kept = true;
					$apply_late_fee = false;
					$charge_type = '';
					$charge_amount = 0;

					foreach ($trial_products as $product) {
						if (!is_array($product)) {
							continue;
						}

						if (isset($product['keep']) && 'yes' == $product['keep']) {
							$price = floatval($product['price']);
							$capture_amount += $price;

							if (!$apply_late_fee && !empty($product['enable_late_fee']) && 'yes' == $product['enable_late_fee']) {
								$apply_late_fee = true;
								$charge_type = isset($product['charge_type']) ? $product['charge_type'] : '';
								$charge_amount = floatval(isset($product['charge_amount']) ? $product['charge_amount'] : 0);
							}
						} else {
							$all_kept = false;
						}
					}


					// Apply late fee to total capture amount (once)
					if ($apply_late_fee && $charge_amount > 0) {
						if ('fixed' == $charge_type) {
							$capture_amount += $charge_amount;
						} elseif ('percentage' == $charge_type) {
							$capture_amount += ( $capture_amount * $charge_amount ) / 100;
						}
					}




					$stripe_data       = get_option('woocommerce_stripe_settings');
					$test_mode         = isset($stripe_data['testmode']) && 'yes' == $stripe_data['testmode'];
					$stripe_secret     = $test_mode ? $stripe_data['test_secret_key'] : $stripe_data['secret_key'];
					$payment_intent_id = $order->get_meta('addify_TBYB_stripe_payment_intent');

					$payment_method = $order->get_meta('addify_TBYB_trial_products_order_payment_method');
					if ($all_kept && $capture_amount > 0) {

						if ('stripe' == $payment_method) {

							if (empty($payment_intent_id)) {
								$order->add_order_note('Stripe capture failed: Payment Intent ID is missing.');
								wp_send_json_error(array( 'message' => 'Capture failed: Missing payment intent ID.' ));
								return;
							}

							$amount_cents = intval(round($capture_amount * 100));

							$capture_response = wp_remote_post("https://api.stripe.com/v1/payment_intents/$payment_intent_id/capture", array(
								'method'  => 'POST',
								'headers' => array( 'Authorization' => 'Bearer ' . $stripe_secret ),
								'body'    => array( 'amount_to_capture' => $amount_cents ),
							));

							$capture_data = json_decode(wp_remote_retrieve_body($capture_response), true);

							if (isset($capture_data['id'])) {
								$order->add_order_note('Stripe payment manually captured: ' . $capture_data['id']);
								$completed_products = array();
								$new_form_data = array();

								foreach ($trial_products as $product) {
									if (! is_array($product)) {
										continue;
									}
									$keep = isset($product['keep']) ? $product['keep'] : '';
									// Include only kept
									if ('yes' == $keep) {
										$completed_products[] = $product;
									}
								}

								$new_form_data = array(
									'customer_email' => $email,
									'customer_name'  => $customer_name,
									'order_id'       => $order_id,
									'products'       => json_encode($completed_products), // JSON encode
								);
								$mailer = WC()->mailer();
								$tbyb_email  = $mailer->emails['WC_TBYB_Trial_Completed_Email'];
								if ($tbyb_email) {
									$tbyb_email->trigger($new_form_data);
								}

								$order->payment_complete($capture_data['id']);
								$order->update_status('completed', 'Payment captured for kept products.');
								$order->update_meta_data('addify_TBYB_total_capture_charge', $capture_amount);
								$order->save_meta_data();

								wp_send_json_success(array(
									'message' => 'Payment captured for kept products.',
									'all_processed' => $all_processed,
								));
							} elseif (isset($capture_data['error'])) {
								$order->add_order_note('Stripe capture failed: ' . $capture_data['error']['message']);
								wp_send_json_error(array( 'message' => 'Capture failed: ' . $capture_data['error']['message'] ));
							}
						} elseif ('ppcp-gateway' == $payment_method) {
							//  Capture PayPal Order
							$bearer_object = json_decode(get_option('_transient_ppcp-paypal-bearerppcp-bearer'));

							if (!$bearer_object || empty($bearer_object->access_token)) {
								wp_die('Unable to retrieve PayPal token.');
							}

							$bearer_access_token = $bearer_object->access_token;
							$authorization_id = $order->get_meta('addify_TBYB_paypal_authorization_id');
							$paypal_common_data = get_option('woocommerce-ppcp-data-common');
							$use_sandbox = $paypal_common_data['use_sandbox'];
							$paypal_api_url = $use_sandbox ? 'https://api-m.sandbox.paypal.com' : 'https://api-m.paypal.com';

							if ($authorization_id && !empty($bearer_object->access_token)) {
								$paypal_api_url = $paypal_common_data['use_sandbox']
									? 'https://api-m.sandbox.paypal.com'
									: 'https://api-m.paypal.com';

								$capture_response = wp_remote_post("$paypal_api_url/v2/payments/authorizations/{$authorization_id}/capture", array(
									'headers' => array(
										'Authorization' => "Bearer {$bearer_access_token}",
										'Content-Type'  => 'application/json',
									),
									'body' => json_encode(array(
										'amount' => array(
											'currency_code' => 'USD',
											'value'         => number_format($capture_amount, 2, '.', ''),
										),
										'final_capture' => true,
									)),
								));

								$capture_body = json_decode(wp_remote_retrieve_body($capture_response), true);

								if (!empty($capture_body['status']) && 'COMPLETED' == $capture_body['status']) {
									$order->update_meta_data('addify_TBYB_total_capture_charge', $capture_amount);
									$order->save_meta_data();
									$completed_products = array();
									$new_form_data = array();

									foreach ($trial_products as $product) {
										if (! is_array($product)) {
											continue;
										}
										$keep          = isset($product['keep']) ? $product['keep'] : '';
										// Include only kept
										if ('yes' == $keep) {
											$completed_products[] = $product;
										}
									}
									$new_form_data = array(
										'customer_email' => $email,
										'customer_name'  => $customer_name,
										'order_id'       => $order_id,
										'products'       => $completed_products,
									);
									$mailer = WC()->mailer();
									$tbyb_email  = $mailer->emails['WC_TBYB_Trial_Completed_Email'];
									if ($tbyb_email) {
										$tbyb_email->trigger($new_form_data);
									}
									$order->update_status('completed', 'Payment captured for kept products.');
									$order->payment_complete();
									$order->add_order_note('PayPal: Payment successfully captured.');
									$order->save();
									wp_send_json_success(array(
										'message' => 'Payment captured for kept products.',
										'all_processed' => $all_processed,
									));
								} else {
									$order->update_status('failed');
									$order->add_order_note('PayPal: Capture failed — ' . wp_json_encode($capture_body));
									wp_send_json_success(array(
										'message' => 'Payment capture failed.',
										'all_processed' => $all_processed,
									));
								}
							}
						}
					} else {
						wp_send_json_success(array(
							'message' => 'Payment will be processed after admin has approved returns.',
							'all_processed' => $all_processed,
						));
					}
				} else {
					wp_send_json_success(array(
						'message' => 'Payment will be processed after admin has approved returns.',
						'all_processed' => $all_processed,
					));
				}
			}
		}

		public function addify_TBYB_add_link_my_account_endpoint() {
			add_rewrite_endpoint('tbyb-account', EP_ROOT | EP_PAGES);
			flush_rewrite_rules();
		}

		public function addify_TBYB_add_link_my_account_vars( $vars ) {
			$vars[] = 'tbyb-account';
			return $vars;
		}

		public function addify_TBYB_add_link_my_account( $menu_links ) {
			$new = array( 'tbyb-account' => esc_html__('Try Before You Buy', 'addify-try-before-you-buy') );  // lowercase key
			$menu_links = array_slice($menu_links, 0, 5, true) + $new + array_slice($menu_links, 5, null, true);
			return $menu_links;
		}
		// Updated helper function to handle all-kept case

		public function addify_TBYB_add_link_my_content() {
			$user_id = get_current_user_id();
			$orders_per_page = 5;
			$paged_raw = filter_input(INPUT_GET, 'tbyb_page', FILTER_SANITIZE_NUMBER_INT);
			$paged = max(1, absint($paged_raw));

			// Base args for orders with trial meta
			$order_args = array(
				'customer_id' => $user_id,
				'status' => array( 'wc-completed', 'wc-processing', 'wc-on-hold', 'wc-cancelled', 'wc-refunded' ),
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
				'meta_query' => array(
					array(
						'key'     => 'addify_TBYB_trial_products',
						'compare' => 'EXISTS',
					),
				),
				'limit' => $orders_per_page,
				'paged' => $paged,
			);

			// Get paginated trial orders
			$trial_orders = wc_get_orders($order_args);

			// Get total count of trial orders (no pagination)
			$total_trial_orders = wc_get_orders(array(
				'customer_id' => $user_id,
				'status' => array( 'wc-completed', 'wc-processing', 'wc-on-hold', 'wc-cancelled', 'wc-refunded' ),
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
				'meta_query' => array(
					array(
						'key'     => 'addify_TBYB_trial_products',
						'compare' => 'EXISTS',
					),
				),
				'return' => 'ids',
				'limit' => -1,
			));

			$total_order_count = count($total_trial_orders);
			$total_pages = ceil($total_order_count / $orders_per_page);

			?>

				<div class="order-list-dashboard">

					<div id="order-list-container">
						<table class="woocommerce-orders-table woocommerce-MyAccount-orders shop_table shop_table_responsive my_account_orders account-orders-table">
							<thead>
								<tr>
									<th class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-number" scope="row"><?php echo esc_html__('Order ID', 'addify-try-before-you-buy'); ?></th>
									<th class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-date"><?php echo esc_html__('Trial End', 'addify-try-before-you-buy'); ?></th>
									<th class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-date"><?php echo esc_html__('Day(s) Remaining', 'addify-try-before-you-buy'); ?></th>
									<th class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-number"><?php echo esc_html__('Total(After Trial)', 'addify-try-before-you-buy'); ?></th>
									<th class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-number"><?php echo esc_html__('Late fee', 'addify-try-before-you-buy'); ?></th>
									<th class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-actions"><?php echo esc_html__('Actions', 'addify-try-before-you-buy'); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php

								foreach ($trial_orders as $order) :

									$trial_products = $order->get_meta('addify_TBYB_trial_products');
									$trial_initialized = $order->get_meta('addify_TBYB_trial_initialize_paypal');
									if (!$trial_products) {
										continue;
									}
									if ('no' == $trial_initialized) {
										continue;
									}

									$order_id = $order->get_id();
									$all_processed = true;
									$trial_expired_flag = false;
									$trial_cancel_flag = false;

									foreach ($trial_products as $product) {

										if (!is_array($product)) {
											continue;
										}

										if (isset($product['trial_status']) && 'expired' == $product['trial_status']) {
											$trial_expired_flag = true;
										}
										if ('cancelled' == $order->get_meta('addify_TBYB_trial_status')) {
											$trial_cancel_flag = true;
										}

										$keep   = isset($product['keep']) && 'yes' == $product['keep'];
										$return = !empty($product['reason']);

										if (!$keep && !$return) {
											$all_processed = false;
											break;
										}
									}

									// Handle payment processing if all are done
									$order_trial_products = isset($trial_products) ? $trial_products : array();
									$trial_end_date = isset($order_trial_products[0]['end']) ? $order_trial_products[0]['end'] : '';
									$enable_late_fee = isset($order_trial_products[0]['enable_late_fee']) ? $order_trial_products[0]['enable_late_fee'] : 'no';
									$charge_type = isset($order_trial_products[0]['charge_type']) ? $order_trial_products[0]['charge_type'] : '';
									$charge_amount = isset($order_trial_products[0]['charge_amount']) ? $order_trial_products[0]['charge_amount'] : 0;
									$days_remaining = '';
									$trial_approved = false;
									$expired_days = false;
									$all_kept_days = true;
									$any_returned_days = false;
									foreach ($order_trial_products as $trial) {
										if (isset($trial['status']) && 'expired' == $trial['status']) {
											$expired_days = true;
										}
										if (!isset($trial['keep']) || 'yes' !== $trial['keep']) {
											$all_kept_days = false;
										}

										if (isset($trial['return_status']) && 'Approved' == $trial['return_status']) {
											$any_returned_days = true;
										}
										if (isset($trial['return_status']) &&  'Approved' == $trial['return_status']) {
											$trial_approved = true;
										} elseif (isset($trial['return_status']) && 'Kept' == $trial['return_status']) {
											$trial_approved = true;
										} else {
											$trial_approved = false;
											break;
										}
									}

									if (! empty($trial_end_date)) {
										$end_date = new DateTime($trial_end_date);
										$today    = new DateTime(gmdate('Y-m-d'));

										if (! empty($order->get_meta('addify_TBYB_total_capture_charge')) || $trial_cancel_flag) {
											// Already captured or cancelled - show dash
											$days_remaining = esc_html('-', 'addify-try-before-you-buy');
										} elseif ($all_processed && $trial_approved) {
											// Trial is fully processed and approved - show dash
											$days_remaining = esc_html__('-', 'addify-try-before-you-buy');
										} elseif ($today > $end_date) {
											// Trial has ended
											$days_remaining = esc_html__('-', 'addify-try-before-you-buy');
										} elseif ($all_kept_days && !$any_returned_days) {
											// All products kept - show dash
											$days_remaining = esc_html__('-', 'addify-try-before-you-buy');
										} else {
											// Trial is still active, show days remaining
											$interval       = $today->diff($end_date);
											$days_remaining = $interval->days;

											// If it's the same day, show 0 days remaining
											if (0 == $days_remaining && $today->format('Y-m-d') == $end_date->format('Y-m-d')) {
												$days_remaining = 0;
											}
										}
									}

									$trial_total = 0;
									if (is_array($order_trial_products)) {
										foreach ($order_trial_products as $trial) {

											if (isset($trial['price'])) {
												$trial_total += (float) $trial['price'];
											}
										}
									}
									?>

									<tr class="woocommerce-orders-table__row woocommerce-orders-table__row--status-processing order">
										<th class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-number" scope="row">
											<a href="<?php echo esc_url(wc_get_endpoint_url('view-order', $order->get_id(), wc_get_page_permalink('myaccount'))); ?>">
												<?php echo esc_html('#' . $order->get_id()); ?>
											</a>
										</th>
										<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-date"><?php echo esc_html(date_i18n(get_option('date_format'), strtotime($trial_end_date))); ?></td>
										<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-date"><?php echo esc_html($days_remaining); ?></td>
										<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-number">
											<?php
											if (!empty($order->get_meta('addify_TBYB_total_capture_charge'))) {

												echo wp_kses_post(wc_price($order->get_meta('addify_TBYB_total_capture_charge')));
											} else {

												echo wp_kses_post(wc_price($trial_total));
											}

											?>
										</td>
										<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-number">
											<?php
											if ($enable_late_fee) {
												if ('fixed' == $charge_type) {
													echo wp_kses_post(wc_price($charge_amount));
												} elseif ('percentage' == $charge_type) {
													$percentage_charge = ( $order->get_subtotal() * $charge_amount ) / 100;
													echo wp_kses_post(wc_price($percentage_charge));
												} else {
													echo '-';
												}
											} else {
												echo '-';
											}
											?>
										</td>
										<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-actions">
											<?php
											// Get plugin settings
											$allow_extension = get_option('Addify_TBYB_allow_return_extension_window');
											$today = gmdate('Y-m-d');

											// Determine product statuses
											$all_kept = true;
											$any_returned = false;
											$expired = false;

											foreach ($order_trial_products as $trial_product) {
												if (isset($trial_product['status']) && 'expired' == $trial_product['status']) {
													$expired = true;
												}
												if (!isset($trial_product['keep']) || 'yes' !== $trial_product['keep']) {
													$all_kept = false;
												}

												if (isset($trial_product['return_status']) && 'Approved' == $trial_product['return_status']) {
													$any_returned = true;
												}

												if (isset($trial_product['status']) && 'Returned' == $trial_product['status']) {
													$any_returned = true;
												}
											}
											if ($trial_cancel_flag) {
												// Treat cancelled as kept
												echo '<span class="trial-expired">' . esc_html__('Product Kept', 'addify-try-before-you-buy') . '</span>';
											} elseif ($trial_expired_flag || $expired) {
												// Trial has expired
												echo '<span class="trial-expired">' . esc_html__('Trial Expired', 'addify-try-before-you-buy') . '</span>';
											} elseif ($today >= $trial_end_date && !$all_kept && !$any_returned) {
												// Trial period has ended
												if (isset($order_trial_products[0]['trial_extension_period_check'])) {
													if ('yes' == $order_trial_products[0]['trial_extension_period_check']) {
														echo esc_html__('Trial Extension Requested', 'addify-try-before-you-buy');
													} elseif ('set_once' == $order_trial_products[0]['trial_extension_period_check']) {
														echo esc_html__('Trial Period Expired', 'addify-try-before-you-buy');
													}
												} elseif ('yes' == $allow_extension) {
													// Show extend trial button
													?>
													<a class="button a-tag-classes extend-trial-btn" data-order-id="<?php echo esc_attr($order->get_id()); ?>">
														<?php echo esc_html__('Extend Trial Period', 'addify-try-before-you-buy'); ?>
													</a>
												<?php
												} else {
													// Trial expired with no extension allowed
													?>
													<span class="extend-trial-btn" data-order-id="<?php echo esc_attr($order->get_id()); ?>">
														<?php echo esc_html__('Trial Period Expired', 'addify-try-before-you-buy'); ?>
													</span>
												<?php
												}
											} elseif (!$all_kept && $any_returned) {
												// Show products that can be processed
												echo '<span class="all-processed">' . esc_html__('All Products Processed', 'addify-try-before-you-buy') . '</span>';
											} elseif (!$all_kept && !$any_returned) {
												// Show products that can be processed
												?>
												<a href="<?php echo esc_url(wc_get_endpoint_url('view-order', $order->get_id(), wc_get_page_permalink('myaccount'))); ?>"
													class="button a-tag-classes view-order-btn woocommerce-button button view">
													<?php echo esc_html__('View', 'addify-try-before-you-buy'); ?>
												</a>
											<?php
											} elseif ($all_kept && !$any_returned) {
												echo '<span class="all-processed">' . esc_html__('All Products Kept', 'addify-try-before-you-buy') . '</span>';
											} elseif ($all_kept && $any_returned) {
												echo '<span class="all-processed">' . esc_html__('All Processed', 'addify-try-before-you-buy') . '</span>';
											}
											?>
										</td>



									</tr>
								<?php
								endforeach;
								?>

							</tbody>
						</table>
						<?php if ($total_pages > 1) : ?>
							<div class="pagination">
								<?php if ($paged > 1) : ?>
									<a class="page-link" href="?tbyb_page=<?php echo esc_attr($paged - 1); ?>">
										&laquo; <?php esc_html_e('Previous', 'addify-try-before-you-buy'); ?>
									</a>
								<?php endif; ?>

								<?php for ($i = 1; $i <= $total_pages; $i++) : ?>
									<a class="page-link <?php echo ( $i == $paged ) ? 'current' : ''; ?>" href="?tbyb_page=<?php echo esc_attr($i); ?>">
										<?php echo esc_html($i); ?>
									</a>
								<?php endfor; ?>

								<?php if ($paged < $total_pages) : ?>
									<a class="page-link" href="?tbyb_page=<?php echo esc_attr($paged + 1); ?>">
										<?php esc_html_e('Next', 'addify-try-before-you-buy'); ?> &raquo;
									</a>
								<?php endif; ?>
							</div>
						<?php endif; ?>

					</div>
				</div>
	<?php
		}

		public function addify_TBYB_front_enqueue_scripts() {
			if (!is_account_page()) {
				return;
			}

			wp_enqueue_script('Addify_TBYB_js_front_call', AD_TBYB_URL . 'assets/js/Addify_TBYB_front.js', array( 'jquery' ), '1.0.3', true);
			wp_enqueue_style('addify_TBYB_css_enqueue', AD_TBYB_URL . 'assets/css/Addify_TBYB_front.css', array(), '1.0.3', 'all');

			$order_id = !empty(get_query_var('order-received')) ? get_query_var('order-received') : 0;
			$client_secret = '';
			$publishable_key = '';
			if ($order_id) {
				$order = wc_get_order($order_id);
				if ($order) {
					$client_secret = $order->get_meta('addify_TBYB_stripe_client_secret');

					// Get Stripe publishable key from WooCommerce Stripe settings
					$stripe_data = get_option('woocommerce_stripe_settings', array());
					$publishable_key = !empty($stripe_data['publishable_key']) ? $stripe_data['publishable_key'] : '';
				}
			}

			wp_localize_script('Addify_TBYB_js_front_call', 'addify_TBYB_front_data', array(
				'ajaxurl'         => admin_url('admin-ajax.php'),
				'nonce'           => wp_create_nonce('addify_TBYB_front_nonce'),
				'order_id'        => $order_id,
				'client_secret'   => $client_secret,
				'stripe_key'      => $publishable_key,
				'keep_nonce'      => wp_create_nonce('addify_TBYB_keep_product_action'),
				'return_nonce'    => wp_create_nonce('addify_TBYB_return_nonce'),
				'extend_nonce'    => wp_create_nonce('addify_TBYB_extend_nonce'),
				'save_message_nonce'    => wp_create_nonce('addify_TBYB_save_message_nonce'),
				'save_message_error_nonce'    => wp_create_nonce('addify_TBYB_save_message_error_nonce'),
				'return_text'     => esc_html__('Return Reason: ', 'addify-try-before-you-buy'),
				'kept_text'       => esc_html__('Product Kept', 'addify-try-before-you-buy'),
				'processing'       => esc_html__('Processing', 'addify-try-before-you-buy'),
			));
		}
	}

	new Addify_TBYB_My_Account_Left_Tab();
endif;
