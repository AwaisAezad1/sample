<?php

if (!defined('ABSPATH')) {
	exit();
}

if (!class_exists('Addify_TBYB_Product_Page')) :
	class Addify_TBYB_Product_Page {
	
















	
		public function addify_cart_validation_product_check( $passed, $product_id, $quantity, $variation_id = 0, $variations = array(), $cart_item_data = array() ) {
			$try_before_buy = filter_input(INPUT_GET, 'try_before_buy', FILTER_SANITIZE_NUMBER_INT);
			// Detect if the item being added is a trial product
			$is_try_before_buy = ! empty($cart_item_data['addify_try_before_buy']) || isset($try_before_buy);

			foreach (WC()->cart->get_cart() as $cart_item) {
				$cart_has_trial   = ! empty($cart_item['addify_try_before_buy']);
				$cart_has_regular = empty($cart_item['addify_try_before_buy']);

				// If cart already has a trial and trying to add regular
				if ($cart_has_trial && ! $is_try_before_buy) {
					wc_clear_notices();
					wc_add_notice(
						esc_html__('You cannot add regular products while you have a trial product in your cart.', 'addify-try-before-you-buy'),
						'error'
					);
					return false;
				}

				// If cart already has a regular and trying to add trial
				if ($cart_has_regular && $is_try_before_buy) {
					wc_clear_notices();
					wc_add_notice(
						esc_html__('You cannot add trial products while you have a regular product in your cart.', 'addify-try-before-you-buy'),
						'error'
					);
					return false;
				}
			}

			return $passed;
		}
		private function is_virtual_product() {
			if (!function_exists('is_product') || !is_product()) {
				return false;
			}
			global $Addify_TBYB_product;

			if (!$Addify_TBYB_product && function_exists('wc_get_product')) {
				$Addify_TBYB_product = wc_get_product(get_the_ID());
			}

			return $Addify_TBYB_product instanceof WC_Product && $Addify_TBYB_product->is_virtual();
		}

		public function add_extra_button_after_add_to_cart() {
			if ($this->is_virtual_product()) {
				return;
			}

			global $Addify_TBYB_product;
			$user = wp_get_current_user();

			$user_role = $user->roles;
			$user_role = !empty($user_role) ? $user_role[0] : 'guest';
			$customer_id = get_current_user_id();
			$user_ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';
			if (empty($user_ip)) {
				$user_ip = '39.49.217.148'; // Fallback IP
			}

			$product_id = $Addify_TBYB_product->get_id();
			$rule_processed = false;

			// Get general settings for min/max trial period selection
			$trial_min_max_setting = get_option('Addify_TBYB_trial_min_max', 'min');

			// Ensure we have a string value, not an array
			if (is_array($trial_min_max_setting)) {
				$trial_min_max_setting = isset($trial_min_max_setting[0]) ? $trial_min_max_setting[0] : 'min';
			}

			// Ensure it's a valid value
			if (!in_array($trial_min_max_setting, array( 'min', 'max' ))) {
				$trial_min_max_setting = 'min';
			}
			$applicable_trial_periods = array();
			$Addify_TBYB_trial_period = ''; // Initialize trial period variable

			// First, collect trial periods from ALL rules (without restrictions)
			$args_posts = array(
				'post_type' => 'trial_rule_tab',
				'orderby' => 'menu_order',
				'order' => 'ASC',
				'posts_per_page' => -1,
			);

			$query = new WP_Query($args_posts);
			if ($query->have_posts()) {
				while ($query->have_posts()) {
					$query->the_post();
					$post_id = get_the_ID();
					$enable_rule = get_post_meta($post_id, 'Addify_TBYB_enablerule', true);
					if ($enable_rule) {
						// Get trial period from this rule (without checking restrictions)
						$rule_trial_period = get_post_meta($post_id, 'Addify_TBYB_trial_period', true);
						if (empty($rule_trial_period)) {
							$rule_trial_period = 7;
						}
						$applicable_trial_periods[] = intval($rule_trial_period);
					}
				}
				wp_reset_postdata();
			}

			// Apply min/max trial period logic
			if (!empty($applicable_trial_periods)) {
				if ('min' === $trial_min_max_setting) {
					$final_trial_period = min($applicable_trial_periods);
				} else {
					$final_trial_period = max($applicable_trial_periods);
				}

				// Format trial period for display
				if ($final_trial_period > 1) {
					$Addify_TBYB_trial_period = $final_trial_period . ' ' . esc_html__('days', 'addify-try-before-you-buy');
				} else {
					$Addify_TBYB_trial_period = $final_trial_period . ' ' . esc_html__('day', 'addify-try-before-you-buy');
				}
			} else {
				// Fallback to default if no rules match
				$Addify_TBYB_trial_period = 7;
				if ($Addify_TBYB_trial_period > 1) {
					$Addify_TBYB_trial_period = $Addify_TBYB_trial_period . ' ' . esc_html__('days', 'addify-try-before-you-buy');
				} else {
					$Addify_TBYB_trial_period = $Addify_TBYB_trial_period . ' ' . esc_html__('day', 'addify-try-before-you-buy');
				}
			}

			// Now process rules for actual application (with restrictions)
			$query = new WP_Query($args_posts);
			if ($query->have_posts()) {
				while ($query->have_posts() && !$rule_processed) {
					$query->the_post();
					$post_id = get_the_ID();
					$enable_rule = get_post_meta($post_id, 'Addify_TBYB_enablerule', true);
					if ('yes' == $enable_rule) {
						$show_button = true;
						$Addify_TBYB_ipinfo_api_key = get_post_meta($post_id, 'Addify_TBYB_ipinfo_api_key', true);
						if (!empty($Addify_TBYB_ipinfo_api_key)) {
							$Api_key = $Addify_TBYB_ipinfo_api_key;
						} else {
							$Api_key = '1a22d7f3f13d4542ae9ab911a7da57b6';
						}
						$api_url = 'https://api.findip.net/' . $user_ip . '/?token=' . $Api_key;
						$response = wp_remote_get($api_url, array(
							'timeout'   => 20,
							'sslverify' => false,
						));

						if (is_wp_error($response)) {
							$ipdat = new stdClass();
						} else {
							$body = wp_remote_retrieve_body($response);
							$ipdat = json_decode($body);
						}
						// Initialize flags and variables
						$brand_flag = false;
						$category_flag = false;
						$product_flag = false;
						$match_found = false;
						$show_button = true;

						// Get geo location data
						$geo_country_code   = isset($ipdat->country->iso_code) ? strtoupper($ipdat->country->iso_code) : '';
						$geo_region_code    = isset($ipdat->subdivisions[0]->iso_code) ? strtoupper($ipdat->subdivisions[0]->iso_code) : '';
						$geo_continent_code = isset($ipdat->continent->code) ? strtoupper($ipdat->continent->code) : '';

						// Get rule meta data
						$Addify_TBYB_apply_all = get_post_meta($post_id, 'Addify_TBYB_apply_all', true);
						$Addify_TBYB_product_selction = get_post_meta($post_id, 'Addify_TBYB_product_selction', true);
						$Addify_TBYB_category_selction = get_post_meta($post_id, 'Addify_TBYB_category_selction', true);
						$Addify_TBYB_brand_selction = get_post_meta($post_id, 'Addify_TBYB_brand_selction', true);
						$Addify_TBYB_user_roles = get_post_meta($post_id, 'Addify_TBYB_user_roles', true);
						$Addify_TBYB_country_selection = get_post_meta($post_id, 'Addify_TBYB_country_selection', true);
						$Addify_TBYB_shipping_zones = get_post_meta($post_id, 'Addify_TBYB_shipping_zones', true);
						$Addify_TBYB_enable_monthly_product_limit = get_post_meta($post_id, 'Addify_TBYB_enable_monthly_product_limit', true);
						$Addify_TBYB_set_monthly_product_limit = get_post_meta($post_id, 'Addify_TBYB_set_monthly_product_limit', true);
						$Addify_TBYB_enable_monthly_purchase_limit_per_customer = get_post_meta($post_id, 'Addify_TBYB_enable_monthly_purchase_limit_per_customer', true);
						$Addify_TBYB_set_monthly_purchase_limit_per_customer = get_post_meta($post_id, 'Addify_TBYB_set_monthly_purchase_limit_per_customer', true);

						// ========================================
						// STEP 1: CHECK PRODUCT CATEGORY/BRAND SELECTION
						// ========================================
						$valid_product_cat_ids = array();
						$valid_product_brand_ids = array();

						$all_products = get_posts(array(
							'post_type' => 'product',
							'posts_per_page' => -1,
							'post_status' => 'publish',
							'fields' => 'ids',
						));

						if ('yes' === $Addify_TBYB_apply_all) {
							$category_flag = true;
							$product_flag = true;
						} else {
							// Check product categories
							foreach ($all_products as $product_loop_id) {
								$product_categories = wp_get_post_terms($product_loop_id, 'product_cat', array( 'fields' => 'ids' ));
								if (!empty($Addify_TBYB_category_selction) && array_intersect($product_categories, $Addify_TBYB_category_selction)) {
									$valid_product_cat_ids[] = $product_loop_id;
								}
							}

							if (!empty($Addify_TBYB_category_selction) && in_array($product_id, $valid_product_cat_ids)) {
								$category_flag = true;
							}

							// Check specific product selection
							if (!empty($Addify_TBYB_product_selction) && in_array($product_id, $Addify_TBYB_product_selction)) {
								$product_flag = true;
							}
						}

						// Check product brands
						foreach ($all_products as $product_loop_id) {
							$product_brands = wp_get_post_terms($product_loop_id, 'product_brand', array( 'fields' => 'ids' ));
							if (!empty($Addify_TBYB_brand_selction) && array_intersect($product_brands, $Addify_TBYB_brand_selction)) {
								$valid_product_brand_ids[] = $product_loop_id;
							}
						}

						if (!empty($Addify_TBYB_brand_selction) && in_array($product_id, $valid_product_brand_ids)) {
							$brand_flag = true;
						}

						// Early exit: If product doesn't match category/brand criteria, skip this rule
						if (!( $product_flag || $category_flag || $brand_flag )) {
							continue; // Skip to next rule
						}

						// ========================================
						// STEP 2: CHECK ZONE/COUNTRY/SHIPPING RESTRICTIONS
						// ========================================

						// Check shipping zones
						if (is_array($Addify_TBYB_shipping_zones)) {
							foreach ($Addify_TBYB_shipping_zones as $zone_id) {
								if ('0' === (string) $zone_id) {
									continue;
								}

								$zone = new WC_Shipping_Zone($zone_id);
								if (!$zone || !$zone->get_id()) {
									continue;
								}

								$zone_locations = $zone->get_zone_locations();

								foreach ($zone_locations as $location) {
									$location_code = strtoupper($location->code);

									if (
										( 'continent' ===  $location->type && $location_code === $geo_continent_code ) ||
										( 'country' ===  $location->type && $location_code === $geo_country_code ) ||
										( 'state' ===  $location->type && $location_code === $geo_country_code . ':' . $geo_region_code )
									) {
										$match_found = true;
										break 2;
									}
								}
							}

							if (!$match_found && in_array('0', $Addify_TBYB_shipping_zones)) {
								$match_found = true;
							}
						}

						// Check user roles restriction
						if (in_array($user_role, $Addify_TBYB_user_roles)) {
							$show_button = false;
						}

						// Check country selection restriction
						if (in_array($geo_country_code, $Addify_TBYB_country_selection)) {
							$show_button = false;
						}

						// If shipping zone restriction found, hide button
						if ($match_found) {
							$show_button = false;
						}

						// ========================================
						// STEP 3: CHECK MONTHLY LIMITS
						// ========================================

						$current_month = gmdate('Y-m');
						$exclude_statuses = array( 'wc-failed', 'wc-trash', 'wc-checkout-draft' ); // ✅ use wc- prefixes
						$all_statuses = array_keys(wc_get_order_statuses());
						$statuses = array_diff($all_statuses, $exclude_statuses);
						if ('yes' === $Addify_TBYB_enable_monthly_product_limit) {
							$monthly_product_limit = intval($Addify_TBYB_set_monthly_product_limit);
							if ($monthly_product_limit > 0) {

								$sitewide_orders_args = array(
									'limit'        => -1,
									'status'       => $statuses,
									'date_created' => $current_month . '-01...' . $current_month . '-31',
								);

								$sitewide_orders = wc_get_orders($sitewide_orders_args);
								$sitewide_qty_for_product = 0;
								foreach ($sitewide_orders as $order) {
									$trial_products = $order->get_meta('addify_TBYB_trial_products');
									if (empty($trial_products) || !is_array($trial_products)) {
										continue;
									}
									foreach ($order->get_items() as $item) {
										$product_id_of_item = 0;
										if (is_object($item) && method_exists($item, 'get_data')) {
											$data = $item->get_data();
											if (isset($data['product_id'])) {
												$product_id_of_item = intval($data['product_id']);
											}
										}
										if ($product_id_of_item == $product_id) {
											$sitewide_qty_for_product += $item->get_quantity();
										}
									}
								}

								if ($sitewide_qty_for_product >= $monthly_product_limit) {
									$show_button = false; // Hide for everyone if sitewide cap reached
								}
							}
						}
						// 3.b) Per-customer total monthly purchase limit (only for logged-in customer)
						if ('yes' === $Addify_TBYB_enable_monthly_purchase_limit_per_customer && $customer_id) {
							$monthly_purchase_limit = intval($Addify_TBYB_set_monthly_purchase_limit_per_customer);
							if ($monthly_purchase_limit > 0) {
								$customer_orders_args = array(
									'customer_id'  => $customer_id,
									'limit'        => -1,
									'status'       => $statuses,
									'date_created' => $current_month . '-01...' . $current_month . '-31',
								);
								$customer_orders = wc_get_orders($customer_orders_args);
								$total_qty_overall = 0;
								foreach ($customer_orders as $order) {
									$trial_products = $order->get_meta('addify_TBYB_trial_products');
									if (empty($trial_products) || !is_array($trial_products)) {
										continue;
									}
									foreach ($order->get_items() as $item) {
										$total_qty_overall += $item->get_quantity();
									}
								}
								if ($total_qty_overall >= $monthly_purchase_limit) {
									$show_button = false; // Hide only for this customer
								}
							}
						}

						// ========================================
						// FINAL CHECK: SHOW BUTTON IF ALL CONDITIONS PASS
						// ========================================
						if ($show_button) {
							$rule_processed = true;
							if ($rule_processed) {
								$current_url = esc_url(get_permalink($product_id));
								$custom_instruction = $post_id ? get_post_meta($post_id, 'Addify_TBYB_instructions', true) : '';
								$custom_heading = $post_id ? get_post_meta($post_id, 'Addify_TBYB_heading', true) : '';
								$try_now_button_options = $post_id ? get_post_meta($post_id, 'Addify_TBYB_replace_add_to_cart', true) : '';
								if (empty($custom_instruction)) {
									$items = array(
										__('Try at home', 'addify-try-before-you-buy'),
										__('Easily return what you do not love', 'addify-try-before-you-buy'),
										__('Only pay for what you keep', 'addify-try-before-you-buy'),
									);
									$items = array_map('esc_html', $items);
									$custom_instruction = '<ul><li>' . implode('</li><li>', $items) . '</li></ul>';
								}
								if (empty($custom_heading)) {
									$custom_heading = esc_html__('Try Before You Buy', 'addify-try-before-you-buy');
								}

								// Check if product is variable
								$is_variable_product = $Addify_TBYB_product->is_type('variable');
								$button_disabled_class = $is_variable_product ? ' tbyb-disabled' : '';
								$button_disabled_attr = $is_variable_product ? ' disabled' : '';

								if ('add_replace' == $try_now_button_options) {
									?>
									<style>
										.single_add_to_cart_button {
											display: none !important;
										}
									</style>
								<?php
								}

								// Add CSS for disabled button
								if ($is_variable_product) {
									?>
									<style>
										.tbyb-disabled {
											opacity: 0.5 !important;
											cursor: not-allowed !important;
											pointer-events: none !important;
										}

										.tbyb-disabled:hover {
											opacity: 0.5 !important;
										}
									</style>
					<?php
								}
								$background_color = get_option('Addify_TBYB_button_background_color', '#000000');
								$text_color = get_option('Addify_TBYB_button_text_color', '#ffffff');
								$icon_class = get_option('Addify_TBYB_button_icon', 'fa-shopping-cart');
								$use_custom_style = get_option('Addify_TBYB_use_custom_style', 'no');

								$pp_behaviour = get_option('Addify_TBYB_trial_pp_behaviour', 'in-page');

								$user_id = get_current_user_id();

								if (0 == $user_id) {
									$my_account_page_id = get_option('woocommerce_myaccount_page_id');
									$my_account_url = $my_account_page_id ? get_permalink($my_account_page_id) : site_url();

									$try_buy_url = add_query_arg(array(
										'redirect_to' => urlencode($current_url),
										'register'    => 'yes',
									), $my_account_url);
								} else {
									$try_buy_url = add_query_arg(array(
										'try_before_buy' => $product_id,
										'quantity' => 1,
										'redirect_to' => urlencode($current_url),
									), home_url());
								}
								$current_theme    = wp_get_theme();
								$this->theme_button_styling_handler($current_theme);
								$style_attr = '';
								if ('yes' == $use_custom_style) {
									$style_attr = sprintf(
										' style="background-color:%s;color:%s;"',
										esc_attr($background_color),
										esc_attr($text_color)
									);
								}

								$icon_html = $icon_class ? '<i class="fa ' . esc_attr($icon_class) . '"></i> ' : '';
								if ('pop-up' == $pp_behaviour) {
									// Popup trigger button
									$button_html = sprintf(
										'<a href="#" class="button wp-element-button tbyb-try-now-btn-popup alt%s"%s%s>%s%s</a>',
										$button_disabled_class,
										$style_attr,
										$button_disabled_attr,
										$icon_html,
										esc_html__('Try Before Buy', 'addify-try-before-you-buy')
									);
									// Hidden option field
									echo '<input type="hidden" id="try_now_button_options" value="' . esc_attr($try_now_button_options) . '">';
									echo '<input type="hidden" id="tbyb_is_variable_product" value="' . ( $is_variable_product ? 'yes' : 'no' ) . '">';
									echo '<input type="hidden" id="tbyb_selected_variation" name="tbyb_selected_variation" value="">';

									$popup_html = '
								<div id="tbyb-popup" class="tbyb-popup" style="display:none;">
									<div class="tbyb-popup-overlay"></div>
									   <div class="tbyb-popup-wrap">
										<div class="tbyb-popup-content">
												<button class="tbyb-popup-close" style="float: right;background-color: #e0e0e0;padding: 2px 9px;border-radius: 50px;">x</button>
												<div class="tbyb-popup-header">
													<h2>' . wp_kses_post($custom_heading) . '</h2>
												</div>
												<div class="tbyb-popup-inner-date-content">
													<p> <i class="fa fa-calendar"></i>&emsp;' . esc_html($Addify_TBYB_trial_period) . '</p>
												</div>
												<div class="tbyb-popup-inner-content">
												<p class="tbyb-custom-instruction">' . wp_kses_post($custom_instruction) . '</p>
												</div>
												<div class="tbyb-popup-buttons">
													<a href="' . esc_url($try_buy_url) . '" class="button tbyb-proceed-btn tbyb-try-now-btn-popup-proceed alt"' . $style_attr . '>' . esc_html__('Proceed', 'addify-try-before-you-buy') . '</a>
													<button class="tbyb-popup-close">' . esc_html__('Not Right Now', 'addify-try-before-you-buy') . '</button>
												</div>
											</div>
										</div>
								</div>';
									echo '<div id="addify-tbyb-wrapper">';
									echo wp_kses_post($button_html);
									echo '</div>';
									echo wp_kses_post($popup_html);
								} else {
									$button_html_try_now = sprintf(
										'<a href="#" class="button wp-element-button tbyb-try-now-btn alt%s"%s%s>%s%s</a>',
										$button_disabled_class,
										$style_attr, // styles
										$button_disabled_attr,
										$icon_html,  // icon
										esc_html__('Try Before Buy', 'addify-try-before-you-buy')
									);

									$button_html_proceed = sprintf(
										'<a href="%s" class="button wp-element-button tbyb-proceed-btn alt"%s>%s%s</a>',
										esc_url($try_buy_url),
										$style_attr,
										'',
										esc_html__('Proceed', 'addify-try-before-you-buy')
									);

									echo '<div class="tbyb-instruction-wrapper"style="display:none;">';
									echo '<div id="addify-tbyb-wrapper" >';

									// Hidden option field
									echo '<input type="hidden" id="try_now_button_options" value="' . esc_attr($try_now_button_options) . '">';
									echo '<input type="hidden" id="tbyb_is_variable_product" value="' . ( $is_variable_product ? 'yes' : 'no' ) . '">';
									echo '<input type="hidden" id="tbyb_selected_variation" name="tbyb_selected_variation" value="">';

									// Dummy Try Now button
									echo wp_kses_post($button_html_try_now);
									echo '</div>';

									// Instructions + Proceed button
									if (!empty($custom_instruction)) {
										echo '<h3 class="tbyb-instruction-title">' . wp_kses_post($custom_heading) . '</h3>';
										echo '<p class="tbyb-instruction-info"><span class="dashicons dashicons-info"></span> Trial Information</p>';
										echo '<p class="tbyb-custom-instruction">' . wp_kses_post($custom_instruction) . '</p>';
									}

									// Real Proceed button
									echo wp_kses_post($button_html_proceed);
									echo '</div>';
								}
							}
						}
					}
					wp_reset_postdata();
				}
			}
		}

		public function addify_TBYB_enqueue_scripts_front() {
			$screen = get_post_type();
			if (isset($screen) && 'product' !== $screen) {
				return;
			}
			if ($this->is_virtual_product()) {
				return;
			}
			$total = 0;
			$has_trial_product = false;
			foreach (WC()->cart->get_cart() as $item) {
				if (!empty($item['addify_try_before_buy'])) {
					$has_trial_product = true;
					$total += $item['data']->get_price() * $item['quantity'];
				}
			}
			wp_enqueue_style('tbyb_font_awesomefont', AD_TBYB_URL . 'assets/font-awesome/css/font-awesome.min.css', array(), '4.7.0');
			wp_enqueue_script('Addify_TBYB_product_js_front_call', AD_TBYB_URL . 'assets/js/Addify_TBYB_front_product.js', array( 'jquery' ), '1.0.2', true);
			wp_enqueue_style('addify_TBYB_css_enqueue_product', AD_TBYB_URL . 'assets/css/Addify_TBYB_front_product.css', array(), '1.0.2', 'all');
			$pp_behaviour = get_option('Addify_TBYB_trial_pp_behaviour', 'in-page');


			wp_localize_script('Addify_TBYB_product_js_front_call', 'addify_TBYB_data_product', array(
				'ajaxurl' => admin_url('admin-ajax.php'),
				'nonce' => wp_create_nonce('addify_TBYB_nonce'),
				'button_behaviour' => $pp_behaviour,
			));
			if ($has_trial_product) {
				wp_enqueue_script('addify-tbyb-block-stripe-payment-attach-method', AD_TBYB_URL . 'assets/js/Addify_TBYB_block_stripe_payment_attach.js', array( 'wp-hooks', 'wp-element', 'wc-blocks-checkout' ), '1.0', true);
				wp_enqueue_script('addify-tbyb-block', AD_TBYB_URL . 'assets/js/Addify_TBYB_block.js', array( 'wp-hooks', 'wp-element', 'wc-blocks-checkout' ), '1.0', true);

				wp_add_inline_script(
					'addify-tbyb-block',
					'window.ADDIFY_TBYB_TOTAL = ' . json_encode(wc_price($total)) . ';',
					'before'
				);

				wp_localize_script('addify-tbyb-block', 'addify_tbyb_data_product', array(
					'trial_total' => wc_price($total),
					'total_label' => esc_html__('Total(After Trial)', 'addify-try-before-you-buy'),
				));
			}
		}
		public function theme_button_styling_handler( $current_theme ) {
			$screen = get_post_type();
			if (isset($screen) && 'trial_rule_tab' !== $screen) {
				return;
			}

			$theme_name = $current_theme->get('Name');

			switch ($theme_name) {
				case 'Divi':
					?>
					<style>
						form.cart {
							display: flex !important;
							flex-wrap: wrap;
							gap: 5px;
						}

						.tbyb-button-container {
							display: flex !important;
							flex-wrap: wrap;
							gap: 5px !important;
							align-items: normal !important;
						}

						.single_add_to_cart_button {
							margin-bottom: 10px !important;
						}
					</style>
				<?php
					break;

				case 'Woodmart':
					?>
					<style>
						.tbyb-button-container {
							display: -webkit-inline-box !important;
							gap: 5px !important;
							align-items: normal !important;
						}

						form.cart>* {
							flex: none;
							order: 12;
							margin-bottom: 1rem;
						}

						.tbyb-try-now-btn-popup,
						.tbyb-try-now-btn-popup-proceed {
							border-radius: var(--btn-accented-brd-radius);
							color: var(--btn-accented-color);
							box-shadow: var(--btn-accented-box-shadow);
							background-color: var(--btn-accented-bgcolor);
							text-transform: var(--btn-accented-transform, var(--btn-transform));
							font-weight: var(--btn-accented-font-weight, var(--btn-font-weight));
							font-family: var(--btn-accented-font-family, var(--btn-font-family));
							font-style: var(--btn-accented-font-style, var(--btn-font-style));
						}

						.tbyb-try-now-btn {
							border-radius: var(--btn-accented-brd-radius);
							color: var(--btn-accented-color);
							box-shadow: var(--btn-accented-box-shadow);
							background-color: var(--btn-accented-bgcolor);
							text-transform: var(--btn-accented-transform, var(--btn-transform));
							font-weight: var(--btn-accented-font-weight, var(--btn-font-weight));
							font-family: var(--btn-accented-font-family, var(--btn-font-family));
							font-style: var(--btn-accented-font-style, var(--btn-font-style));
						}

						.tbyb-try-now-btn-popup:hover {
							color: var(--btn-accented-color-hover);
							box-shadow: var(--btn-accented-box-shadow-hover);
							background-color: var(--btn-accented-bgcolor-hover);
						}

						.tbyb-try-now-btn:hover {
							color: var(--btn-accented-color-hover);
							box-shadow: var(--btn-accented-box-shadow-hover);
							background-color: var(--btn-accented-bgcolor-hover);
						}
					</style>
				<?php
					break;

				case 'Astra':
					?>
					<style>
						.single_add_to_cart_button {
							padding: 15px 30px !important;
						}

						form.cart {
							display: flex !important;
							flex-wrap: wrap;
							align-items: center;
							gap: 10px;
						}

						.tbyb-try-now-btn {
							padding: 10px !important;
						}
					</style>
				<?php
					break;

				case 'Storefront':
					?>
					<style>
						form.cart {
							display: flex !important;
							flex-wrap: wrap;
							align-items: center;
							gap: 10px;
						}
					</style>
				<?php
					break;

				case 'Twenty Twenty-Three':
					?>
					<style>
						#addify-tbyb-wrapper a {
							margin-top: 0 !important;
						}

						form.cart {
							display: flex !important;
							align-items: center;
							flex-wrap: wrap;
							gap: 10px;
						}
					</style>
				<?php
					break;
				case 'Twenty Twenty-Five':
					?>
					<style>
						#addify-tbyb-wrapper a {
							margin-top: 0 !important;
						}



						form.cart {
							display: flex !important;
							align-items: center;
							flex-wrap: wrap;
							gap: 10px;
						}
					</style>
				<?php
					break;

				default:
					?>
					<style>
						form.cart {
							display: flex !important;
							align-items: center;
							flex-wrap: wrap;
							gap: 10px;
						}
					</style>
<?php
					break;
			}
		}

		public function handle_try_before_buy_add_to_cart() {
			if ($this->is_virtual_product()) {
				return;
			}

			$try_before_buy = filter_input(INPUT_GET, 'try_before_buy', FILTER_SANITIZE_NUMBER_INT);

			if ($try_before_buy && is_numeric($try_before_buy)) {
				$product_id = absint($try_before_buy);
				$product    = wc_get_product($product_id);

				if (! $product) {
					return;
				}

				// Check cart compatibility
				foreach (WC()->cart->get_cart() as $cart_item) {
					$is_trial_in_cart   = ! empty($cart_item['addify_try_before_buy']);
					$is_regular_in_cart = empty($cart_item['addify_try_before_buy']);

					// If cart already has trial item and trying to add regular → block
					if ($is_trial_in_cart && empty($try_before_buy)) {
						wc_clear_notices();
						wc_add_notice(
							esc_html__('You cannot add regular products while you have a trial product in your cart.', 'addify-try-before-you-buy'),
							'error'
						);
						wp_safe_redirect(get_permalink($product_id));
						exit;
					}

					// If cart already has regular item and trying to add trial → block
					if ($is_regular_in_cart && ! empty($try_before_buy)) {
						wc_clear_notices();
						wc_add_notice(
							esc_html__('You cannot add trial products while you have a regular product in your cart.', 'addify-try-before-you-buy'),
							'error'
						);
						wp_safe_redirect(get_permalink($product_id));
						exit;
					}
				}

				// Handle Grouped Product
				if ($product->is_type('grouped')) {
					$children_ids = $product->get_children();
					$added_any    = false;

					if (! empty($children_ids)) {
						foreach ($children_ids as $child_id) {
							$child_product = wc_get_product($child_id);

							if ($child_product && $child_product->is_purchasable()) {

								// Prevent duplicate adds for same child product
								$already_in_cart = false;
								foreach (WC()->cart->get_cart() as $cart_item) {
									if (! empty($cart_item['addify_try_before_buy']) && $cart_item['product_id'] == $child_id) {
										$already_in_cart = true;
										break;
									}
								}

								if ($already_in_cart) {
									continue;
								}

								WC()->cart->add_to_cart($child_id, 1, 0, array(), array(
									'addify_try_before_buy' => true,
									'tbyb_unique_id'        => uniqid(),
								));

								// Set cookie for each child
								$data        = array(
									'product_id' => $child_id,
									'timestamp'  => time(),
								);
								$cookie_name = 'addify_try_now_data_' . $child_id . '_' . uniqid();
								setcookie($cookie_name, json_encode($data), time() + WEEK_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN);

								$added_any = true;
							}
						}
					}

					// After adding grouped product(s) to cart
					if ($added_any) {
						wc_clear_notices();
						wc_add_notice(
							esc_html__('Grouped product', 'addify-try-before-you-buy') . ' ' .
								esc_html($product->get_name()) . ' ' .
								esc_html__('has been added to your cart for Try Before Buy.', 'addify-try-before-you-buy'),
							'success'
						);
					} else {
						wc_clear_notices();
						wc_add_notice(
							esc_html__('None of the products in this group are available for Try Before Buy.', 'addify-try-before-you-buy'),
							'notice'
						);
					}

					wp_safe_redirect(get_permalink($product_id));
					exit;
				}

				if ($product->is_purchasable()) {

					// Collect variation attributes from URL
					$variation_data = array();

					// Get all attribute parameters from URL
					// phpcs:ignore WordPress.Security.NonceVerification.Recommended
					foreach ($_GET as $key => $value) {
						if (strpos($key, 'attribute_') === 0) {
							$variation_data[ sanitize_text_field($key) ] = sanitize_text_field($value);
						}
					}

					// Determine variation_id - prefer the actual variation_id parameter if provided
					$variation_id = filter_input(INPUT_GET, 'variation_id', FILTER_SANITIZE_NUMBER_INT);

					// If no variation_id provided but we have attributes, try to find the matching variation
					if (empty($variation_id) && !empty($variation_data) && $product->is_type('variable')) {
						$data_store = WC_Data_Store::load('product');
						$variation_id = $data_store->find_matching_product_variation($product, $variation_data);
					}

					// If we still don't have a variation_id but try_before_buy is a variation ID
					if (empty($variation_id) && $product->is_type('variation')) {
						$variation_id = $product->get_id();
						$product_id   = $product->get_parent_id();

						// Get attributes from the variation product
						$variation_attributes = $product->get_attributes();
						foreach ($variation_attributes as $attr_name => $attr_value) {
							$attribute_key = 'attribute_' . sanitize_title($attr_name);
							if (empty($variation_data[ $attribute_key ])) {
								$variation_data[ $attribute_key ] = $attr_value;
							}
						}
					}

					// Validate that we have a valid variation for variable products
					if ($product->is_type('variable') && empty($variation_id)) {
						wc_clear_notices();
						wc_add_notice(
							esc_html__('Please select all required options for this product.', 'addify-try-before-you-buy'),
							'error'
						);
						wp_safe_redirect(get_permalink($product_id));
						exit;
					}

					// Check cart duplicates
					foreach (WC()->cart->get_cart() as $cart_item) {
						if (
							! empty($cart_item['addify_try_before_buy']) &&
							$cart_item['product_id'] == $product_id &&
							$cart_item['variation_id'] == $variation_id
						) {
							// Also check if attributes match for variable products
							$attributes_match = true;
							if (!empty($variation_data)) {
								foreach ($variation_data as $key => $value) {
									if (isset($cart_item['variation'][ $key ]) && $cart_item['variation'][ $key ] !== $value) {
										$attributes_match = false;
										break;
									}
								}
							}

							if ($attributes_match) {
								wc_clear_notices();
								wc_add_notice(
									sprintf(
										/* translators: %s: product name */
										esc_html__('You have already added %s to your cart for Try Before Buy.', 'addify-try-before-you-buy'),
										esc_html($product->get_name())
									),
									'notice'
								);
								wp_safe_redirect(get_permalink($product_id));
								exit;
							}
						}
					}

					// Add to cart
					$cart_item_key = WC()->cart->add_to_cart(
						$product_id,
						1,
						$variation_id,
						$variation_data,
						array(
							'addify_try_before_buy' => true,
							'tbyb_unique_id'        => uniqid(),
						)
					);

					if ($cart_item_key) {
						$data = array(
							'product_id'   => $product_id,
							'variation_id' => $variation_id,
							'attributes'   => $variation_data,
							'timestamp'    => time(),
						);

						$cookie_name = 'addify_try_now_data_' . $product_id . '_' . $variation_id . '_' . uniqid();
						setcookie($cookie_name, json_encode($data), time() + WEEK_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN);

						wc_clear_notices();

						$product_name = esc_html($product->get_name());
						$view_cart_url = wc_get_cart_url();
						$view_cart_link = '<a href="' . esc_url($view_cart_url) . '" class="button wc-forward">' . esc_html__('View cart', 'addify-try-before-you-buy') . '</a>';

						wc_add_notice(
							sprintf(
								/* translators: %s: product name */
								esc_html__('You have added %s to your cart for Try Before Buy.', 'addify-try-before-you-buy'),
								$product_name
							) . ' ' . $view_cart_link,
							'success'
						);
					} else {
						wc_clear_notices();
						wc_add_notice(
							esc_html__('Failed to add product to cart. Please try again.', 'addify-try-before-you-buy'),
							'error'
						);
					}

					wp_safe_redirect(get_permalink($product_id));
					exit;
				}
			}
		}
	}

	new Addify_TBYB_Product_Page();
endif;
