<?php

if (!defined('ABSPATH')) {
	exit();
}

if (!class_exists('Addify_TBYB_Cart_Page')) :

	class Addify_TBYB_Cart_Page {
	

	

		public function wsp_update_cart_quantity_validation_block_minimum( $value, $product, $cart_item ) {
			if (is_admin() && !defined('DOING_AJAX')) {
				return;
			}

			if (!empty($cart_item['addify_try_before_buy'])) {
									return 1;

			}
		}
		public function wsp_update_cart_quantity_validation_block_maximum( $value, $product, $cart_item ) {
			if (is_admin() && !defined('DOING_AJAX')) {
				return;
			}

			if (!empty($cart_item['addify_try_before_buy'])) {
				return 1;
			}
		}


		//  Block manual POST updates (via "Update Cart" button)
		public function addify_prevent_trial_qty_update( $passed, $cart_item_key, $values, $quantity ) {
			if (!empty($values['addify_try_before_buy']) && $quantity > 1) {
				wc_add_notice(__('Trial product quantity cannot be changed. Only one trial per product is allowed.', 'addify-try-before-you-buy'), 'error');
				return false;
			}
			return $passed;
		}

		public function addify_set_try_before_buy_price( $cart ) {
			if (is_admin() && !defined('DOING_AJAX')) {
				return;
			}

			$has_trial_product = false;

			foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
				if (!empty($cart_item['addify_try_before_buy'])) {
					$has_trial_product = true;
					$cart_item['data']->set_price(0);
					$cart_item['data']->set_sale_price(0);
					$cart_item['data']->set_regular_price(0);
				}
			}

			if ($has_trial_product) {
				$fee_amount = floatval(get_option('Addify_TBYB_trial_fee_charge', 0.5));
				if (0 == $fee_amount) {
					$fee_amount = 0.5;
				}
				if ($fee_amount > 0) {
					$fee_name = esc_html__('Trial Product Fee', 'addify-try-before-you-buy');
					$cart->add_fee($fee_name, $fee_amount, true);
				}
			}
		}

		public function addify_cart_item_name( $name, $cart_item, $cart_item_key ) {
			if (!empty($cart_item['addify_try_before_buy'])) {
				$name .= '<p class="trial-label" style="color: inherit; font-style: italic;">' . esc_html__('Trial Product', 'addify-try-before-you-buy') . '</p>';
			}
			return $name;
		}

		// Display trial price in mini-cart and cart
		public function addify_trial_price_display( $price, $cart_item, $cart_item_key ) {
			if (!empty($cart_item['addify_try_before_buy'])) {
				$badge = '<span class="trial-price-badge" ' .
					esc_html__('Trial', 'addify-try-before-you-buy') . '</span>';

				$trial_price = '<span class="trial-price">' .
					wc_price(0) . '</span>';

				return $badge . $trial_price;
			}

			return $price;
		}

		// Display trial subtotal in mini-cart and cart
		public function addify_trial_subtotal_display( $subtotal, $cart_item, $cart_item_key ) {
			if (!empty($cart_item['addify_try_before_buy'])) {
				$trial_subtotal = '<span class="trial-subtotal">' .
					wc_price(0) . '</span>';

				return $trial_subtotal;
			}

			return $subtotal;
		}
	}

	new Addify_TBYB_Cart_Page();

endif;
