jQuery(document).ready(function ($) {
  jQuery(".sel-order-status").select2({
    ajax: {
      url: wsp_php_vars.admin_url,
      dataType: "json",
      type: "POST",
      delay: 250,
      data: function (params) {
        return {
          q: params.term || "",
          action: "Addify_TBYB_ajax_search",
          nonce: wsp_php_vars.nonce,
          context: "order_status", // Specify the context as 'order_status' for rule
        };
      },
      processResults: function (data) {
        if (data && Array.isArray(data)) {
          return {
            results: data.map(function (item) {
              return { id: item.id, text: item.text };
            }),
          };
        }
        return { results: [] };
      },
      error: function (xhr, status, error) {
        console.error("Error fetching data:", error);
      },
      cache: true,
    },
    multiple: true,
    placeholder: wsp_php_vars.choose_order_status,
    allowClear: true,
    minimumInputLength: 0,
  });
  jQuery(".sel-role").select2({
    ajax: {
      url: wsp_php_vars.admin_url,
      dataType: "json",
      type: "POST",
      delay: 250,
      data: function (params) {
        return {
          q: params.term || "",
          action: "Addify_TBYB_ajax_search",
          nonce: wsp_php_vars.nonce,
          context: "roles", // Specify the context as 'roles' for rule
        };
      },
      processResults: function (data) {
        if (data && Array.isArray(data)) {
          return {
            results: data.map(function (item) {
              return { id: item.id, text: item.text };
            }),
          };
        }
        return { results: [] };
      },
      error: function (xhr, status, error) {
        console.error("Error fetching data:", error);
      },
      cache: true,
    },
    multiple: true,
    placeholder: wsp_php_vars.choose_role,
    allowClear: true,
    minimumInputLength: 0,
  });
  jQuery(".sel_pros").select2({
    ajax: {
      url: wsp_php_vars.admin_url,
      dataType: "json",
      type: "POST",
      delay: 60,
      data: function (params) {
        return {
          q: params.term,
          action: "Addify_TBYB_ajax_search",
          context: "products", // Specify the context as 'products' for rule
          nonce: wsp_php_vars.nonce,
        };
      },
      processResults: function (data) {
        return { results: data };
      },
      cache: true,
    },
    placeholder: wsp_php_vars.choose_products,
    allowClear: true,
    minimumInputLength: 0,
  });
  jQuery(".sel_brands").select2({
    ajax: {
      url: wsp_php_vars.admin_url,
      dataType: "json",
      type: "POST",
      delay: 60,
      data: function (params) {
        return {
          q: params.term,
          action: "Addify_TBYB_ajax_search",
          context: "brands", // Specify the context as 'brands' for rule
          nonce: wsp_php_vars.nonce,
        };
      },
      processResults: function (data) {
        return { results: data };
      },
      cache: true,
    },
    placeholder: wsp_php_vars.choose_brands,
    allowClear: true,
    minimumInputLength: 0,
  });
  jQuery(".sel_cats").select2({
    ajax: {
      url: wsp_php_vars.admin_url,
      dataType: "json",
      type: "POST",
      delay: 60,
      data: function (params) {
        return {
          q: params.term,
          action: "Addify_TBYB_ajax_search",
          context: "categories", // Specify the context as 'categories' for rule
          nonce: wsp_php_vars.nonce,
        };
      },
      processResults: function (data) {
        return { results: data };
      },
      cache: true,
    },
    placeholder: wsp_php_vars.choose_categories,
    allowClear: true,
    minimumInputLength: 0,
  });
  jQuery(".sel_pros2").select2({
    ajax: {
      url: wsp_php_vars.admin_url,
      dataType: "json",
      type: "POST",
      delay: 60,
      data: function (params) {
        return {
          q: params.term,
          action: "Addify_TBYB_ajax_search",
          context: "products2", // Specify the context as 'products2 for sub tab 3'
          nonce: wsp_php_vars.nonce,
        };
      },
      processResults: function (data) {
        return { results: data };
      },
      cache: true,
    },
    placeholder: wsp_php_vars.choose_products,
    allowClear: true,
    minimumInputLength: 0,
  });

  jQuery(".sel_country").select2({
    ajax: {
      url: wsp_php_vars.admin_url,
      dataType: "json",
      type: "POST",
      delay: 60,
      data: function (params) {
        return {
          q: params.term,
          action: "Addify_TBYB_ajax_search",
          context: "country", // Specify the context as 'country' for rule
          nonce: wsp_php_vars.nonce,
        };
      },
      processResults: function (data) {
        return { results: data };
      },
      cache: true,
    },
    placeholder: wsp_php_vars.choose_country,
    allowClear: true,
    minimumInputLength: 0,
  });
  jQuery(".sel_zone").select2({
    ajax: {
      url: wsp_php_vars.admin_url,
      dataType: "json",
      type: "POST",
      delay: 60,
      data: function (params) {
        return {
          q: params.term,
          action: "Addify_TBYB_ajax_search",
          context: "zones", // Specify the context as 'zones' for rule
          nonce: wsp_php_vars.nonce,
        };
      },
      processResults: function (data) {
        return { results: data };
      },
      cache: true,
    },
    placeholder: wsp_php_vars.choose_zone,
    allowClear: true,
    minimumInputLength: 0,
  });
  jQuery(function ($) {
    $(".woocommerce-help-tip").tipTip({
      attribute: "data-tip",
      fadeIn: 200,
      fadeOut: 200,
      delay: 200,
    });
  });

  jQuery(document).on("click", ".Addify_TBYB_check", function () {
    hideFields();
  });
  function hideFields() {
    var applycustomestyle = $("#Addify_TBYB_use_custom_style").prop("checked");

    if (applycustomestyle == true) {
      $("#Addify_TBYB_button_background_color").closest("tr").show();
      $("#Addify_TBYB_button_text_color").closest("tr").show();
    } else {
      $("#Addify_TBYB_button_background_color").closest("tr").hide();
      $("#Addify_TBYB_button_text_color").closest("tr").hide();
    }
    var applyallcheck = $("#Addify_TBYB_apply_all").prop("checked");
    if (applyallcheck !== true) {
      $('label[for="Addify_TBYB_product_selction"]').closest("tr").show();
      $('label[for="Addify_TBYB_category_selction"]').closest("tr").show();
      $('label[for="Addify_TBYB_brand_selction"]').closest("tr").show();
    } else {
      $('label[for="Addify_TBYB_product_selction"]').closest("tr").hide();
      $('label[for="Addify_TBYB_category_selction"]').closest("tr").hide();
      $('label[for="Addify_TBYB_brand_selction"]').closest("tr").hide();
    }

    var latefeecheck = $("#Addify_TBYB_allow_late_fee_returns").prop("checked");
    if (latefeecheck == true) {
      $("#Addify_TBYB_charge_amount_type").closest("tr").show();
      $("#Addify_TBYB_charge_amount").closest("tr").show();
    } else {
      $("#Addify_TBYB_charge_amount_type").closest("tr").hide();
      $("#Addify_TBYB_charge_amount").closest("tr").hide();
    }
    var applyallcheck = $("#Addify_TBYB_allow_return_extension_window").prop(
      "checked"
    );
    if (applyallcheck == true) {
      $("#Addify_TBYB_return_extension_window").closest("tr").show();
      $("#Addify_TBYB_allow_late_fee_returns").closest("tr").show();
      var latefeecheck = $("#Addify_TBYB_allow_late_fee_returns").prop(
        "checked"
      );
      if (latefeecheck == true) {
        $("#Addify_TBYB_charge_amount_type").closest("tr").show();
        $("#Addify_TBYB_charge_amount").closest("tr").show();
      } else {
        $("#Addify_TBYB_charge_amount_type").closest("tr").hide();
        $("#Addify_TBYB_charge_amount").closest("tr").hide();
      }
    } else {
      $("#Addify_TBYB_return_extension_window").closest("tr").hide();
      $("#Addify_TBYB_allow_late_fee_returns").closest("tr").hide();
      $("#Addify_TBYB_charge_amount_type").closest("tr").hide();
      $("#Addify_TBYB_charge_amount").closest("tr").hide();
    }
    var applyallcheck = $("#Addify_TBYB_enable_monthly_product_limit").prop(
      "checked"
    );
    if (applyallcheck == true) {
      $('label[for="Addify_TBYB_set_monthly_product_limit"]')
        .closest("tr")
        .show();
      // add required attribute
      $("#Addify_TBYB_set_monthly_product_limit").attr("required", "required");
    } else {
      $('label[for="Addify_TBYB_set_monthly_product_limit"]')
        .closest("tr")
        .hide();
      // remove required attribute
      $("#Addify_TBYB_set_monthly_product_limit").removeAttr("required");
    }
    var applyallcheck = $(
      "#Addify_TBYB_enable_monthly_purchase_limit_per_customer"
    ).prop("checked");
    if (applyallcheck == true) {
      $('label[for="Addify_TBYB_set_monthly_purchase_limit_per_customer"]')
        .closest("tr")
        .show();
      // add required attribute
      $("#Addify_TBYB_set_monthly_purchase_limit_per_customer").attr(
        "required",
        "required"
      );
    } else {
      $('label[for="Addify_TBYB_set_monthly_purchase_limit_per_customer"]')
        .closest("tr")
        .hide();
      // remove required attribute
      $("#Addify_TBYB_set_monthly_purchase_limit_per_customer").removeAttr(
        "required"
      );
    }

    var trialextensioncheck = $("#Addify_TBYB_trial_period_enable").prop(
      "checked"
    );
    if (trialextensioncheck == true) {
      $('label[for="Addify_TBYB_trial_period_days"]').closest("tr").show();
    } else {
      $('label[for="Addify_TBYB_trial_period_days"]').closest("tr").hide();
    }

    var customreturnreason = $("#Addify_TBYB_allow_custom_return_reason").prop(
      "checked"
    );
    if (customreturnreason == true) {
      $("#customReturn_block_table").closest("tr").show();
    } else {
      $("#customReturn_block_table").closest("tr").hide();
    }
    var fileuploadinstruction = $("#Addify_TBYB_file_upload").prop("checked");
    if (fileuploadinstruction == true) {
      $("#Addify_TBYB_file_upload_allowed_extension").closest("tr").show();
    } else {
      $("#Addify_TBYB_file_upload_allowed_extension").closest("tr").hide();
    }
  }

  hideFields();
  customReturnBlock();
  function customReturnBlock() {
    $("head").append(`
      <style>
        #customReturn_block_table { max-width: 60%; }
        #customReturn_block_table th { text-align: center; }
        #customReturn_block_body td input,
        #customReturn_block_body td button,
        #customReturn_block_body td select { width: 100%; }
        #add_customReturnRow {margin-top: 10px}
      </style>
    `);

    // Add row
    $(document)
      .off("click", "#add_customReturnRow")
      .on("click", "#add_customReturnRow", function () {
        let index = $("#customReturn_block_body tr").length;
        let row = `
        <tr data-new="true">
          <td><input type="text" name="Addify_TBYB_custom_return_reason[${index}][name]" required></td>
          <td><input type="text" name="Addify_TBYB_custom_return_reason[${index}][return_reason]" required></td>
          <td>
            <select name="Addify_TBYB_custom_return_reason[${index}][status]" id="Addify_TBYB_custom_return_reason[${index}][status]">
              <option value="1">Active</option>
              <option value="0">Inactive</option>
            </select>
          </td>
          <td><button type="button" class="button remove_customReturn_block">${wsp_php_vars.remove}</button></td>
        </tr>`;
        $("#customReturn_block_body").append(row);
      });

    // Remove row and normalize indexes
    $(document)
      .off("click", ".remove_customReturn_block")
      .on("click", ".remove_customReturn_block", function () {
        $(this).closest("tr").remove();
        normalizeIndexes();
      });
    normalizeIndexes();

    // Normalize indexes after removing rows
    function normalizeIndexes() {
      $("#customReturn_block_body tr").each(function (newIndex) {
        $(this)
          .find("input, select")
          .each(function () {
            const oldName = $(this).attr("name");
            const oldId = $(this).attr("id");

            if (oldName) {
              const newName = oldName.replace(/\[\d+\]/, `[${newIndex}]`);
              $(this).attr("name", newName);
            }

            if (oldId) {
              const newId = oldId.replace(/\[\d+\]/, `[${newIndex}]`);
              $(this).attr("id", newId);
            }
          });
      });
    }
  }

  $(".admin-extend-trial-btn").on("click", function (e) {
    e.preventDefault();
    var orderId = $(this).data("order-id");
    $.ajax({
      url: wsp_php_vars.admin_url,
      type: "POST",
      data: {
        action: "Addify_TBYB_extend_trial_period",
        order_id: orderId,
        action_type: "extend_trial",
        security: wsp_php_vars.admin_extend_nonce,
        extend_trial: true,
      },
      beforeSend: function () {
        $(".addify-trial-order-wrapper").append(
          '<div class="return_form_overlay"></div><p class="return_form_loader"></p>'
        );
      },
      success: function (response) {
        $(".return_form_overlay").remove();
        $(".return_form_loader").remove();
        location.reload();
      },
      error: function (xhr, status, error) {},
    });
  });
  $(".cancel_trial_period").on("click", function (e) {
    e.preventDefault();
    var orderId = $(this).data("order-id");
    $.ajax({
      url: wsp_php_vars.admin_url,
      type: "POST",
      data: {
        action: "Addify_TBYB_cancel_trial_period",
        order_id: orderId,
        action_type: "cancel_trial",
        security: wsp_php_vars.admin_cancel_nonce,
        extend_trial: true,
      },
      beforeSend: function () {
        $(".addify-trial-order-wrapper").append(
          '<div class="return_form_overlay"></div><p class="return_form_loader"></p>'
        );
      },
      success: function (response) {
        $(".return_form_overlay").remove();
        $(".return_form_loader").remove();
        location.reload();
      },
      error: function (xhr, status, error) {},
    });
  });
  $(".approve_trial_return_reason").on("click", function (e) {
    e.preventDefault();
    const $btn = $(this);

    var orderId = $(this).data("order-id");
    var productId = $(this).data("product-id");
    var variationId = $(this).data("variation-id");

    const attributes = {};
    $.each($btn[0].dataset, function (key, value) {
      if (key.startsWith("attribute_")) {
        attributes[key] = value;
      }
    });
    $.ajax({
      url: wsp_php_vars.admin_url,
      type: "POST",
      data: {
        action: "Addify_TBYB_approve_trial_period",
        order_id: orderId,
        product_id: productId,
        variation_id: variationId,
        attributes: attributes, // ✅ send attributes
        action_type: "approve_trial_reason",
        security: wsp_php_vars.admin_approve_nonce,
        approve_reason: true,
      },
      beforeSend: function () {
        $(".addify-trial-order-wrapper").append(
          '<div class="return_form_overlay"></div><p class="return_form_loader"></p>'
        );
      },
      success: function (response) {
        $(".return_form_overlay, .return_form_loader").remove();

        if (response.success && response.data) {
          const allprocessed = response.data.all_processed;

          if (allprocessed && response.data.message) {
            $.post(
              wsp_php_vars.ajaxurl,
              {
                action: "addify_save_message_admin",
                security: wsp_php_vars.save_message_admin_nonce,
                message: response.data.message,
              },
              function () {
                location.reload();
              }
            );
          } else {
            // ✅ Update only THIS table cell
            $btn.closest("td").html("<span class='status'>Approved</span>");
          }
        }
      },
    });
  });
  $(".reject_trial_return_reason").on("click", function (e) {
    e.preventDefault();
    const $btn = $(this);

    var orderId = $(this).data("order-id");
    var productId = $(this).data("product-id");
    var variationId = $(this).data("variation-id");
    const rejectReason = $btn
      .closest(".reject-popup-form")
      .find("textarea[name='return_reason_text']")
      .val()
      .trim();
    // ✅ Validation: stop if no reason entered
    if (!rejectReason) {
      alert("Please enter a reject reason before submitting.");
      return;
    }
    const attributes = {};
    $.each($btn[0].dataset, function (key, value) {
      if (key.startsWith("attribute_")) {
        attributes[key] = value;
      }
    });
    $.ajax({
      url: wsp_php_vars.admin_url,
      type: "POST",
      data: {
        action: "Addify_TBYB_reject_trial_period",
        order_id: orderId,
        product_id: productId,
        variation_id: variationId,
        attributes: attributes,
        reject_reason_text: rejectReason,
        action_type: "reject_trial_reason",
        security: wsp_php_vars.admin_reject_nonce,
        reject_reason: true,
      },
      beforeSend: function () {
        $(".addify-trial-order-wrapper").append(
          '<p class="return_form_loader"></p>'
        );
      },
      success: function (response) {
        $(
          ".return_form_overlay, .return_form_loader , .trial_reject_overlay"
        ).remove();
        $(".reject-popup-form").hide();

        if (response.success && response.data) {
          const allprocessed = response.data.all_processed;

          if (allprocessed && response.data.message) {
            $.post(
              wsp_php_vars.ajaxurl,
              {
                action: "addify_save_message_admin",
                security: wsp_php_vars.save_message_nonce,
                message: response.data.message,
              },
              function () {
                location.reload();
              }
            );
          } else {
            $btn
              .closest("td")
              .html(
                "<p class='status'>"+wsp_php_vars.rejected_text+"</p>" +
                "<p class='status'>"+wsp_php_vars.admin_reject_text+":</p>"+
                  "<p class='admin_reject_reason'>" +
                  response.data.reject_reason_text +
                  "</p>"
              );
          }
        }
      },
    });
  });

  $(document).on("click", "#close_reject_form", function (e) {
    e.preventDefault();

    $(this).closest(".reject-popup-form").hide();

    $(".trial_reject_overlay").remove();
  });
  $(document).on("click", ".trial_reject_overlay", function () {
    $(".reject-popup-form").hide();
    $(this).remove();
  });
  $(".reject_trial_return_reason_popup_button").on("click", function (e) {
    e.preventDefault();

    // Find the sibling reject form and show it
    $(this)
      .closest(".approve_reject_trial_return_reason")
      .next(".reject-popup-form")
      .show();
    $(".addify-trial-order-wrapper").append(
      '<div class="trial_reject_overlay"></div>'
    );
  });
});
