jQuery(document).ready(function ($) {
  const $boxes = $(".box");
  const chartData = wsp_php_vars.chart_data;

  const chartInstances = {};

  function renderChart(stat) {
    const $chartContainer = $(`#chart-${stat}`);
    if ($chartContainer.length === 0) return;

    if (document.querySelector(".date-range-info").textContent == "") {
      const formattedRange = chartData.range
        .replace(/_/g, " ")
        .replace(/\b\w/g, (c) => c.toUpperCase());
      const dateInfo = `${formattedRange} (${
        chartData.start_date.date.split(" ")[0]
      } to ${chartData.end_date.date.split(" ")[0]})`;
      document.querySelector(".date-range-info").textContent = dateInfo;
    }

    $(".chart-container").hide();
    $chartContainer.show();

    if (!chartInstances[stat]) {
      const ctx = $chartContainer.find("canvas")[0].getContext("2d");
      const maxY = Math.max(...chartData[stat]);
      const baseMax = Math.max(maxY, 15);
      const stepSize = Math.ceil(baseMax / 3 / 5) * 5;
      const max = stepSize * 3;

      chartInstances[stat] = new Chart(ctx, {
        type: "line",
        data: {
          labels: chartData.labels,
          datasets: [
            {
              label: stat
                .replace(/_/g, " ")
                .replace(/\b\w/, (c) => c.toUpperCase()),
              data: chartData[stat],
              borderColor: "#0073aa",
              borderWidth: 2,
              backgroundColor: "transparent",
            },
          ],
        },
        options: {
          responsive: true,
          plugins: {
            legend: { display: false },
            tooltip: { mode: "index", intersect: false },
          },
          interaction: { mode: "nearest", axis: "x", intersect: false },
          scales: {
            x: {
              grid: { display: false },
              ticks: { color: "#555", font: { size: 12 } },
            },
            y: {
              beginAtZero: true,
              min: 0,
              max: max,
              grid: { color: "#e0e0e0", drawBorder: false },
              ticks: {
                color: "#555",
                font: { size: 12 },
                stepSize: stepSize,
                callback: (value) => value,
              },
            },
          },
        },
      });
    }
  }

  $boxes.on("click", function () {
    const stat = $(this).data("stat");
    renderChart(stat);
    $boxes.removeClass("active");
    $(this).addClass("active");
  });

  renderChart("active_trial");

  // ========== Preset Options ==========
  $(".preset-options li").on("click", function () {
    const range = $(this).data("range");
    $(".preset-options li").removeClass("active");
    $(this).addClass("active");

    $calendarPreview.html("");
    fetchAndUpdateCharts(range);
  });

  function updateCharts(data) {
    const formattedRange = data.range
      .replace(/_/g, " ")
      .replace(/\b\w/g, (c) => c.toUpperCase());
    const startDateStr =
      typeof data.start_date === "string"
        ? data.start_date.split(" ")[0]
        : data.start_date.date.split(" ")[0];
    const endDateStr =
      typeof data.end_date === "string"
        ? data.end_date.split(" ")[0]
        : data.end_date.date.split(" ")[0];
    const dateInfo = `${formattedRange} (${startDateStr} to ${endDateStr})`;
    document.querySelector(".date-range-info").textContent = dateInfo;

    // --- Update Stat Boxes ---
    document.querySelectorAll(".stats-boxes .box").forEach((box) => {
      const statKey = box.getAttribute("data-stat");
      if (data[statKey]) {
        const total = data[statKey].reduce((sum, val) => sum + val, 0);
        const isMoneyStat = [
          "shipping_cost",
          "amount_of_kept_products",
        ].includes(statKey);

        const isPercentageStat = ["average_return_rate"].includes(statKey);

        const boxNumbers = box.querySelector(".box-numbers");

        if (!boxNumbers) return;
        const currencySymbol = data.currency_symbol || "$";

        if (isMoneyStat) {
          const formatted = new Intl.NumberFormat("en-US", {
            style: "currency",
            currency: currencySymbol,
          }).format(total);

          // Split symbol and amount for WooCommerce styling
          const symbol = formatted.match(/[^0-9.,\s]+/g)?.[0] || "$";
          const amount = formatted.replace(symbol, "").trim();

          boxNumbers.innerHTML = `
        <span class="woocommerce-Price-amount amount">
          <span class="woocommerce-Price-currencySymbol">${symbol}</span>&nbsp;${amount}
        </span>
      `;
        } else if (isPercentageStat) {
          const keptTotal = data.total_kept.reduce((sum, val) => sum + val, 0);
          const returnedTotal = data.total_returns.reduce(
            (sum, val) => sum + val,
            0
          );
          const overallRate =
            keptTotal + returnedTotal > 0
              ? (returnedTotal / (keptTotal + returnedTotal)) * 100
              : 0;
          boxNumbers.textContent = `${overallRate.toFixed(2)}%`;
        } else {
          boxNumbers.textContent = total.toLocaleString();
        }
      }
    });

    // --- Update Charts ---
    Object.keys(data).forEach((stat) => {
      if (
        stat === "labels" ||
        stat === "start_date" ||
        stat === "end_date" ||
        stat === "range"
      )
        return;

      const $chartContainer = $(`#chart-${stat}`);
      const canvas = $chartContainer.find("canvas")[0];
      if (!$chartContainer.length || !canvas) return;

      const ctx = canvas.getContext("2d");
      const values = data[stat];
      const maxY = Math.max(...values);
      const baseMax = Math.max(maxY, 15);
      const stepSize = Math.ceil(baseMax / 3 / 5) * 5;
      const max = stepSize * 3;

      if (chartInstances[stat]) {
        chartInstances[stat].data.labels = data.labels;
        chartInstances[stat].data.datasets[0].data = values;
        chartInstances[stat].options.scales.y.max = max;
        chartInstances[stat].options.scales.y.ticks.stepSize = stepSize;
        chartInstances[stat].update();
      } else {
        chartInstances[stat] = new Chart(ctx, {
          type: "line",
          data: {
            labels: data.labels,
            datasets: [
              {
                label: stat
                  .replace(/_/g, " ")
                  .replace(/\b\w/, (c) => c.toUpperCase()),
                data: values,
                borderColor: "#0073aa",
                borderWidth: 2,
                backgroundColor: "transparent",
              },
            ],
          },
          options: {
            responsive: true,
            plugins: {
              legend: { display: false },
              tooltip: { mode: "index", intersect: false },
            },
            interaction: { mode: "nearest", axis: "x", intersect: false },
            scales: {
              x: {
                grid: { display: false },
                ticks: { color: "#555", font: { size: 12 } },
              },
              y: {
                beginAtZero: true,
                min: 0,
                max: max,
                grid: { color: "#e0e0e0", drawBorder: false },
                ticks: {
                  color: "#555",
                  font: { size: 12 },
                  stepSize: stepSize,
                  callback: (value) => value,
                },
              },
            },
          },
        });
      }
    });
  }

  // Dropdown logic
  const $dropdownToggle = $(".dropdown-toggle");
  const $dropdownMenu = $(".dropdown-menu");
  const $customTabOverlay = $(".custom-tab-overlay");

  $dropdownToggle.on("click", function (e) {
    e.stopPropagation();
    $dropdownMenu.toggle();
    $customTabOverlay.toggle();
    const isDropdownVisible = $dropdownMenu.is(":visible");
    const isCustomActive = $(".tab[data-tab='custom-tab']").hasClass("active");
    const dateValue = $("#custom-date-range").val()?.trim();

    if (isDropdownVisible && isCustomActive && dateValue !== "") {
      fp.open(); // open Flatpickr
    } else {
      fp.close(); // close Flatpickr otherwise
    }
  });

  $customTabOverlay.on("click", function (e) {
    $dropdownMenu.hide();
    $customTabOverlay.hide();
  });
  $dropdownMenu.on("click", function (e) {
    e.stopPropagation();
  });

  // Tabs + Calendar
  const $tabs = $(".tab");
  const $contents = $(".tab-content");
  const $calendarPreview = $("#calendar-preview");
  const $presettab = $(".preset-tab");

  const fp = flatpickr("#custom-date-range", {
    mode: "range",
    dateFormat: "Y-m-d",
    maxDate: "today",
    onChange: function (selectedDates) {
      if (selectedDates.length === 2) {
        const start = flatpickr.formatDate(selectedDates[0], "Y-m-d");
        const end = flatpickr.formatDate(selectedDates[1], "Y-m-d");

        $(".preset-options li").removeClass("active");
        $calendarPreview.html(
          `<strong style="padding: 10px 0px 0px 10px">Selected:</strong> ${start} → ${end}`
        );

        fetchAndUpdateCharts(null, start, end);
      }
    },
  });

  $tabs.on("click", function () {
    $tabs.removeClass("active");
    $contents.removeClass("active");
    $(this).addClass("active");
    $("." + $(this).data("tab")).addClass("active");

    if ($(this).data("tab") === "custom-tab") {
      $presettab.hide();
      const dateValue = $("#custom-date-range").val()?.trim();

      if (dateValue !== "") {
        fp.open(); // open Flatpickr
      } else {
        fp.close(); // close Flatpickr otherwise
      }
    } else {
      $presettab.show();
    }
  });

  function fetchAndUpdateCharts(range, startDate = null, endDate = null) {
    $dropdownMenu.hide();
    $customTabOverlay.hide();
    let body = `action=get_trial_dashboard_data&nonce=${wsp_php_vars.nonce}`;
    if (range) {
      // Clear custom date input and calendar preview
      $("#custom-date-range").val("");
      $("#calendar-preview").html("");
      // ✅ Properly reset the same Flatpickr instance (`fp`)
      if (fp && typeof fp.clear === "function") {
        fp.clear();
      }
      body += `&range=${range}`;
    }
    if (startDate && endDate) {
      body += `&start_date=${startDate}&end_date=${endDate}`;
      $(".preset-options li").removeClass("active");
    }

    fetch(ajaxurl, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: body,
    })
      .then((response) => response.json())
      .then((data) => {
        updateCharts(data);
      })
      .catch((err) => {
        console.error("Error fetching data:", err);
      });
  }
});
