jQuery(document).ready(function ($) {
  var tbybWrapper = $("#addify-tbyb-wrapper");
  var tryNowOption = $("#try_now_button_options").val();

  if (tbybWrapper.length) {
    var $targetButton = $(".single_add_to_cart_button");
    $targetButton.css("float", "none");

    var $cart_form = $targetButton.parent(".cart");
    $cart_form.css("display", "block");
    if (tryNowOption === "add_new") {
      if (!$targetButton.parent().hasClass("tbyb-button-container")) {
        $targetButton.wrap(
          "<div class='tbyb-button-container' style='display:flex; align-items:center; gap:10px;'></div>"
        );
      }
      var $container = $targetButton.parent(".tbyb-button-container");
      $container.append(tbybWrapper).css("display", "-webkit-inline-box");
      tbybWrapper.css("display", "flex");
    } else if (tryNowOption === "add_replace") {
      tbybWrapper.insertAfter($targetButton);
      $targetButton.remove();
    }
  }
  
  var $buttonbehaviour = addify_TBYB_data_product.button_behaviour;
  if ($buttonbehaviour === "in-page") {
    $(".tbyb-try-now-btn").on("click", function (e) {
      e.preventDefault();
      // Show instruction wrapper with smooth transition
      $(".tbyb-instruction-wrapper").slideDown(300); // 300ms animation
    });
  } else if ($buttonbehaviour === "pop-up") {
    $(".tbyb-try-now-btn-popup").on("click", function (e) {
      e.preventDefault();
      $("#tbyb-popup").attr("style", "");
      $("#tbyb-popup").fadeIn(300);
    });

    $(document).on(
      "click",
      ".tbyb-popup-close, .tbyb-popup-overlay",
      function (e) {
        e.preventDefault();
        $("#tbyb-popup").fadeOut(300, function () {
          $(this).attr("style", "display: none !important;");
        });
      }
    );
  }
  
  $("form.cart").removeAttr("style");

  // Function to update Try Before Buy button state and URL
  function updateTBYBButton() {
    var isVariableProduct = $("#tbyb_is_variable_product").val();
    if (isVariableProduct === "yes") {
      var variation_id = $('input[name="variation_id"]').val();
      var tbybButton = $(".tbyb-try-now-btn, .tbyb-try-now-btn-popup");
      var proceedButton = $(".tbyb-proceed-btn");

      if (variation_id && variation_id !== "0") {
        // Enable button
        tbybButton.removeClass("tbyb-disabled").removeAttr("disabled");
        proceedButton.removeClass("tbyb-disabled").removeAttr("disabled");
        
        // Update URLs with variation attributes
        updateTBYBUrls(variation_id);
      } else {
        // Disable button
        tbybButton.addClass("tbyb-disabled").attr("disabled", "disabled");
        proceedButton.addClass("tbyb-disabled").attr("disabled", "disabled");
      }
    }
  }

  // Function to update Try Before Buy URLs with variation data
  function updateTBYBUrls(variation_id) {
    $(".tbyb-proceed-btn, .tbyb-try-now-btn, .tbyb-try-now-btn-popup").each(function () {
      var $button = $(this);
      var originalUrl = $button.attr("href") || $button.data("url") || "";
      
      if (originalUrl) {
        var url = new URL(originalUrl, window.location.origin);
        
        // Update or add variation_id parameter
        url.searchParams.set("try_before_buy", variation_id);
        
        // Add variation attributes to URL
        var selectedData = $("#tbyb_selected_variation").val();
        if (selectedData) {
          try {
            var attributes = JSON.parse(selectedData);
            for (var attrName in attributes) {
              if (attributes.hasOwnProperty(attrName) && attributes[attrName]) {
                // Convert attribute_pa_color to attribute_color format
                var cleanAttrName = attrName.replace(/^attribute_/, '');
                url.searchParams.set("attribute_" + cleanAttrName, attributes[attrName]);
              }
            }
          } catch (e) {
            console.error("Error parsing variation attributes:", e);
          }
        }
        
        // Update the button URL
        if ($button.is("a")) {
          $button.attr("href", url.toString());
        } else {
          $button.attr("data-url", url.toString());
        }
      }
    });
  }

  // Listen for variation changes
  $(document).on("change", ".variation_id", function () {
    var variation_id = $(this).val();
    updateTBYBButton(); // Update button state and URLs

    $("#tbyb_selected_variation").val($(this).val());
  });

  // Listen for WooCommerce variation events
  $(document).on("found_variation", "form.cart", function (event, variation) {
    updateTBYBButton();
    
    // Store the selected variation attributes
    if (variation && variation.attributes) {
      $("#tbyb_selected_variation").val(JSON.stringify(variation.attributes));
    }
  });

  $(document).on("reset_data", "form.cart", function () {
    updateTBYBButton();
    $("#tbyb_selected_variation").val("");
  });
  
  jQuery("form.variations_form").on(
    "woocommerce_variation_has_changed",
    function () {
      let selectedData = {};

      jQuery(this)
        .find("select[data-attribute_name]")
        .each(function () {
          const attrName = jQuery(this).data("attribute_name"); // attribute_pa_color
          const attrValue = jQuery(this).val(); // red/blue/etc
          selectedData[attrName] = attrValue;
        });

      // Save into hidden field
      jQuery("#tbyb_selected_variation").val(JSON.stringify(selectedData));
      
      // Update URLs with current attributes
      var variation_id = $('input[name="variation_id"]').val();
      if (variation_id && variation_id !== "0") {
        updateTBYBUrls(variation_id);
      }

      console.log("Stored attributes:", selectedData);
    }
  );

  // Function to handle attribute changes directly
  $(document).on("change", ".variations select", function() {
    setTimeout(function() {
      var variation_id = $('input[name="variation_id"]').val();
      if (variation_id && variation_id !== "0") {
        updateTBYBUrls(variation_id);
      }
    }, 100);
  });

  // Initial check
  updateTBYBButton();
});