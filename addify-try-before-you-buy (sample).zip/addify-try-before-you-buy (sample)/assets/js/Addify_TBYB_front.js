jQuery(document).ready(function ($) {
  function closeReturnModal() {
    $("#return-reason-modal").removeClass("active").hide();
    $("#modal-overlay").removeClass("active").hide();
    $("body").removeClass("modal-open");
    $(".custom-return-reason textarea").val("");
    $("#return_reason").val("").trigger("change");
  }

  $("#modal-overlay, #close_return_modal").on("click", function () {
    closeReturnModal();
  });
  $("#return_reason").on("change", function () {
    const selectedVal = $(this).val();
    if (selectedVal === "custom_reason") {
      $(".custom-return-reason").show().find("textarea").prop("required", true);
    } else {
      $(".custom-return-reason")
        .hide()
        .find("textarea")
        .prop("required", false);
    }
  });

  $(".keep-btn").on("click", function (e) {
    e.preventDefault();
    e.stopPropagation();

    const $btn = $(this);
    const productName = $btn.data("product");
    const orderId = $btn.data("order-id");
    const productId = $btn.data("id");
    const rowId = $btn.data("row-id");

    const attributes = {};
    $.each($btn[0].dataset, function (key, value) {
      if (!["product", "id", "orderId", "rowId"].includes(key)) {
        attributes[key] = value;
      }
    });

    $.ajax({
      url: addify_TBYB_front_data.ajaxurl,
      type: "POST",
      data: {
        action: "trial_product_action",
        action_type: "keep",
        security: addify_TBYB_front_data.keep_nonce,
        order_id: orderId,
        product_id: productId,
        attributes: attributes,
      },
      beforeSend: function () {
        $(".woocommerce-order-details").append(
          '<div class="return_form_overlay"></div><p class="return_form_loader"></p>'
        );
      },
      success: function (response) {
        $(".return_form_overlay, .return_form_loader").remove();

        $(
          `[data-row-id="${rowId}"] .keep-btn, [data-row-id="${rowId}"] .return-btn`
        ).each(function () {
          const $currentBtn = $(this);
          let match = true;

          // If attributes exist (variation), compare them
          if (Object.keys(attributes).length > 0) {
            $.each(attributes, function (key, value) {
              if ($currentBtn.data(key) != value) {
                match = false;
                return false; // break loop
              }
            });
          }

          if (
            Object.keys(attributes).length === 0 &&
            $currentBtn.data("id") != productId
          ) {
            match = false;
          }

          if (match) {
            $currentBtn
              .closest(".custom-trial-buttons")
              .html(
                `<div class="keep-product-text">${addify_TBYB_front_data.kept_text}</div>`
              );
          }
        });

        var allprocessed = response.data.all_processed;
        if (allprocessed) {
          if (response.data.message) {
            $.post(
              addify_TBYB_front_data.ajaxurl,
              {
                action: "addify_save_message",
                security: addify_TBYB_front_data.save_message_nonce,
                message: response.data.message,
              },
              function () {
                location.reload();
              }
            );
          } else {
            location.reload();
          }
        }
      },
      error: function (xhr, status, error) {},
    });
  });

  $(".return-btn").on("click", function (e) {
    e.preventDefault();
    e.stopPropagation();

    const $btn = $(this);
    const productName = $btn.data("product");
    const orderId = $btn.data("order-id");
    const productId = $btn.data("id");
    const rowId = $btn.data("row-id");

    const attributes = {};
    $.each($btn[0].dataset, function (key, value) {
      if (!["product", "id", "orderId", "rowId"].includes(key)) {
        attributes[key] = value;
      }
    });

    const $form = $("#return-reason-form");
    $form.find('input[name^="attributes"]').remove();
    for (const key in attributes) {
      $("<input>")
        .attr("type", "hidden")
        .attr("name", `attributes[${key}]`)
        .val(attributes[key])
        .appendTo($form);
    }

    $("#popup-product-id").val(productId);
    $("#popup-order-id").val(orderId);
    $("#popup-product-name").text(productName);
    $("#popup-product-input").val(productName);
    $("#popup-row-id").val(rowId);

    $("#modal-overlay").show();
    $("#return-reason-modal").fadeIn();
  });

  $("#return-reason-form").on("submit", function (e) {
    e.preventDefault();
    e.stopPropagation();

    const formElement = this;
    const formData = new FormData(formElement);

    const selectedReason = $("#return_reason").val();
    const reason =
      selectedReason === "custom_reason"
        ? $("#custom_reason_text").val().trim()
        : $("#return_reason option:selected").text().trim();

    const productId = $("#popup-product-id").val();
    const orderId = $("#popup-order-id").val();
    const rowId = $("#popup-row-id").val();

    if (!reason || !productId || !orderId || !rowId) {
      alert("Missing required information.");
      return;
    }

    formData.append("action", "trial_product_action");
    formData.append("action_type", "return");
    formData.append("reason", reason);
    formData.append("security", addify_TBYB_front_data.return_nonce);

    $.ajax({
      url: addify_TBYB_front_data.ajaxurl,
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      beforeSend: function () {
        $("#return-reason-modal").append(
          '<div class="return_form_overlay"></div><p class="return_form_loader"></p>'
        );
      },
      success: function (response) {
        closeReturnModal();
        $(".return_form_overlay, .return_form_loader").remove();

        const fileInput = $("#return_reason_file")[0];

        if (fileInput && fileInput.files && fileInput.files.length > 0) {
          const file = fileInput.files[0];
          if (file) {
            $("#return_reason_file").val("");
            $("#file-upload-name").text("");
            $("#file-upload-error").text("");
          }
        }

        const attributes = {};
        $("#return-reason-form")
          .find("[name^='attributes']")
          .each(function () {
            const name = $(this)
              .attr("name")
              .replace(/^attributes\[|\]$/g, "")
              .toLowerCase();
            const value = ($(this).val() || "").trim().toLowerCase();
            attributes[name] = value;
          });
        const productId = $("#popup-product-id").val();
        const orderId = $("#popup-order-id").val();
        const rowId = $("#popup-row-id").val();
        let updatedOnce = false;
        $(`[data-row-id="${rowId}"]`)
          .find(".keep-btn, .return-btn")
          .each(function (index) {
            if (updatedOnce) {
              return;
            }

            const $currentBtn = $(this);
            const btnData = $currentBtn[0].dataset;

            const btnAttributes = {};
            $.each(btnData, function (key, value) {
              if (
                !["product", "id", "orderid", "rowid"].includes(
                  key.toLowerCase()
                )
              ) {
                btnAttributes[key.toLowerCase()] = (value || "")
                  .trim()
                  .toLowerCase();
              }
            });

            let match = true;

            //  Match variation (or simple product) ID first
            if ($currentBtn.data("id") != productId) {
              match = false;
            }

            // Then check all attributes (must match exactly)
            if (match && Object.keys(attributes).length > 0) {
              for (const key in attributes) {
                if (btnAttributes[key] !== attributes[key]) {
                  match = false;
                  break;
                }
              }
            }

            if (match) {
              updatedOnce = true;
              $currentBtn.closest(".custom-trial-buttons").html(`
          <strong>${addify_TBYB_front_data.return_text}</strong>
          <div class="return-reason-text">${reason}</div>
        `);
            }
          });

        var allprocessed = response.data.all_processed;
        if (allprocessed) {
          if (response.data.message) {
            $.post(
              addify_TBYB_front_data.ajaxurl,
              {
                action: "addify_save_message",
                security: addify_TBYB_front_data.save_message_nonce,
                message: response.data.message,
              },
              function () {
                location.reload();
              }
            );
          } else {
            location.reload();
          }
        }
      },
      error: function (xhr, status, error) {},
    });
  });

  const maxSize = 10 * 1024 * 1024; // 10MB

  $("#return_reason_file").on("change", function () {
    const file = this.files[0];
    const $errorDiv = $("#file-upload-error");
    const $fileNameDiv = $("#file-upload-name");

    if (file) {
      if (file.size > maxSize) {
        $errorDiv.text("File is too big. Max size is 10MB.");
        $fileNameDiv.text("");
        $fileNameDiv.$(this).val(""); // clear the file input
      } else {
        $errorDiv.text("");
        $fileNameDiv.text(file.name);
      }
    }
  });

  (function () {
    var $dropTarget = $(".custom-file-upload");
    var $fileInput = $("#return_reason_file");

    function preventDefaults(e) {
      e.preventDefault();
      e.stopPropagation();
    }

    $(document).on("dragenter dragover dragleave drop", function (e) {
      preventDefaults(e);
    });

    $dropTarget.on("dragenter dragover", function () {
      $(this).addClass("is-dragover");
    });
    $dropTarget.on("dragleave drop", function () {
      $(this).removeClass("is-dragover");
    });

    $dropTarget.on("drop", function (e) {
      var dt = e.originalEvent && e.originalEvent.dataTransfer;
      if (!dt || !dt.files || dt.files.length === 0) return;
      if ($fileInput && $fileInput.length) {
        $fileInput[0].files = dt.files;
        $fileInput.trigger("change");
      }
    });
  })();
  $(".extend-trial-btn").on("click", function (e) {
    e.preventDefault();

    var orderId = $(this).data("order-id");

    $.ajax({
      url: addify_TBYB_front_data.ajaxurl,
      type: "POST",
      data: {
        action: "trial_product_action",
        order_id: orderId,
        action_type: "extend_trial",
        security: addify_TBYB_front_data.extend_nonce,
        extend_trial: true,
      },
      success: function (response) {
        if (response.data.message) {
          $.post(
            addify_TBYB_front_data.ajaxurl,
            {
              action: "addify_save_message",
              security: addify_TBYB_front_data.save_message_nonce,
              message: response.data.message,
            },
            function () {
              location.reload();
            }
          );
        } else {
          location.reload();
        }
      },
      error: function (xhr, status, error) {},
    });
  });
  document.querySelectorAll("#back-to-orders").forEach(function (button) {
    button.addEventListener("click", function () {
      const orderId = this.getAttribute("data-order-id");

      const orderDetails = document.getElementById("order-products-" + orderId);
      if (orderDetails) {
        orderDetails.style.display = "none";
      }

      const orderList = document.getElementById("order-list-container");
      if (orderList) {
        orderList.style.display = "block";
      }
    });
  });

  $("#close_return_modal, #modal-overlay").on("click", function () {
    const file = $("#return_reason_file")[0].files[0];

    if (file) {
      $("#return_reason_file").val("");
      $("#file-upload-name").text("");
      $("#file-upload-error").text("");
    }
    $("#modal-overlay, #return-reason-modal").fadeOut();
  });
});
