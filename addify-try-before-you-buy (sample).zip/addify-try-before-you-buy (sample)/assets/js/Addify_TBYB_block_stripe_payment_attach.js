document.addEventListener('wc_stripe_block_payment_complete', async (e) => {
  const intent = e.detail.paymentIntent;

  if (intent && intent.payment_method) {
    const response = await fetch('/wp-json/custom-stripe/v1/attach-method', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        payment_method_id: intent.payment_method,
        customer_id: window.stripe_customer_id,
      }),
    });

    const result = await response.json();
    if (result.success) {
      // Payment method successfully attached to customer
    }
  }
});
